import random
import matplotlib.pyplot as plt


class Word:
    def __init__(self, length, diff_level):
        self.length = length
        self.diff_level = diff_level
        self.correct_streak = 0

    def visited_correctly(self):
        # increment the number of correct_streak
        pass

    def visited_incorrectly(self):
        # reset the number of correct_streak
        pass

    def get_difficulty_representation(self):
        # calculate the difficulty of the word:
        # 0.0 if correct_streak is at least 10
        # (length * diff_level) / (streak + 1) otherwise
        return 1.0


class Student:
    def __init__(self, retention_rate):
        self.retention_rate = retention_rate
        self.vocabulary = list()

    def get_no_of_learned_words(self):
        # return number of learned words
        return 0

    def learn(self, words_batch):
        # represents learning new words
        # throw TypeError if non-Word object in words_batch
        pass

    def review(self):
        # represents a review session; returns the list of words forgotten
        # generate a random number between 0 and 1 for each word
        # process each word in the following way:
        #  - if random number smaller than retention_rate, word remembered
        #  - if random number smaller than the word's difficulty, word remembered
        #  - otherwise word forgot
        return list()

    def time_step(self, new_words):
        # represents a student's study session:
        # combination of review and learning new words
        # returns list of forgotten words
        return list()


def simulate_learning(word_list_size, batch_size,
                      student_retention_rate, duration):
    # the method simulates a student learning new words
    # generate word_list_size number of words
    # simulate duration time steps
    # return a list of the student's vocabulary at each time step
    learned_vocabulary_sizes = list()

    return learned_vocabulary_sizes


def main():
    # test students' learning with different retention rates
    # visualize the changes in a single plot
    # sample call of simulate_cleaning
    # simulate_learning(500, 20, 0.95, 1000)
    pass


if __name__ == '__main__':
    main()
