import random
import matplotlib.pyplot as plt


class Room:
    def __init__(self, width, length):
        self.width = width
        self.length = length
        self.room = list()
        for w in range(self.width):
            self.room.append(list())
            for l in range(self.length):
                self.room[-1].append(0)

    def add_dust(self, count):
        # add count number of dust to random positions in the room
        pass

    def has_position(self, pos):
        # return True if the room has position with coordinates
        # defined in the parameter (a tuple of x and y coordinates)
        # return False otherwise
        return False

    def has_dust(self, pos):
        # return True if there is dust on position with coordinates
        # defined in the parameter (a tuple of x and y coordinates)
        # return False otherwise
        return False

    def pickup_dust(self, pos):
        # decrease the number of dust particles at position pos if it has any
        # pos - tuple with x and y coordinates
        pass

    def is_clean(self):
        # returns True if there's no dust in the room
        # returns False otherwise
        return False


class VacuumCleaner:
    def __init__(self, start_pos, room):
        self.current_position = start_pos
        self.possible_directions = ['N', 'E', 'S', 'W']
        self.room = room

    def move(self, direction):
        # moves the vacuum cleaner:
        # - if there's dust on the vacuum's current position, do not move it
        # - otherwise compute the new position's coordinate based on direction
        # - if the room has position with the new coordinates, move the vacuum
        # direction -- should be a single letter (N, E, S, or W)
        #              raise ValueError otherwise
        pass


def simulate_cleaning(room_dimensions, dust_count, simulation_no):
    # the method returns a list of integers -- the number of steps it takes
    # to clean a room
    # the method runs simulation_no number of simulations
    # the vacuum cleaner moves randomly in the room
    all_steps = list()

    return all_steps


def main():
    # tests the distribution of the number of steps it takes to clean the room
    # sample call of simulate_cleaning
    # simulate_cleaning((5, 3), 50, 50)
    pass


if __name__ == '__main__':
    main()
