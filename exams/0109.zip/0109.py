import random
import matplotlib.pyplot as plt


class News:
    def __init__(self, rate_of_excitement, decay):
        self.rate = rate_of_excitement
        self.decay = decay

    def update(self):
        # updates rate according to the formula
        # rate <- rate x decay
        pass


class Person:
    def __init__(self, no_of_friends, rate_of_sharing, excitability):
        self.no_of_friends = no_of_friends
        self.rate_of_sharing = rate_of_sharing
        self.excitability = excitability

        self.friends = None
        self.has_read = False

    def make_friends(self, population):
        # selects no_of_friends elements from population randomly
        pass

    def read_news(self, news):
        # represents the person's reaction to a news, returns a list of Person objects
        # - if the person has read the news, returns an empty list
        # - if the person does not have friends, returns an empty list
        # - if the news's rate of excitement is higher than the person's excitability
        #   returns a list of randomly selected Persons from the list of friends
        #   selects rate_of_sharing x no_of_friends friends
        # - otherwise returns empty list
        pass


def get_read_no(population):
    # returns the number of people who have read the news from population
    pass


def run_simulation(population_size, friend_count_range, news_rate, steps):
    # carries out a simulation of a news spreading within a population
    # returns the number of people who have read the news at each timestep
    pass


def main():
    # tests how the news's rate of excitement affects its spread within a population
    # sample call of run_simulation
    # run_simulation(1000, (10, 20), 0.1, 500)
    pass


if __name__ == '__main__':
    main()
