class Passenger:
    def __init__(self, row, seat, no_of_bags):
        if seat not in ['A', 'B', 'C', 'D', 'E', 'F']:
            raise ValueError("Seat must be a letter from A to F")

        self.row = row
        self.seat = seat
        self.bags = no_of_bags * 4

        self.plane = None
        self.current_position = [None, None]

    def __str__(self):
        return "<Passenger in seat: {}{}>".format(self.row, self.seat)

    def get_position(self):
        return 0, 0

    def get_seat(self):
        return None, None

    def add_to_plane(self, plane):
        pass

    def can_sit(self):
        return True

    def forced_to_move(self, x, y):
        pass

    def move(self):
        return 0, 0
