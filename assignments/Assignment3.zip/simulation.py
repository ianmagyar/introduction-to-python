def simulate_spread(all_news, population):
    return


def average_spread_with_excitement_rate(
        excitement_rate, pop_size, friends_count, patience_limit, test_count=100):
    return None, None


def excitement_to_reach_percentage(percentage, pop_size, friends_count, patience_limit):
    return


def excitement_to_reach_percentage_special_interest(
        percentage, pop_size, friends_count, patience_limit, news_category):
    return


if __name__ == '__main__':
    pass
