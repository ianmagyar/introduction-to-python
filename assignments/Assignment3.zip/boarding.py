class Boarding:
    def __init__(self):
        self.plane = None

    def generate_boarding(self, plane_length):
        # DO NOT IMPLEMENT HERE
        pass

    def run_simulation(self, plane_length):
        return 0

    def test_boarding_method(self, plane_length, no_simulation):
        return 0, []


class BoardingBTF(Boarding):
    def generate_boarding(self, plane_length):
        pass


class BoardingFTB(Boarding):
    def generate_boarding(self, plane_length):
        pass


class BoardingWTA(Boarding):
    def generate_boarding(self, plane_length):
        pass


class BoardingATW(Boarding):
    def generate_boarding(self, plane_length):
        pass


class BoardingRandom(Boarding):
    def generate_boarding(self, plane_length):
        pass


class BoardingSteffen(Boarding):
    def generate_boarding(self, plane_length):
        pass
