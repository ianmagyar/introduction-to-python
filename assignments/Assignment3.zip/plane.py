class Plane:
    def __init__(self, length):
        self.length = length
        self.seats = [[[] for i in range(self.length + 2)] for j in range(7)]

    def add_passengers(self, psg_list):
        pass

    def is_empty(self, row, seat):
        return True

    def move_row(self, row, seat_letter):
        pass

    def return_row(self, row):
        pass

    def move_passengers(self):
        pass

    def boarding_finished(self):
        return True
