class Person:
    def __init__(self, threshold, interested_in):
        self.threshold = threshold
        self.interested_in = interested_in
        self.friends_list = list()
        self.has_read = list()

    def is_interested_in(self, category):
        return

    def has_read_news(self, news):
        return

    def make_friends(self, population, n):
        pass

    def process_news(self, news, time_step):  # 1b
        return


if __name__ == '__main__':
    # you can test the class here
    pass
