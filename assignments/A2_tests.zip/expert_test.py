import math
import random

import ai_system as st_ai
import expert as st_exp


def test_structure(obj, should_have):
    attribute_list = dir(obj)
    for att in should_have:
        if att not in attribute_list:
            print(f"\tMissing attribute {att} in object {obj}.")
            return False
    return True


def test_expert_constructor():
    print("Testing Expert constructor...")
    points = 0.0

    name = "Expert A"
    specialization = "NLP"

    try:
        exp = st_exp.Expert(name, specialization, "assistant", 0.5)
    except Exception as e:
        print("\tValid constructor call raised unexpected exception:")
        print(e)
    else:
        if test_structure(exp, ["name", "specialization", "seniority", "reliability"]):
            points += 0.1

        if exp.name == name:
            points += 0.0125
        else:
            print("\tIncorrect name")

        if exp.specialization == specialization:
            points += 0.0125
        else:
            print("\tIncorrect specialization")

        if exp.seniority == "assistant":
            points += 0.0125
        else:
            print("\tIncorrect seniority")

        if exp.reliability == 0.5:
            points += 0.0125
        else:
            print("\tIncorrect reliability")

    bad_seniority = "invalid_level"
    try:
        st_exp.Expert(name, specialization, bad_seniority, 0.5)
    except ValueError as e:
        expected = f"Unknown seniority level: {bad_seniority}"
        if str(e) == expected:
            points += 0.05
        else:
            print("\tWrong message for invalid seniority")
    except Exception as e:
        print("\tWrong exception type for invalid seniority:", type(e))
    else:
        print("\tMissing exception for invalid seniority")

    bad_rel = 1
    try:
        st_exp.Expert(name, specialization, "assistant", bad_rel)
    except TypeError as e:
        expected = f"Reliability must be float, not {type(bad_rel)}"
        if str(e) == expected:
            points += 0.05
        else:
            print("\tWrong message for non-float reliability")
    except Exception as e:
        print("\tWrong exception type for non-float reliability:", type(e))
    else:
        print("\tMissing exception for non-float reliability")

    bad_rel = 1.5
    try:
        st_exp.Expert(name, specialization, "assistant", bad_rel)
    except ValueError as e:
        expected = f"Reliability must be between 0 and 1. Got {bad_rel}"
        if str(e) == expected:
            points += 0.025
        else:
            print("\tWrong message for reliability out of range")
    except Exception as e:
        print("\tWrong exception type for reliability range:", type(e))
    else:
        print("\tMissing exception for reliability out of range")

    bad_rel = -1.5
    try:
        st_exp.Expert(name, specialization, "assistant", bad_rel)
    except ValueError as e:
        expected = f"Reliability must be between 0 and 1. Got {bad_rel}"
        if str(e) == expected:
            points += 0.025
        else:
            print("\tWrong message for reliability out of range")
    except Exception as e:
        print("\tWrong exception type for reliability range:", type(e))
    else:
        print("\tMissing exception for reliability out of range")

    try:
        st_exp.Expert(name, specialization, "assistant", 0.7)
    except ValueError as e:
        if str(e) == "An assistant's reliability cannot be bigger than 0.6":
            points += 0.05
        else:
            print("\tWrong message for assistant reliability")
    except Exception as e:
        print("\tWrong exception type for assistant reliability:", type(e))
    else:
        print("\tMissing exception for assistant reliability")

    try:
        st_exp.Expert(name, specialization, "associate", 0.4)
    except ValueError as e:
        if str(e) == "An associate's reliability cannot be smaller than 0.5":
            points += 0.05
        else:
            print("\tWrong message for associate low reliability")
    except Exception as e:
        print("\tWrong exception type for associate low reliability:", type(e))
    else:
        print("\tMissing exception for associate low reliability")

    try:
        st_exp.Expert(name, specialization, "associate", 0.9)
    except ValueError as e:
        if str(e) == "An associate's reliability cannot be bigger than 0.8":
            points += 0.05
        else:
            print("\tWrong message for associate high reliability")
    except Exception as e:
        print("\tWrong exception type for associate high reliability:", type(e))
    else:
        print("\tMissing exception for associate high reliability")

    try:
        st_exp.Expert(name, specialization, "professor", 0.6)
    except ValueError as e:
        if str(e) == "A professor's reliability cannot be smaller than 0.7":
            points += 0.05
        else:
            print("\tWrong message for professor reliability")
    except Exception as e:
        print("\tWrong exception type for professor reliability:", type(e))
    else:
        print("\tMissing exception for professor reliability")

    print(f"Testing Expert constructor finished: {points:.2f}/0.5 points")
    return points


def test_estimate_step_duration():
    print("Testing Expert.estimate_step_duration()...")
    points = 0.0

    name = "Expert A"
    specialization = "NLP"

    test_cases = [
        ("assistant", 0.5, 1, 2),   # 1.2 → 2
        ("assistant", 0.5, 5, 6),   # 6.0 → 6
        ("assistant", 0.5, 3, 4),   # 3.6 → 4
        ("associate", 0.6, 1, 1),
        ("associate", 0.6, 7, 7),
        ("associate", 0.6, 13, 13),
        ("professor", 0.8, 1, 1),   # 0.8 → 1
        ("professor", 0.8, 5, 4),   # 4.0 → 4
        ("professor", 0.8, 6, 5),   # 4.8 → 5
    ]
    test_results = {
        "assistant": [],
        "associate": [],
        "professor": []
    }

    for seniority, reliability, base, expected in test_cases:
        try:
            exp = st_exp.Expert(name, specialization, seniority, reliability)
            result = exp.estimate_step_duration(base)
        except Exception as e:
            print(f"\tError for {seniority}, base={base}:")
            print(e)
            continue

        test_results[seniority].append(result == expected)
        if result == expected:
            points += 0.03
        else:
            print(f"\tWrong result for {seniority}, base={base}: expected {expected}, got {result}")

    for seniority in test_results:
        if all(test_results[seniority]):
            points += 0.01

    print(f"Testing Expert.estimate_step_duration() finished: {points:.2f}/0.3 points")
    return points


def test_compute_reliability_weight():
    print("Testing Expert.compute_reliability_weight()...")
    points = 0.0

    name = "Expert A"
    test_cases = [
        ("NLP", "CV", "assistant", 0.5, 0.5),
        ("CV", "NLP", "associate", 0.6, 0.6),
        ("AI", "Robotics", "professor", 0.8, 0.8),
        ("NLP", "NLP", "assistant", 0.5, 0.55),
        ("CV", "CV", "associate", 0.7, 0.77),
        ("AI", "AI", "professor", 0.8, 0.88),
        ("NLP", "NLP", "assistant", 0.6, 0.66),
        ("CV", "CV", "associate", 0.8, 0.88),
        ("AI", "AI", "professor", 0.95, 1.0),
        ("AI", "AI", "professor", 1.0, 1.0)
    ]

    for spec_exp, spec_sys, seniority, reliability, expected in test_cases:
        try:
            exp = st_exp.Expert(name, spec_exp, seniority, reliability)
            result = exp.compute_reliability_weight(spec_sys)
        except Exception as e:
            print(f"\tError for ({spec_exp}, {spec_sys}, {seniority}, {reliability}):")
            print(e)
            continue

        # allow tiny float tolerance
        if abs(result - expected) < 1e-6:
            points += 0.02
        else:
            print(f"\tWrong result for ({spec_exp}, {spec_sys}, {reliability}): expected {expected}, got {result}")

    print(f"Testing Expert.compute_reliability_weight() finished: {points:.2f}/0.2 points")
    return points


def test_linguist_expert():
    print("Testing LinguistExpert...")
    points = 0.0

    name = "Ling A"
    spec = "NLP"

    try:
        ling = st_exp.LinguistExpert(name, spec, "assistant", 0.5)
    except Exception as e:
        print("\tConstructor failed:")
        print(e)
        return points

    if not isinstance(ling, st_exp.Expert):
        print("\tLinguistExpert is not a subclass of Expert")
        print("Testing LinguistExpert finished: 0.00/1.5 points")
        return 0.0

    eval_cases = [
        ("assistant", {"coherence": 1.0, "vocabulary_richness": 1.0, "grammar_errors": 0}, 1.0),
        ("assistant", {"coherence": 0.0, "vocabulary_richness": 0.0, "grammar_errors": 0}, 0.1),
        ("assistant", {"coherence": 0.5, "vocabulary_richness": 0.5, "grammar_errors": 1}, 0.7*0.5 + 0.2*0.5 + 0.1*(1/2)),
        ("assistant", {"coherence": 0.8, "vocabulary_richness": 0.3, "grammar_errors": 2}, 0.7*0.8 + 0.2*0.3 + 0.1*(1/3)),
        ("assistant", {"coherence": 0.2, "vocabulary_richness": 0.9, "grammar_errors": 5}, 0.7*0.2 + 0.2*0.9 + 0.1*(1/6)),
        ("associate", {"coherence": 1.0, "vocabulary_richness": 1.0, "grammar_errors": 0}, 1.0),
        ("associate", {"coherence": 0.0, "vocabulary_richness": 0.0, "grammar_errors": 0}, 0.1),
        ("associate", {"coherence": 0.5, "vocabulary_richness": 0.5, "grammar_errors": 1}, 0.6*0.5 + 0.3*0.5 + 0.1*(1/2)),
        ("associate", {"coherence": 0.8, "vocabulary_richness": 0.3, "grammar_errors": 2}, 0.6*0.8 + 0.3*0.3 + 0.1*(1/3)),
        ("associate", {"coherence": 0.2, "vocabulary_richness": 0.9, "grammar_errors": 5}, 0.6*0.2 + 0.3*0.9 + 0.1*(1/6)),
        ("professor", {"coherence": 1.0, "vocabulary_richness": 1.0, "grammar_errors": 0}, 1.0),
        ("professor", {"coherence": 0.0, "vocabulary_richness": 0.0, "grammar_errors": 0}, 0.2),
        ("professor", {"coherence": 0.5, "vocabulary_richness": 0.5, "grammar_errors": 1}, 0.5*0.5 + 0.3*0.5 + 0.2*(1/2)),
        ("professor", {"coherence": 0.8, "vocabulary_richness": 0.3, "grammar_errors": 2}, 0.5*0.8 + 0.3*0.3 + 0.2*(1/3)),
        ("professor", {"coherence": 0.2, "vocabulary_richness": 0.9, "grammar_errors": 5}, 0.5*0.2 + 0.3*0.9 + 0.2*(1/6)),
    ]

    for seniority, metrics, expected in eval_cases:
        ling = st_exp.LinguistExpert(name, spec, seniority, 0.5 if seniority != "professor" else 0.8)

        try:
            res = ling.evaluate_dialogue(metrics)
        except Exception as e:
            print("\tUnexpected error in evaluate_dialogue:", e)
            continue

        if abs(res - expected) < 1e-6:
            points += 0.02
        else:
            print(f"\tWrong evaluation for {seniority}: expected {expected:.4f}, got {res:.4f}")

    ling = st_exp.LinguistExpert(name, spec, "assistant", 0.5)

    error_tests = [
        ({"vocabulary_richness": 0.5, "grammar_errors": 1}, "Did not find coherence in metrics"),
        ({"coherence": 0.5, "grammar_errors": 1}, "Did not find vocabulary_richness in metrics"),
        ({"coherence": 0.5, "vocabulary_richness": 0.5}, "Did not find grammar_errors in metrics"),
    ]

    for metrics, expected_msg in error_tests:
        try:
            ling.evaluate_dialogue(metrics)
        except KeyError as e:
            if str(e) == f"'{expected_msg}'":
                points += 0.033
            else:
                print("\tWrong error message:", e)
        except Exception as e:
            print("\tWrong exception type:", type(e))
        else:
            print("\tMissing exception for invalid metrics")

    duration_cases = [
        ("assistant", 0.5, 1, 2),
        ("assistant", 0.5, 5, 7),
        ("assistant", 0.5, 3, 4),
        ("assistant", 0.5, 10, 13),
        ("assistant", 0.5, 7, 10),
        ("associate", 0.6, 1, 1),
        ("associate", 0.6, 5, 5),
        ("associate", 0.6, 3, 3),
        ("associate", 0.6, 10, 10),
        ("associate", 0.6, 7, 7),
        ("professor", 0.8, 1, 1),
        ("professor", 0.8, 5, 4),
        ("professor", 0.8, 3, 3),
        ("professor", 0.8, 10, 8),
        ("professor", 0.8, 7, 6),
        ("assistant", 0.5, 2, 3),
        ("assistant", 0.5, 4, 6),
        ("associate", 0.6, 8, 8),
        ("professor", 0.8, 8, 6),
        ("professor", 0.8, 9, 7),
    ]

    for seniority, reliability, base, expected in duration_cases:
        ling = st_exp.LinguistExpert(name, spec, seniority, reliability)

        try:
            res = ling.estimate_step_duration(base)
        except Exception as e:
            print("\tError in estimate_step_duration:", e)
            continue

        if res == expected:
            points += 0.005
        else:
            print(f"\tWrong duration for {seniority}, base={base}: expected {expected}, got {res}")

    print(f"Testing LinguistExpert finished: {points:.2f}/0.5 points")
    return points


def test_ml_researcher():
    print("Testing MLResearcher...")
    points = 0.0

    name = "ML A"
    spec = "NLP"

    frameworks = ["PyTorch", "TensorFlow"]

    try:
        ml = st_exp.MLResearcher(name, spec, "associate", 0.6, frameworks)
    except Exception as e:
        print("\tConstructor failed:")
        print(e)
        return points

    if isinstance(ml, st_exp.Expert) and hasattr(ml, "known_frameworks"):
        if isinstance(ml.known_frameworks, list) and ml.known_frameworks == frameworks:
            points += 0.1
        else:
            print("\tknown_frameworks has incorrect type or value")
    else:
        print("\tMLResearcher is not a subclass of Expert or missing attribute")

    test_cases = [
        ("PyTorch", True),
        ("TensorFlow", True),
        ("Keras", False),
        ("Torch", False),
        ("PyTorch", True),
        ("TensorFlow", True),
        ("MXNet", False),
        ("PyTorch", True),
        ("JAX", False),
        ("TensorFlow", True),
    ]

    for fw, expected in test_cases:
        try:
            res = ml.knows_framework(fw)
        except Exception as e:
            print("\tError in knows_framework:", e)
            continue

        if res == expected:
            points += 0.01
        else:
            print(f"\tknows_framework({fw}) returned {res}, expected {expected}")

    def variance(values):
        mean = sum(values) / len(values)
        return sum((x - mean) ** 2 for x in values) / len(values)

    for i in range(20):
        quality = random.uniform(0.3, 0.9)
        framework = random.choice(["PyTorch", "TensorFlow", "UnknownFW"])
        ai = st_ai.AISystem("AI", spec, framework, quality)

        known_fw = random.choice([True, False])
        seniority = random.choice(["assistant", "associate", "professor"])
        reliabilities = {
            "assistant": 0.5,
            "associate": 0.7,
            "professor": 0.8
        }
        if known_fw:
            ml = st_exp.MLResearcher(name, spec, seniority, reliabilities[seniority], [framework])
        else:
            ml = st_exp.MLResearcher(name, spec, seniority, reliabilities[seniority], ["OtherFW"])

        hours = random.randint(1, 5)

        try:
            res = ml.validate_model(ai, hours)
        except Exception as e:
            print("\tError in validate_model:", e)
            continue

        coherences = res["coherences"]
        consistencies = res["consistencies"]
        variability = res["variability"]

        constants = {
            "assistant": 1.2,
            "associate": 1.0,
            "professor": 0.8
        }
        expected_len = math.ceil(constants[seniority] * hours) * 2

        if len(coherences) == expected_len and len(consistencies) == expected_len:
            points += 0.02
        else:
            print(f"\tRun {i+1}: Wrong number of experiments (expected {expected_len}, got {len(coherences)} and {len(consistencies)})")

        try:
            coh_var = variance(coherences)
            cons_var = variance(consistencies)

            if ml.knows_framework(ai.get_framework()):
                coh_var *= 0.8
                cons_var *= 0.8

            expected_var = (coh_var + cons_var) / 2

            if abs(variability - expected_var) < 1e-6:
                points += 0.02
            else:
                print(f"\tRun {i+1}: Wrong variability value. Expected {expected_var}, got {variability}")
        except Exception as e:
            print("\tError when checking variability:", e)

    print(f"Testing MLResearcher finished: {points:.2f}/1.0 point")
    return points


def test_statistician():
    print("Testing Statistician...")
    points = 0.0

    name = "Stat A"
    spec = "NLP"

    try:
        stat = st_exp.Statistician(name, spec, "associate", 0.6)
    except Exception as e:
        print("\tConstructor failed:")
        print(e)
        return points

    if not isinstance(stat, st_exp.Expert):
        print("\tStatistician is not a subclass of Expert")
        print("Testing Statistician finished: 0.00/1.0 point")
        return 0.0

    test_cases = [
        ([0.8,0.7,0.9],[0.75,0.65,0.85],0.1,0.8,0.7,0.4747,0.4753),
        ([0.6,0.6,0.6],[0.6,0.6,0.6],0.2,0.7,0.6,0.3936,0.3949),
        ([0.9,0.8,0.85],[0.88,0.82,0.87],0.05,0.9,0.8,0.5418,0.5424),
        ([0.5,0.4,0.6],[0.45,0.35,0.55],0.3,0.6,0.5,0.3226,0.3241),
        ([0.7,0.75,0.8],[0.72,0.78,0.76],0.15,0.75,0.65,0.4415,0.4421),
        ([0.3,0.4,0.5],[0.35,0.45,0.55],0.25,0.5,0.4,0.2674,0.2684),
        ([0.85,0.9,0.95],[0.88,0.92,0.94],0.05,0.95,0.85,0.5749,0.5755),
        ([0.6,0.7,0.8],[0.65,0.75,0.85],0.2,0.7,0.6,0.4086,0.4092),
        ([0.4,0.5,0.6],[0.45,0.55,0.65],0.3,0.6,0.5,0.3282,0.3294),
        ([0.9,0.85,0.88],[0.87,0.83,0.86],0.1,0.9,0.8,0.5380,0.5387),
    ]

    for i, (coh, cons, var, ling_score, quality, expected_same, expected_diff) in enumerate(test_cases):
        try:
            ai = st_ai.AISystem("AI", spec, "FW", quality)

            ling = st_exp.LinguistExpert("Ling", spec, "assistant", 0.5)
            ml_same = st_exp.MLResearcher("ML", spec, "associate", 0.6, ["FW"])

            metric_dict_same = {
                "quality": (ai, quality),
                "linguist": (ling, ling_score),
                "MLexpert": (ml_same, {
                    "coherences": coh,
                    "consistencies": cons,
                    "variability": var
                })
            }

            res_same = stat.aggregate_scores(metric_dict_same)

            if not isinstance(res_same, float):
                print(f"\tRun {i+1}: Result is not float (got {type(res_diff)})")
            elif abs(res_same - expected_same) < 1e-3:
                points += 0.05
            else:
                print(f"\tRun {i+1}: Result incorrect (expected {expected_same}, got {res_same:.4f})")

            ml_diff = st_exp.MLResearcher("ML", "DIFF", "associate", 0.6, ["PT"])

            metric_dict_diff = {
                "quality": (ai, quality),
                "linguist": (ling, ling_score),
                "MLexpert": (ml_diff, {
                    "coherences": coh,
                    "consistencies": cons,
                    "variability": var
                })
            }

            res_diff = stat.aggregate_scores(metric_dict_diff)

            if not isinstance(res_diff, float):
                print(f"\tRun {i+1}: Result is not float (got {type(res_diff)})")
            elif abs(res_diff - expected_diff) < 1e-3:
                points += 0.05
            else:
                print(f"\tRun {i+1}: Result incorrect (expected {expected_diff}, got {res_diff:.4f})")

        except Exception as e:
            print(f"\tRun {i+1}: Unexpected error:")
            print(e)

    print(f"Testing Statistician finished: {points:.2f}/1.0 point")
    return points


if __name__ == "__main__":
    total = 0.0

    total += test_expert_constructor()
    total += test_estimate_step_duration()
    total += test_compute_reliability_weight()
    total += test_linguist_expert()
    total += test_ml_researcher()
    total += test_statistician()

    print("\n=========================")
    print(f"TOTAL: {total:.2f}/3.5 points")
