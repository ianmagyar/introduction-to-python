import lab as st_lab
import experiment as st_expmt
import evaluation as st_eval
import expert as st_exp
import ai_system as st_ai


def test_structure(obj, should_have):
    attribute_list = dir(obj)
    for att in should_have:
        if att not in attribute_list:
            print(f"\tMissing attribute {att} in object {obj}.")
            return False
    return True


def test_get_available_experts():
    print("Testing ResearchLab.get_available_experts()...")
    points = 0.0

    ling1 = st_exp.LinguistExpert("Ling1", "NLP", "assistant", 0.5)
    ling2 = st_exp.LinguistExpert("Ling2", "NLP", "assistant", 0.5)
    ml1 = st_exp.MLResearcher("ML1", "NLP", "associate", 0.6, ["FW"])
    ml2 = st_exp.MLResearcher("ML2", "NLP", "associate", 0.6, ["FW"])
    stat1 = st_exp.Statistician("Stat1", "NLP", "associate", 0.6)
    stat2 = st_exp.Statistician("Stat2", "NLP", "associate", 0.6)

    members = [ling1, ling2, ml1, ml2, stat1, stat2]

    lab = st_lab.ResearchLab(members, [])
    protocol = st_eval.EvaluationProtocol("Protocol")
    protocol.add_step({
        "desc": "Step",
        "duration": 3,
        "requirements": [st_exp.LinguistExpert]
    })

    ai = st_ai.AISystem("AI", "NLP", "FW", 0.7)
    busy_experts = [ling1, ml1, stat1]
    expmt = st_expmt.Experiment(lab, protocol, ai, busy_experts)
    lab.active_experiments = [expmt]

    try:
        result = lab.get_available_experts()
    except Exception as e:
        print("\tError calling get_available_experts():")
        print(e)
        return points

    expected = [ling2, ml2, stat2]

    correct = True
    if len(result) != len(expected):
        print(f"\tIncorrect number of available experts (no filter). Expected {len(expected)}, got {len(result)}")
        correct = False

    for exp in expected:
        if exp not in result:
            print("\tMissing available expert:", exp)
            correct = False

    if correct:
        points += 0.05

    filter_tests = [
        (st_exp.LinguistExpert, [ling2]),
        (st_exp.MLResearcher, [ml2]),
        (st_exp.Statistician, [stat2]),
    ]
    for exp_type, expected_list in filter_tests:
        try:
            result = lab.get_available_experts(exp_type)
        except Exception as e:
            print("\tError with type filtering:", e)
            continue

        correct = True
        if len(result) != len(expected_list):
            print(f"\tWrong number of experts for {exp_type}. Expected {len(expected_list)}, got {len(result)}")
            correct = False

        for exp in expected_list:
            if exp not in result:
                print(f"\tMissing expert {exp} for {exp_type}")
                correct = False

        if correct:
            points += 0.05

    print(f"Testing get_available_experts finished: {points:.2f}/0.2 points")
    return points


def test_get_unsolved_requests():
    print("Testing ResearchLab.get_unsolved_requests()...")
    points = 0.0

    ling = st_exp.LinguistExpert("Ling", "NLP", "assistant", 0.5)
    experts = [ling]
    lab = st_lab.ResearchLab(experts, [])
    prot1 = st_eval.EvaluationProtocol("P1")
    prot2 = st_eval.EvaluationProtocol("P2")
    prot3 = st_eval.EvaluationProtocol("P3")
    for prot in [prot1, prot2, prot3]:
        prot.add_step({
            "desc": "Step",
            "duration": 3,
            "requirements": [st_exp.LinguistExpert]
        })

    ai1 = st_ai.AISystem("AI1", "NLP", "FW", 0.7)
    ai2 = st_ai.AISystem("AI2", "NLP", "FW", 0.7)
    ai3 = st_ai.AISystem("AI3", "NLP", "FW", 0.7)

    lab.requests = [
        (ai1, prot1),
        (ai2, prot2),
        (ai3, prot3),
    ]

    lab.active_experiments = []
    res = lab.get_unsolved_requests()
    expected = lab.requests.copy()

    if len(res) == len(expected) and all(req in res for req in expected):
        points += 0.05
    else:
        print("\tRun 1: Incorrect unsolved requests")

    exp1 = st_expmt.Experiment(lab, prot1, ai1, experts)
    lab.active_experiments = [exp1]
    res = lab.get_unsolved_requests()
    expected = [(ai2, prot2), (ai3, prot3)]

    if len(res) == len(expected) and all(req in res for req in expected):
        points += 0.05
    else:
        print("\tRun 2: Incorrect unsolved requests")

    exp2 = st_expmt.Experiment(lab, prot2, ai2, experts)
    lab.active_experiments = [exp1, exp2]

    res = lab.get_unsolved_requests()
    expected = [(ai3, prot3)]

    if len(res) == len(expected) and all(req in res for req in expected):
        points += 0.05
    else:
        print("\tRun 3: Incorrect unsolved requests")

    exp3 = st_expmt.Experiment(lab, prot3, ai3, experts)
    lab.active_experiments = [exp1, exp2, exp3]

    res = lab.get_unsolved_requests()
    expected = []

    if res == expected:
        points += 0.05
    else:
        print("\tRun 4: Incorrect unsolved requests (should be empty)")

    print(f"Testing get_unsolved_requests finished: {points:.2f}/0.2 points")
    return points


def test_can_run_protocol():
    print("Testing ResearchLab.can_run_protocol()...")
    points = 0.0

    ling1 = st_exp.LinguistExpert("Ling1", "NLP", "assistant", 0.5)
    ling2 = st_exp.LinguistExpert("Ling2", "NLP", "assistant", 0.5)
    ml1 = st_exp.MLResearcher("ML1", "NLP", "associate", 0.6, ["FW"])
    ml2 = st_exp.MLResearcher("ML2", "NLP", "associate", 0.6, ["FW"])
    stat1 = st_exp.Statistician("Stat1", "NLP", "associate", 0.6)
    stat2 = st_exp.Statistician("Stat2", "NLP", "associate", 0.6)
    members = [ling1, ling2, ml1, ml2, stat1, stat2]
    lab = st_lab.ResearchLab(members, [])

    protocol = st_eval.EvaluationProtocol("Protocol")
    protocol.add_step({
        "desc": "Step 1",
        "duration": 3,
        "requirements": [st_exp.LinguistExpert]
    })
    protocol.add_step({
        "desc": "Step 2",
        "duration": 4,
        "requirements": [st_exp.MLResearcher]
    })
    protocol.add_step({
        "desc": "Step 3",
        "duration": 2,
        "requirements": [st_exp.Statistician]
    })

    ai = st_ai.AISystem("AI", "NLP", "FW", 0.7)
    lab.active_experiments = []
    if lab.can_run_protocol(protocol) is True:
        points += 0.05
    else:
        print("\tRun 1: Should be able to run protocol")

    exp1 = st_expmt.Experiment(lab, protocol, ai, [ling1, ml1, stat1])
    lab.active_experiments = [exp1]
    if lab.can_run_protocol(protocol) is True:
        points += 0.05
    else:
        print("\tRun 2: Should still be able to run protocol")

    exp2 = st_expmt.Experiment(lab, protocol, ai, [ling1, ling2])
    lab.active_experiments = [exp2]
    if lab.can_run_protocol(protocol) is False:
        points += 0.05
    else:
        print("\tRun 3: Should NOT be able to run protocol (no linguist available)")

    exp3 = st_expmt.Experiment(lab, protocol, ai, [ml1, ml2])
    lab.active_experiments = [exp3]
    if lab.can_run_protocol(protocol) is False:
        points += 0.05
    else:
        print("\tRun 4: Should NOT be able to run protocol (no ML researcher available)")

    print(f"Testing can_run_protocol finished: {points:.2f}/0.2 points")
    return points


def test_run_simulation():
    print("Testing ResearchLab.run_simulation()...")
    points = 0.0

    lab = st_lab.ResearchLab([], [])
    try:
        lab.run_simulation()
    except RuntimeError as e:
        if str(e) == "No selection strategy was set":
            points += 0.1
        else:
            print("\tRun 1: Wrong error message")
    except Exception as e:
        print("\tRun 1: Wrong exception type:", type(e))
    else:
        print("\tRun 1: Missing exception when no strategy set")

    ling = st_exp.LinguistExpert("Ling", "NLP", "assistant", 0.5)
    members = [ling]
    protocol = st_eval.EvaluationProtocol("Protocol")
    protocol.add_step({
        "desc": "Step",
        "duration": 3,
        "requirements": [st_exp.LinguistExpert]
    })
    ai = st_ai.AISystem("AI", "NLP", "FW", 0.7)
    lab = st_lab.ResearchLab(members, [(ai, protocol)])
    strategy = st_lab.ExperimentStrategy()
    lab.set_strategy(strategy)

    try:
        days = lab.run_simulation()
    except Exception as e:
        print("\tRun 2: Unexpected error:")
        print(e)
    else:
        correct = True

        if days == 1:
            points += 0.05
        else:
            print(f"\tRun 2: Expected 1 day, got {days}")
            correct = False

        if len(lab.requests) != 0:
            print("\tRun 2: Requests not cleared")
            correct = False

        if len(lab.active_experiments) != 0:
            print("\tRun 2: Active experiments not empty")
            correct = False

        if len(lab.completed_experiments) != 1:
            print("\tRun 2: Completed experiments incorrect")
            correct = False

        if correct:
            points += 0.10

    ling = st_exp.LinguistExpert("Ling", "NLP", "assistant", 0.5)
    ml = st_exp.MLResearcher("ML", "NLP", "associate", 0.6, ["FW"])
    stat = st_exp.Statistician("Stat", "NLP", "associate", 0.6)
    members = [ling, ml, stat]
    p1 = st_eval.EvaluationProtocol("P1")
    p1.add_step({"desc": "S1", "duration": 3, "requirements": [st_exp.LinguistExpert]})
    p2 = st_eval.EvaluationProtocol("P2")
    p2.add_step({"desc": "S2", "duration": 4, "requirements": [st_exp.MLResearcher]})
    p3 = st_eval.EvaluationProtocol("P3")
    p3.add_step({"desc": "S3", "duration": 5, "requirements": [st_exp.Statistician]})
    ai1 = st_ai.AISystem("AI1", "NLP", "FW", 0.7)
    ai2 = st_ai.AISystem("AI2", "NLP", "FW", 0.7)
    ai3 = st_ai.AISystem("AI3", "NLP", "FW", 0.7)
    requests = [(ai1, p1), (ai2, p2), (ai3, p3)]
    lab = st_lab.ResearchLab(members, requests)
    strategy = st_lab.ExperimentStrategy()
    lab.set_strategy(strategy)

    try:
        days = lab.run_simulation()
    except Exception as e:
        print("\tRun 3: Unexpected error:")
        print(e)
    else:
        correct = True

        if isinstance(days, int) and days >= 1:
            points += 0.05
        else:
            print("\tRun 3: Invalid number of days")
            correct = False

        if len(lab.requests) != 0:
            print("\tRun 3: Requests not cleared")
            correct = False

        if len(lab.active_experiments) != 0:
            print("\tRun 3: Active experiments not empty")
            correct = False

        if len(lab.completed_experiments) != 3:
            print("\tRun 3: Completed experiments incorrect")
            correct = False

        if correct:
            points += 0.10

    print(f"Testing run_simulation finished: {points:.2f}/0.4 points")
    return points


def test_create_experiment_base():
    print("Testing ExperimentStrategy.create_experiment()...")
    points = 0.0

    ling = st_exp.LinguistExpert("Ling", "NLP", "assistant", 0.5)
    ml = st_exp.MLResearcher("ML", "NLP", "associate", 0.6, ["FW"])
    stat = st_exp.Statistician("Stat", "NLP", "associate", 0.6)
    members = [ling, ml]

    p1 = st_eval.EvaluationProtocol("P1")
    p1.add_step({"desc": "S1", "duration": 3, "requirements": [st_exp.LinguistExpert]})
    p2 = st_eval.EvaluationProtocol("P2")
    p2.add_step({"desc": "S2", "duration": 4, "requirements": [st_exp.MLResearcher]})
    p3 = st_eval.EvaluationProtocol("P3")
    p3.add_step({"desc": "S3", "duration": 5, "requirements": [st_exp.Statistician]})
    p4 = st_eval.EvaluationProtocol("P4")
    p4.add_step({"desc": "S4", "duration": 6, "requirements": [st_exp.LinguistExpert, st_exp.MLResearcher]})

    ai1 = st_ai.AISystem("AI1", "NLP", "FW", 0.7)
    ai2 = st_ai.AISystem("AI2", "NLP", "FW", 0.7)
    ai3 = st_ai.AISystem("AI3", "NLP", "FW", 0.7)
    ai4 = st_ai.AISystem("AI4", "NLP", "FW", 0.7)

    requests = [(ai1, p1), (ai2, p2), (ai3, p3), (ai4, p4)]
    lab = st_lab.ResearchLab(members, requests)
    strategy = st_lab.ExperimentStrategy()

    if strategy.create_experiment(lab.requests) is None:
        points += 0.1
    else:
        print("\tShould return None when no lab assigned")

    lab.selection_strategy = strategy
    strategy.lab = lab
    results = []
    for _ in range(5):
        expmt = strategy.create_experiment(lab.requests)
        if isinstance(expmt, st_expmt.Experiment):
            results.append(expmt)

    if len(results) > 0:
        points += 0.1
    else:
        print("\tDid not create any experiment")

    valid_requests = [(ai1, p1), (ai2, p2), (ai4, p4)]
    valid = True

    for expmt in results:
        if not any(expmt.tests(ai, prot) for ai, prot in valid_requests):
            print("\tSelected infeasible or invalid request")
            valid = False

        for req_type in expmt.protocol.get_all_experts():
            if not any(isinstance(e, req_type) for e in expmt.experts):
                print("\tMissing required expert type in experiment")
                valid = False

    if valid:
        points += 0.3

    print(f"Testing ExperimentStrategy.create_experiment() finished: {points:.2f}/0.5 points")
    return points


def test_chronological_strategy():
    print("Testing ChronologicalStrategy...")
    points = 0.0

    ling = st_exp.LinguistExpert("Ling", "NLP", "assistant", 0.5)
    ml1 = st_exp.MLResearcher("ML1", "NLP", "associate", 0.6, ["FW"])
    ml2 = st_exp.MLResearcher("ML2", "NLP", "professor", 0.9, ["FW"])
    stat = st_exp.Statistician("Stat", "NLP", "associate", 0.6)
    members = [ling, ml1, ml2]

    p_invalid = st_eval.EvaluationProtocol("Invalid")
    p_invalid.add_step({
        "desc": "S0",
        "duration": 5,
        "requirements": [st_exp.LinguistExpert, st_exp.Statistician]
    })
    p1 = st_eval.EvaluationProtocol("P1")
    p1.add_step({
        "desc": "S1",
        "duration": 3,
        "requirements": [st_exp.MLResearcher]
    })
    p2 = st_eval.EvaluationProtocol("P2")
    p2.add_step({
        "desc": "S2",
        "duration": 4,
        "requirements": [st_exp.LinguistExpert]
    })
    ai0 = st_ai.AISystem("AI0", "NLP", "FW", 0.7)
    ai1 = st_ai.AISystem("AI1", "NLP", "FW", 0.7)
    ai2 = st_ai.AISystem("AI2", "NLP", "FW", 0.7)
    requests = [(ai0, p_invalid), (ai1, p1), (ai2, p2)]

    lab = st_lab.ResearchLab(members, requests)
    strat = st_lab.ChronologicalStrategy()
    lab.selection_strategy = strat
    strat.lab = lab

    results = []
    selected_experts = []
    for _ in range(5):
        expmt = strat.create_experiment(lab.requests)
        if isinstance(expmt, st_expmt.Experiment):
            results.append(expmt)
            selected_experts.append(expmt.experts)

    if len(results) > 0:
        points += 0.2
    else:
        print("\tNo experiment created")

    valid = True
    for expmt in results:
        if expmt.ai_system == ai0 or expmt.protocol == p_invalid:
            print("\tSelected invalid request")
            valid = False

        if not (expmt.ai_system == ai1 and expmt.protocol == p1):
            print("\tDid not select first valid request")
            valid = False

    unique_selections = []
    for sel in selected_experts:
        rep = tuple(sorted(id(e) for e in sel))
        if rep not in unique_selections:
            unique_selections.append(rep)

    if not len(unique_selections) > 1:
        print("\tExperts are not selected randomly (always same selection)")
        valid = False

    if valid:
        points += 0.3

    print(f"Testing ChronologicalStrategy finished: {points:.2f}/0.5 points")
    return points


def test_complex_protocol_strategy():
    print("Testing ComplexProtocolStrategy...")
    points = 0.0

    ling = st_exp.LinguistExpert("Ling", "NLP", "assistant", 0.5)
    ml1 = st_exp.MLResearcher("ML1", "NLP", "associate", 0.6, ["FW"])
    ml2 = st_exp.MLResearcher("ML2", "NLP", "professor", 0.9, ["FW"])
    stat = st_exp.Statistician("Stat", "NLP", "associate", 0.6)
    members = [ling, ml1, ml2]

    p_invalid = st_eval.EvaluationProtocol("Invalid")
    p_invalid.add_step({
        "desc": "S0",
        "duration": 5,
        "requirements": [st_exp.LinguistExpert, st_exp.Statistician]
    })
    p1 = st_eval.EvaluationProtocol("P1")
    p1.add_step({
        "desc": "S1",
        "duration": 3,
        "requirements": [st_exp.LinguistExpert]
    })
    p2 = st_eval.EvaluationProtocol("P2")
    p2.add_step({
        "desc": "S2",
        "duration": 4,
        "requirements": [st_exp.MLResearcher]
    })
    ai0 = st_ai.AISystem("AI0", "NLP", "FW", 0.7)
    ai1 = st_ai.AISystem("AI1", "NLP", "FW", 0.7)
    ai2 = st_ai.AISystem("AI2", "NLP", "FW", 0.7)
    requests = [(ai0, p_invalid), (ai1, p1), (ai2, p2)]

    lab = st_lab.ResearchLab(members, requests)
    strat = st_lab.ComplexProtocolStrategy()
    lab.selection_strategy = strat
    strat.lab = lab

    results = []
    selected_experts = []
    for _ in range(5):
        expmt = strat.create_experiment(lab.requests)
        if isinstance(expmt, st_expmt.Experiment):
            results.append(expmt)
            selected_experts.append(expmt.experts)

    if len(results) > 0:
        points += 0.2
    else:
        print("\tNo experiment created")

    valid = True
    for expmt in results:
        if expmt.ai_system == ai0 or expmt.protocol == p_invalid:
            print("\tSelected invalid request")
            valid = False
        if expmt.ai_system == ai1 or expmt.protocol == p1:
            print("\tSelected invalid request")
            valid = False

        if not (expmt.ai_system == ai2 and expmt.protocol == p2):
            print("\tDid not select first valid request")
            valid = False

    unique_selections = []
    for sel in selected_experts:
        rep = tuple(sorted(id(e) for e in sel))
        if rep not in unique_selections:
            unique_selections.append(rep)

    if not len(unique_selections) > 1:
        print("\tExperts are not selected randomly (always same selection)")
        valid = False

    if valid:
        points += 0.3

    print(f"Testing ComplexProtocolStrategy finished: {points:.2f}/0.5 points")
    return points


def test_efficient_strategy():
    print("Testing EfficientStrategy...")
    points = 0.0

    ling = st_exp.LinguistExpert("Ling", "NLP", "assistant", 0.5)
    ml1 = st_exp.MLResearcher("ML1", "NLP", "associate", 0.6, ["FW"])
    ml2 = st_exp.MLResearcher("ML2", "NLP", "professor", 0.9, ["FW"])
    stat = st_exp.Statistician("Stat", "NLP", "associate", 0.6)
    members = [ling, ml1, ml2]

    p_invalid = st_eval.EvaluationProtocol("Invalid")
    p_invalid.add_step({
        "desc": "S0",
        "duration": 5,
        "requirements": [st_exp.LinguistExpert, st_exp.Statistician]
    })
    p1 = st_eval.EvaluationProtocol("P1")
    p1.add_step({
        "desc": "S1",
        "duration": 3,
        "requirements": [st_exp.LinguistExpert]
    })
    p2 = st_eval.EvaluationProtocol("P2")
    p2.add_step({
        "desc": "S2",
        "duration": 4,
        "requirements": [st_exp.MLResearcher]
    })
    ai0 = st_ai.AISystem("AI0", "NLP", "FW", 0.7)
    ai1 = st_ai.AISystem("AI1", "NLP", "FW", 0.7)
    ai2 = st_ai.AISystem("AI2", "NLP", "FW", 0.7)
    requests = [(ai0, p_invalid), (ai1, p1), (ai2, p2)]

    lab = st_lab.ResearchLab(members, requests)
    strat = st_lab.EfficientStrategy()
    lab.selection_strategy = strat
    strat.lab = lab

    results = []
    selected_experts = []
    for _ in range(5):
        expmt = strat.create_experiment(lab.requests)
        if isinstance(expmt, st_expmt.Experiment):
            results.append(expmt)
            selected_experts.append(expmt.experts)

    if len(results) > 0:
        points += 0.2
    else:
        print("\tNo experiment created")

    valid = True
    for expmt in results:
        if expmt.ai_system == ai0 or expmt.protocol == p_invalid:
            print("\tSelected invalid request")
            valid = False
        if expmt.ai_system == ai1 or expmt.protocol == p1:
            print("\tSelected invalid request")
            valid = False

        if not (expmt.ai_system == ai2 and expmt.protocol == p2):
            print("\tDid not select first valid request")
            valid = False

    for selection in selected_experts:
        if ml2 not in selection or ml1 in selection:
            print("\tYou did not select the most senior available expert")
            valid = False

    if valid:
        points += 0.3

    print(f"Testing EfficientStrategy finished: {points:.2f}/0.5 points")
    return points


if __name__ == "__main__":
    total = 0.0

    # ResearchLab
    total += test_get_available_experts()
    total += test_get_unsolved_requests()
    total += test_can_run_protocol()
    total += test_run_simulation()

    # Strategies
    total += test_create_experiment_base()
    total += test_chronological_strategy()
    total += test_complex_protocol_strategy()
    total += test_efficient_strategy()

    print("\n=========================")
    print(f"TOTAL: {total:.2f}/3.0 points")
