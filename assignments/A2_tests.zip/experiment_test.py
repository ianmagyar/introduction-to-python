import experiment as st_expmt
import evaluation as st_eval
import expert as st_exp
import ai_system as st_ai
import lab as st_lab


def test_structure(obj, should_have):
    attribute_list = dir(obj)
    for att in should_have:
        if att not in attribute_list:
            print(f"\tMissing attribute {att} in object {obj}.")
            return False
    return True


def test_experiment_constructor():
    print("Testing Experiment constructor...")
    points = 0.0

    ling = st_exp.LinguistExpert("Ling", "NLP", "assistant", 0.5)
    ml = st_exp.MLResearcher("ML", "NLP", "associate", 0.6, ["FW"])
    stat = st_exp.Statistician("Stat", "NLP", "associate", 0.6)

    experts = [ling, ml, stat]

    protocol = st_eval.EvaluationProtocol("Test Protocol")

    protocol.add_step({
        "desc": "Step 1",
        "duration": 5,
        "requirements": [st_exp.LinguistExpert]
    })

    protocol.add_step({
        "desc": "Step 2",
        "duration": 4,
        "requirements": [st_exp.MLResearcher]
    })

    protocol.add_step({
        "desc": "Step 3",
        "duration": 3,
        "requirements": [st_exp.Statistician]
    })

    ai = st_ai.AISystem("AI", "NLP", "FW", 0.7)

    lab = st_lab.ResearchLab(experts, [])

    try:
        expmt = st_expmt.Experiment(lab, protocol, ai, experts)
    except Exception as e:
        print("\tConstructor raised unexpected exception:")
        print(e)
        return points

    if test_structure(expmt, ["lab", "protocol", "ai_system", "experts", "remaining_hours_per_step"]):
        points += 0.1

    correct = True
    if expmt.lab != lab:
        print("\tIncorrect lab assignment")
        correct = False

    if expmt.protocol != protocol:
        print("\tIncorrect protocol assignment")
        correct = False

    if expmt.ai_system != ai:
        print("\tIncorrect AI system assignment")
        correct = False

    for exp in experts:
        if exp not in expmt.experts:
            print("\tIncorrect experts list")
            correct = False

    if correct:
        points += 0.1

    steps = protocol.steps

    if len(expmt.remaining_hours_per_step) != len(steps):
        print("\tIncorrect number of steps in remaining_hours_per_step")
    else:
        valid = True

        for step in steps:
            if step not in expmt.remaining_hours_per_step:
                print("\tMissing step in remaining_hours_per_step")
                valid = False
                continue

            expected_hours = None
            for expert in experts:
                if type(expert) in step.experts:
                    expected_hours = expert.estimate_step_duration(step.duration)
                    break

            if expmt.remaining_hours_per_step[step] != expected_hours:
                print("\tIncorrect remaining hours for step")
                valid = False

        if valid:
            points += 0.3

    print(f"Testing Experiment constructor finished: {points:.2f}/0.5 points")
    return points


def test_simulate_day():
    print("Testing Experiment.simulate_day()...")
    points = 0.0

    ling = st_exp.LinguistExpert("Ling", "NLP", "assistant", 0.5)
    experts = [ling]

    protocol = st_eval.EvaluationProtocol("Test Protocol")

    protocol.add_step({
        "desc": "Step 1",
        "duration": 5,
        "requirements": [st_exp.LinguistExpert]
    })

    protocol.add_step({
        "desc": "Step 2",
        "duration": 3,
        "requirements": [st_exp.LinguistExpert]
    })

    ai = st_ai.AISystem("AI", "NLP", "FW", 0.7)
    lab = st_lab.ResearchLab(experts, [])

    expmt = st_expmt.Experiment(lab, protocol, ai, experts)

    steps = protocol.get_steps()

    initial_values = {step: expmt.remaining_hours_per_step[step] for step in steps}

    expmt.simulate_day()

    correct_day1 = True
    for step in steps:
        expected = max(0, initial_values[step] - 6)  # 1 expert × 6 hours
        if expmt.remaining_hours_per_step[step] != expected:
            print("\tDay 1: incorrect update")
            correct_day1 = False

    if correct_day1:
        points += 0.1

    prev_values = expmt.remaining_hours_per_step.copy()
    expmt.simulate_day()

    correct_day2 = True

    for step in steps:
        expected = max(0, prev_values[step] - 6)
        if expmt.remaining_hours_per_step[step] != expected:
            print("\tDay 2: incorrect update")
            correct_day2 = False

    if correct_day2:
        points += 0.1

    for _ in range(5):
        expmt.simulate_day()

    all_zero = True

    for step in steps:
        if expmt.remaining_hours_per_step[step] != 0:
            print("\tHours should not go below zero")
            all_zero = False

    if all_zero:
        points += 0.2

    print(f"Testing simulate_day finished: {points:.2f}/0.4 points")
    return points


def test_is_finished():
    print("Testing Experiment.is_finished()...")
    points = 0.0

    ling = st_exp.LinguistExpert("Ling", "NLP", "assistant", 0.5)
    experts = [ling]

    protocol = st_eval.EvaluationProtocol("Test Protocol")

    protocol.add_step({
        "desc": "Step 1",
        "duration": 5,
        "requirements": [st_exp.LinguistExpert]
    })

    protocol.add_step({
        "desc": "Step 2",
        "duration": 3,
        "requirements": [st_exp.LinguistExpert]
    })

    ai = st_ai.AISystem("AI", "NLP", "FW", 0.7)
    lab = st_lab.ResearchLab(experts, [])

    expmt = st_expmt.Experiment(lab, protocol, ai, experts)

    steps = protocol.get_steps()

    expmt.remaining_hours_per_step = {
        steps[0]: 0,
        steps[1]: 5
    }

    try:
        res = expmt.is_finished()
    except Exception as e:
        print("\tError in is_finished():")
        print(e)
    else:
        if res is False:
            points += 0.1
        else:
            print("\tShould return False when some hours remain")

    expmt.remaining_hours_per_step = {
        steps[0]: 0,
        steps[1]: 0
    }

    try:
        res = expmt.is_finished()
    except Exception as e:
        print("\tError in is_finished():")
        print(e)
    else:
        if res is True:
            points += 0.1
        else:
            print("\tShould return True when all hours are zero")

    print(f"Testing is_finished finished: {points:.2f}/0.2 points")
    return points


def test_compute_results():
    print("Testing Experiment.compute_results()...")
    points = 0.0

    ling = st_exp.LinguistExpert("Ling", "NLP", "assistant", 0.5)
    ml = st_exp.MLResearcher("ML", "NLP", "associate", 0.6, ["FW"])
    stat = st_exp.Statistician("Stat", "NLP", "associate", 0.6)

    experts = [ling, ml, stat]

    protocol = st_eval.EvaluationProtocol("Test Protocol")

    protocol.add_step({
        "desc": "Linguistic analysis",
        "duration": 4,
        "requirements": [st_exp.LinguistExpert]
    })
    protocol.add_step({
        "desc": "ML validation",
        "duration": 5,
        "requirements": [st_exp.MLResearcher]
    })
    protocol.add_step({
        "desc": "Final aggregation",
        "duration": 3,
        "requirements": [st_exp.Statistician]
    })

    ai = st_ai.AISystem("AI", "NLP", "FW", 0.7)
    lab = st_lab.ResearchLab(experts, [])
    expmt = st_expmt.Experiment(lab, protocol, ai, experts)

    try:
        result = expmt.compute_results()
    except Exception as e:
        print("\tError calling compute_results():")
        print(e)
        return points

    expected_keys = ["quality", "linguist", "MLexpert", "statistician"]

    if all(k in result for k in expected_keys):
        points += 0.1
    else:
        print("\tMissing keys in result")

    try:
        ai_obj, quality_val = result["quality"]
        if ai_obj == ai and isinstance(quality_val, float):
            points += 0.1
        else:
            print("\tInvalid quality entry")
    except:
        print("\tMalformed quality entry")

    try:
        ling_obj, ling_val = result["linguist"]
        if isinstance(ling_obj, st_exp.LinguistExpert) and isinstance(ling_val, float):
            if 0 <= ling_val <= 1:
                points += 0.1
            else:
                print("\tLinguist score out of bounds")
        else:
            print("\tInvalid linguist entry")
    except:
        print("\tMalformed linguist entry")

    try:
        ml_obj, ml_data = result["MLexpert"]

        if isinstance(ml_obj, st_exp.MLResearcher) and isinstance(ml_data, dict):
            keys_ok = all(k in ml_data for k in ["coherences", "consistencies", "variability"])

            if not keys_ok:
                print("\tMissing keys in MLexpert data")
            else:
                coherences = ml_data["coherences"]
                consistencies = ml_data["consistencies"]
                variability = ml_data["variability"]

                valid = True

                if not (isinstance(coherences, list) and len(coherences) > 0):
                    print("\tInvalid coherences list")
                    valid = False

                if not (isinstance(consistencies, list) and len(consistencies) > 0):
                    print("\tInvalid consistencies list")
                    valid = False

                if not (isinstance(variability, float) and variability >= 0):
                    print("\tInvalid variability value")
                    valid = False

                if valid:
                    points += 0.2
        else:
            print("\tInvalid MLexpert entry")
    except:
        print("\tMalformed MLexpert entry")

    try:
        stat_obj, stat_val = result["statistician"]
        if isinstance(stat_obj, st_exp.Statistician) and isinstance(stat_val, float):
            if 0 <= stat_val <= 1:
                points += 0.1
            else:
                print("\tStatistician score out of bounds")
        else:
            print("\tInvalid statistician entry")
    except:
        print("\tMalformed statistician entry")

    print(f"Testing compute_results finished: {points:.2f}/0.6 points")
    return points


def test_employs():
    print("Testing Experiment.employs()...")
    points = 0.0


    ling = st_exp.LinguistExpert("Ling", "NLP", "assistant", 0.5)
    ling2 = st_exp.LinguistExpert("Ling2", "law", "associate", 0.7)
    ml = st_exp.MLResearcher("ML", "NLP", "associate", 0.6, ["FW"])
    stat = st_exp.Statistician("Stat", "NLP", "associate", 0.6)
    stat2 = st_exp.Statistician("Stat2", "law", "assistant", 0.4)

    experts = [ling, ml]

    protocol = st_eval.EvaluationProtocol("Test Protocol")
    protocol.add_step({
        "desc": "Step",
        "duration": 3,
        "requirements": [st_exp.LinguistExpert]
    })

    ai = st_ai.AISystem("AI", "NLP", "FW", 0.7)
    lab = st_lab.ResearchLab(experts, [])

    expmt = st_expmt.Experiment(lab, protocol, ai, experts)

    test_cases = [
        (ling, True),
        (ling2, False),
        (ml, True),
        (stat, False),
        (stat2, False)
    ]

    for expert, expected in test_cases:
        try:
            res = expmt.employs(expert)
        except Exception as e:
            print("\tError in employs():")
            print(e)
            continue

        if res == expected:
            points += 0.02
        else:
            print(f"\tIncorrect result for employs({expert}), expected {expected}, got {res}")

    print(f"Testing employs finished: {points:.2f}/0.1 point")
    return points


def test_tests():
    print("Testing Experiment.tests()...")
    points = 0.0

    ling = st_exp.LinguistExpert("Ling", "NLP", "assistant", 0.5)
    experts = [ling]

    protocol = st_eval.EvaluationProtocol("Protocol A")
    protocol.add_step({
        "desc": "Step",
        "duration": 3,
        "requirements": [st_exp.LinguistExpert]
    })

    ai = st_ai.AISystem("AI", "NLP", "FW", 0.7)

    lab = st_lab.ResearchLab(experts, [])
    expmt = st_expmt.Experiment(lab, protocol, ai, experts)

    other_ai = st_ai.AISystem("Other", "NLP", "FW", 0.7)

    other_protocol = st_eval.EvaluationProtocol("Protocol B")
    other_protocol.add_step({
        "desc": "Step",
        "duration": 3,
        "requirements": [st_exp.LinguistExpert]
    })

    test_cases = [
        (ai, protocol, True),
        (other_ai, protocol, False),
        (ai, other_protocol, False),
        (other_ai, other_protocol, False)
    ]

    for sys, prot, expected in test_cases:
        try:
            res = expmt.tests(sys, prot)
        except Exception as e:
            print("\tError in tests():")
            print(e)
            continue

        if res == expected:
            points += 0.05
        else:
            print(f"\tIncorrect result for tests({sys}, {prot}). Expected {expected}, got {res}")

    print(f"Testing tests finished: {points:.2f}/0.2 points")
    return points


if __name__ == "__main__":
    total = 0.0

    total += test_experiment_constructor()
    total += test_simulate_day()
    total += test_is_finished()
    total += test_compute_results()
    total += test_employs()
    total += test_tests()

    print("\n=========================")
    print(f"TOTAL: {total:.2f}/2.0 points")
