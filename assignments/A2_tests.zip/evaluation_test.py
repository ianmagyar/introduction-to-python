import evaluation as st_eval
import expert as st_exp


def test_structure(obj, should_have):
    attribute_list = dir(obj)
    for att in should_have:
        if att not in attribute_list:
            print(f"\tMissing attribute {att} in object {obj}.")
            return False
    return True


def test_step_constructor():
    print("Testing Step constructor...")
    points = 0.0

    desc = "Test step"
    duration = 5
    experts = [st_exp.LinguistExpert, st_exp.MLResearcher]

    try:
        step = st_eval.Step(desc, duration, experts)
    except Exception as e:
        print("\tConstructor raised unexpected exception:")
        print(e)
    else:
        if test_structure(step, ["step_desc", "duration", "experts"]):
            if step.step_desc == desc and step.duration == duration and step.experts == experts:
                points = 0.1
            else:
                print("\tAttributes not set correctly:")
                print(f"\tstep_desc: expected {desc}, got {step.step_desc}")
                print(f"\tduration: expected {duration}, got {step.duration}")
                print(f"\texperts: expected {experts}, got {step.experts}")

    print(f"Testing Step constructor finished: {points:.2f}/0.1 points")
    return points


def test_step_methods():
    print("Testing Step methods...")
    points = 0.0

    test_cases = [
        ([st_exp.LinguistExpert], st_exp.LinguistExpert, True),
        ([st_exp.LinguistExpert], st_exp.MLResearcher, False),
        ([st_exp.MLResearcher], st_exp.MLResearcher, True),
        ([st_exp.MLResearcher], st_exp.Statistician, False),
        ([st_exp.Statistician], st_exp.Statistician, True),
        ([st_exp.Statistician], st_exp.LinguistExpert, False),
        ([st_exp.LinguistExpert, st_exp.MLResearcher], st_exp.LinguistExpert, True),
        ([st_exp.LinguistExpert, st_exp.MLResearcher], st_exp.MLResearcher, True),
        ([st_exp.LinguistExpert, st_exp.MLResearcher], st_exp.Statistician, False),
        ([st_exp.LinguistExpert, st_exp.MLResearcher, st_exp.Statistician], st_exp.Statistician, True),
    ]

    for experts, query, expected in test_cases:
        step = st_eval.Step("desc", 5, experts)

        try:
            result = step.can_contribute(query)
        except Exception as e:
            print("\tError when calling can_contribute:")
            print(e)
            continue

        if result == expected:
            points += 0.01
        else:
            print(f"\tWrong result for experts={experts}, query={query}: expected {expected}, got {result}")

    print(f"Testing Step methods finished: {points:.2f}/0.1 points")
    return points


def test_protocol_constructor():
    print("Testing EvaluationProtocol constructor...")
    points = 0.0

    name = "Test Protocol"

    try:
        protocol = st_eval.EvaluationProtocol(name)
    except Exception as e:
        print("\tConstructor raised unexpected exception:")
        print(e)
    else:
        if test_structure(protocol, ["protocol_name", "steps", "required_experts"]):
            correct = True

            if protocol.protocol_name != name:
                print(f"\tIncorrect protocol_name: expected {name}, got {protocol.protocol_name}")
                correct = False

            if not isinstance(protocol.steps, list) or len(protocol.steps) != 0:
                print(f"\tsteps should be an empty list, got {protocol.steps}")
                correct = False

            if not isinstance(protocol.required_experts, dict) or len(protocol.required_experts) != 0:
                print(f"\trequired_experts should be an empty dict, got {protocol.required_experts}")
                correct = False

            if correct:
                points = 0.1

    print(f"Testing EvaluationProtocol constructor finished: {points:.2f}/0.1 points")
    return points


def test_add_step():
    print("Testing EvaluationProtocol.add_step()...")
    points = 0.0

    protocol = st_eval.EvaluationProtocol("Test Protocol")

    valid_steps = [
        ("Step 1", 5, [st_exp.LinguistExpert]),
        ("Step 2", 3, [st_exp.MLResearcher]),
        ("Step 3", 7, [st_exp.Statistician]),
        ("Step 4", 4, [st_exp.LinguistExpert, st_exp.MLResearcher]),
    ]

    for i, (desc, duration, reqs) in enumerate(valid_steps):
        try:
            protocol.add_step({
                "desc": desc,
                "duration": duration,
                "requirements": reqs
            })
        except Exception as e:
            print(f"\tError when adding valid step {i+1}:")
            print(e)
            continue

        if len(protocol.steps) != i + 1:
            print(f"\tStep {i+1} was not added correctly")
            continue

        step = protocol.steps[-1]
        correct = True

        if step.step_desc != desc:
            print(f"\tStep {i+1}: wrong description")
            correct = False

        if step.duration != duration:
            print(f"\tStep {i+1}: wrong duration")
            correct = False

        if step.experts != reqs:
            print(f"\tStep {i+1}: wrong experts list")
            correct = False

        if step not in protocol.required_experts:
            print(f"\tStep {i+1}: missing in required_experts")
            correct = False
        elif protocol.required_experts[step] != reqs:
            print(f"\tStep {i+1}: wrong required_experts value")
            correct = False

        if correct:
            points += 0.05

    invalid_cases = [
        {"desc": "Bad 1", "duration": 0, "requirements": [st_exp.LinguistExpert]},
        {"desc": "Bad 2", "duration": -5, "requirements": [st_exp.MLResearcher]},
        {"desc": "Bad 3", "duration": 3.5, "requirements": [st_exp.Statistician]},
    ]

    error_points = 0.0

    for case in invalid_cases:
        try:
            protocol.add_step(case)
        except ValueError as e:
            if str(e) == "Step duration must be an integer and at least 1":
                error_points += 0.033
            else:
                print("\tWrong error message:", e)
        except Exception as e:
            print("\tWrong exception type:", type(e))
        else:
            print("\tMissing exception for invalid duration")

    points += error_points

    print(f"Testing add_step finished: {points:.2f}/0.3 points")
    return points


def test_get_all_experts():
    print("Testing EvaluationProtocol.get_all_experts()...")
    points = 0.0

    test_cases = [
        (
            [("Step 1", 5, [st_exp.LinguistExpert])],
            [st_exp.LinguistExpert]
        ),
        (
            [
                ("Step 1", 5, [st_exp.LinguistExpert]),
                ("Step 2", 3, [st_exp.MLResearcher]),
            ],
            [st_exp.LinguistExpert, st_exp.MLResearcher]
        ),
        (
            [
                ("Step 1", 5, [st_exp.LinguistExpert]),
                ("Step 2", 3, [st_exp.LinguistExpert, st_exp.MLResearcher]),
            ],
            [st_exp.LinguistExpert, st_exp.MLResearcher]
        ),
        (
            [
                ("Step 1", 5, [st_exp.LinguistExpert, st_exp.MLResearcher]),
                ("Step 2", 4, [st_exp.MLResearcher, st_exp.Statistician]),
                ("Step 3", 2, [st_exp.LinguistExpert, st_exp.Statistician]),
            ],
            [st_exp.LinguistExpert, st_exp.MLResearcher, st_exp.Statistician]
        ),
    ]

    for i, (steps_data, expected) in enumerate(test_cases):
        protocol = st_eval.EvaluationProtocol("Test Protocol")

        for desc, duration, reqs in steps_data:
            protocol.add_step({
                "desc": desc,
                "duration": duration,
                "requirements": reqs
            })

        try:
            result = protocol.get_all_experts()
        except Exception as e:
            print(f"\tRun {i+1}: Error calling get_all_experts():")
            print(e)
            continue

        correct = True

        if len(result) != len(expected):
            print(f"\tRun {i+1}: Wrong number of experts (expected {len(expected)}, got {len(result)})")
            correct = False

        for exp in expected:
            if exp not in result:
                print(f"\tRun {i+1}: Missing expert {exp}")
                correct = False

        if correct:
            points += 0.05
        else:
            print(f"\tRun {i+1}: Result was {result}")

    print(f"Testing get_all_experts finished: {points:.2f}/0.2 points")
    return points


def test_get_total_duration():
    print("Testing EvaluationProtocol.get_total_duration()...")
    points = 0.0

    test_cases = [
        (
            [("Step 1", 5, [st_exp.LinguistExpert])],
            5
        ),
        (
            [
                ("Step 1", 5, [st_exp.LinguistExpert]),
                ("Step 2", 3, [st_exp.MLResearcher]),
            ],
            8
        ),
        (
            [
                ("Step 1", 7, [st_exp.Statistician]),
                ("Step 2", 4, [st_exp.LinguistExpert]),
                ("Step 3", 2, [st_exp.MLResearcher]),
            ],
            13
        ),
        (
            [
                ("Step 1", 10, [st_exp.LinguistExpert, st_exp.MLResearcher]),
                ("Step 2", 6, [st_exp.MLResearcher, st_exp.Statistician]),
            ],
            16
        ),
        (
            [
                ("Step 1", 1, [st_exp.LinguistExpert]),
                ("Step 2", 2, [st_exp.MLResearcher]),
                ("Step 3", 3, [st_exp.Statistician]),
                ("Step 4", 4, [st_exp.LinguistExpert]),
            ],
            10
        ),
    ]

    for i, (steps_data, expected) in enumerate(test_cases):
        protocol = st_eval.EvaluationProtocol("Test Protocol")

        for desc, duration, reqs in steps_data:
            protocol.add_step({
                "desc": desc,
                "duration": duration,
                "requirements": reqs
            })

        try:
            result = protocol.get_total_duration()
        except Exception as e:
            print(f"\tRun {i+1}: Error calling get_total_duration():")
            print(e)
            continue

        if result == expected:
            points += 0.02
        else:
            print(f"\tRun {i+1}: Incorrect result (expected {expected}, got {result})")

    print(f"Testing get_total_duration finished: {points:.2f}/0.1 points")
    return points


def test_get_hours_for_expert():
    print("Testing EvaluationProtocol.get_hours_for_expert()...")
    points = 0.0

    test_cases = [
        (
            [
                ("Step 1", 5, [st_exp.LinguistExpert]),
                ("Step 2", 3, [st_exp.LinguistExpert]),
                ("Step 3", 2, [st_exp.MLResearcher]),
            ],
            st_exp.LinguistExpert("L", "NLP", "assistant", 0.5),
            8
        ),
        (
            [
                ("Step 1", 4, [st_exp.MLResearcher]),
                ("Step 2", 6, [st_exp.MLResearcher]),
                ("Step 3", 3, [st_exp.LinguistExpert]),
            ],
            st_exp.MLResearcher("M", "NLP", "associate", 0.6, []),
            10
        ),
        (
            [
                ("Step 1", 2, [st_exp.Statistician]),
                ("Step 2", 3, [st_exp.Statistician]),
                ("Step 3", 4, [st_exp.Statistician]),
            ],
            st_exp.Statistician("S", "NLP", "associate", 0.6),
            9
        ),
        (
            [
                ("Step 1", 5, [st_exp.LinguistExpert, st_exp.MLResearcher]),
                ("Step 2", 7, [st_exp.LinguistExpert]),
                ("Step 3", 4, [st_exp.MLResearcher]),
            ],
            st_exp.LinguistExpert("L", "NLP", "assistant", 0.5),
            12
        ),
        (
            [
                ("Step 1", 6, [st_exp.MLResearcher, st_exp.Statistician]),
                ("Step 2", 2, [st_exp.Statistician]),
                ("Step 3", 5, [st_exp.LinguistExpert]),
            ],
            st_exp.Statistician("S", "NLP", "associate", 0.6),
            8
        ),
    ]

    for i, (steps_data, expert, expected) in enumerate(test_cases):
        protocol = st_eval.EvaluationProtocol("Test Protocol")

        for desc, duration, reqs in steps_data:
            protocol.add_step({
                "desc": desc,
                "duration": duration,
                "requirements": reqs
            })

        try:
            result = protocol.get_hours_for_expert(expert)
        except Exception as e:
            print(f"\tRun {i+1}: Error calling get_hours_for_expert():")
            print(e)
            continue

        if result == expected:
            points += 0.02
        else:
            print(f"\tRun {i+1}: Incorrect result (expected {expected}, got {result})")

    print(f"Testing get_hours_for_expert finished: {points:.2f}/0.1 points")
    return points


if __name__ == "__main__":
    total = 0.0

    # Step
    total += test_step_constructor()
    total += test_step_methods()

    # EvaluationProtocol
    total += test_protocol_constructor()
    total += test_add_step()
    total += test_get_all_experts()
    total += test_get_total_duration()
    total += test_get_hours_for_expert()

    print("\n=========================")
    print(f"TOTAL: {total:.2f}/1.0 points")