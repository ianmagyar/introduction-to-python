import ai_system as st_ai
import random

def test_structure(obj, should_have):
    attribute_list = dir(obj)
    for att in should_have:
        if att not in attribute_list:
            print(f"\tMissing attribute {att} in object {obj}.")
            return False
    return True

def test_ai_system_constructor():
    print("Testing AISystem constructor...")
    points = 0.0

    name = "TestAI"
    specialization = "NLP"
    framework = "PyTorch"
    quality = 0.75

    try:
        ai = st_ai.AISystem(name, specialization, framework, quality)
    except Exception as e:
        print("\tConstructor raised unexpected exception:")
        print(e)
    else:
        if test_structure(ai, ["name", "specialization", "framework", "quality"]):
            points += 0.05

            if ai.name == name:
                points += 0.0125
            else:
                print(f"\tIncorrect name: expected {name}, got {ai.name}")

            if ai.specialization == specialization:
                points += 0.0125
            else:
                print(f"\tIncorrect specialization: expected {specialization}, got {ai.specialization}")

            if ai.framework == framework:
                points += 0.0125
            else:
                print(f"\tIncorrect framework: expected {framework}, got {ai.framework}")

            if ai.quality == quality:
                points += 0.0125
            else:
                print(f"\tIncorrect quality: expected {quality}, got {ai.quality}")

    print(f"Testing AISystem constructor finished: {points:.2f}/0.1 points")
    return points


def compute_variance(values):
    mean = sum(values) / len(values)
    return sum((x - mean) ** 2 for x in values) / len(values)


def test_simulate_dialogue():
    print("Testing AISystem.simulate_dialogue()...")
    points = 0.0

    quality = random.uniform(0.5, 0.9)
    ai = st_ai.AISystem("AI", "NLP", "TF", quality)

    N = 200
    coherences = []
    consistencies = []
    grammar_errors = []
    vocabularies = []

    try:
        for _ in range(N):
            res = ai.simulate_dialogue()

            try:
                coherences.append(res["coherence"])
            except KeyError:
                print("\tDid not find coherence in function result")

            try:
                consistencies.append(res["consistency"])
            except KeyError:
                print("\tDid not find consistency in function result")

            try:
                grammar_errors.append(res["grammar_errors"])
            except KeyError:
                print("\tDid not find grammar_errors in function result")

            try:
                vocabularies.append(res["vocabulary_richness"])
            except KeyError:
                print("\tDid not find vocabulary_richness in function result")
    except Exception as e:
        print("\tMethod raised unexpected exception:")
        print(e)
        return points

    if len(coherences) == N:
        points += 0.01
    if len(consistencies) == N:
        points += 0.01
    if len(grammar_errors) == N:
        points += 0.01
    if len(vocabularies) == N:
        points += 0.01

    if all(0 <= x <= 1 for x in coherences):
        points += 0.01
    else:
        print("\tCoherence values out of bounds")

    if all(0 <= x <= 1 for x in consistencies):
        points += 0.01
    else:
        print("\tConsistency values out of bounds")

    if all(isinstance(x, int) and x >= 0 for x in grammar_errors):
        points += 0.01
    else:
        print("\tGrammar errors invalid")

    if all(0 <= x <= 1 for x in vocabularies):
        points += 0.01
    else:
        print("\tVocabulary richness out of bounds")

    mean_coh = sum(coherences) / N
    mean_cons = sum(consistencies) / N
    mean_gram = sum(grammar_errors) / N
    mean_vocab = sum(vocabularies) / N

    if abs(mean_coh - quality) < 0.1:
        points += 0.02
    else:
        print(f"\tCoherence mean incorrect: expected ~{quality}, got {mean_coh:.3f}")

    if abs(mean_cons - quality) < 0.1:
        points += 0.02
    else:
        print(f"\tConsistency mean incorrect: expected ~{quality}, got {mean_cons:.3f}")

    expected_grammar = 10 * (1 - quality)
    if abs(mean_gram - expected_grammar) < 2:
        points += 0.02
    else:
        print(f"\tGrammar mean incorrect: expected ~{expected_grammar}, got {mean_gram:.3f}")

    expected_vocab = 0.5 + 0.5 * quality
    if abs(mean_vocab - expected_vocab) < 0.1:
        points += 0.02
    else:
        print(f"\tVocabulary mean incorrect: expected ~{expected_vocab}, got {mean_vocab:.3f}")

    var_coh = compute_variance(coherences)
    var_cons = compute_variance(consistencies)
    var_gram = compute_variance(grammar_errors)
    var_vocab = compute_variance(vocabularies)

    # Expected variances (approx):
    # coherence ~ sigma=0.1 → var ≈ 0.01
    # consistency ~ sigma=0.07 → var ≈ 0.005
    # grammar_errors ~ sigma=1 → var ≈ 1
    # vocabulary ~ sigma=0.1 → var ≈ 0.01

    # Coherence
    if 0.002 < var_coh < 0.03:
        points += 0.01
    else:
        print(f"\tCoherence variance suspicious: {var_coh:.4f}")

    # Consistency
    if 0.001 < var_cons < 0.02:
        points += 0.01
    else:
        print(f"\tConsistency variance suspicious: {var_cons:.4f}")

    # Grammar errors
    if 0.2 < var_gram < 5:
        points += 0.01
    else:
        print(f"\tGrammar errors variance suspicious: {var_gram:.4f}")

    # Vocabulary richness
    if 0.002 < var_vocab < 0.03:
        points += 0.01
    else:
        print(f"\tVocabulary variance suspicious: {var_vocab:.4f}")

    print(f"Testing AISystem.simulate_dialogue() finished: {points:.2f}/0.2 points")
    return points


def test_get_dialogue_metrics():
    print("Testing AISystem.get_dialogue_metrics()...")
    points = 0.0

    TEST_RUNS = 20

    for i in range(TEST_RUNS):
        quality = random.uniform(0.2, 0.9)
        n_dialogues = random.randint(30, 120)

        ai = st_ai.AISystem("AI", "NLP", "TF", quality)

        try:
            res = ai.get_dialogue_metrics(n_dialogues)
        except Exception as e:
            print(f"\tRun {i+1}: Method raised unexpected exception:")
            print(e)
            continue

        expected_keys = ["coherence", "consistency", "grammar_errors", "vocabulary_richness"]
        if not all(k in res for k in expected_keys):
            print(f"\tRun {i+1}: Missing keys in result {res}")
            continue

        expected_coh = quality
        expected_cons = quality
        expected_gram = 10 * (1 - quality)
        expected_vocab = 0.5 + 0.5 * quality

        ok = True

        if abs(res["coherence"] - expected_coh) >= 0.12:
            print(f"\tRun {i+1}: Coherence off (expected ~{expected_coh:.2f}, got {res['coherence']:.3f})")
            ok = False

        if abs(res["consistency"] - expected_cons) >= 0.12:
            print(f"\tRun {i+1}: Consistency off (expected ~{expected_cons:.2f}, got {res['consistency']:.3f})")
            ok = False

        if abs(res["grammar_errors"] - expected_gram) >= 3:
            print(f"\tRun {i+1}: Grammar errors off (expected ~{expected_gram:.2f}, got {res['grammar_errors']})")
            ok = False

        if abs(res["vocabulary_richness"] - expected_vocab) >= 0.12:
            print(f"\tRun {i+1}: Vocabulary off (expected ~{expected_vocab:.2f}, got {res['vocabulary_richness']:.3f})")
            ok = False

        if ok:
            points += 0.01

    print(f"Testing AISystem.get_dialogue_metrics() finished: {points:.2f}/0.2 points")
    return points


if __name__ == "__main__":
    total = 0
    total += test_ai_system_constructor()
    total += test_simulate_dialogue()
    total += test_get_dialogue_metrics()

    print(f"\nTOTAL: {total:.2f}/0.5 points")
