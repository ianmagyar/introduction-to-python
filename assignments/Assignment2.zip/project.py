class Project:
    def __init__(self, company, order, started, employees):
        pass

    def update(self):
        pass

    def is_finished(self):
        return False

    def clear_project(self):
        pass

    def get_income(self):
        return 0.0


if __name__ == '__main__':
    # you can do some independent testing here
    pass
