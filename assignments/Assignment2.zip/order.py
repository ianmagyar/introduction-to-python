class Order:
    def __init__(self, client, offer, active, total_hours):
        pass

    def set_tasks(self, development, testing):  # 0.2
        pass

    def add_required_technologies(self, technologies):  # 0.2
        pass


if __name__ == '__main__':
    # you can do some independent testing here
    pass
