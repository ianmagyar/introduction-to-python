class Experiment:
    def __init__(self, lab, protocol, ai_system, experts):
        pass

    def simulate_day(self):
        pass

    def is_finished(self):
        return True

    def compute_results(self):
        return dict()

    def employs(self, expert):
        return True

    def tests(self, ai_system, protocol):
        return True
