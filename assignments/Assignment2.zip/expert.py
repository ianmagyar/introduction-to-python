class Expert:
    def __init__(self, name, specialization, seniority, reliability):
        pass

    def estimate_step_duration(self, base_hours):
        return 0

    def compute_reliability_weight(self, system_specialization):
        return 0.0


class LinguistExpert:
    def __init__(self, name, specialization, seniority, reliability):
        pass

    def evaluate_dialogue(self, dialogue_metrics):
        return 0.0

    def estimate_step_duration(self, base_hours):
        return 0


class MLResearcher:
    def __init__(self, name, specialization, seniority, reliability, frameworks):
        pass

    def knows_framework(self, framework):
        return False

    def variance(self, values):
        mean = sum(values) / len(values)
        squared_diff = [(x - mean) ** 2 for x in values]

        return sum(squared_diff) / len(values)

    def validate_model(self, ai_system, hours):
        return dict()


class Statistician:
    def __init__(self, name, specialization, seniority, reliability):
        pass

    def aggregate_scores(self, metric_dict):
        return 0.0
