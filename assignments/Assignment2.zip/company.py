class Company:
    def __init__(self, employees, scheduler):
        self.employees = employees
        self.active_projects = []
        self.finished_projects = []
        self.scheduler = scheduler
        self.scheduler.set_company(self)

    def calculate_total_income(self):
        return 0.0

    def get_available_employees(self, emp_type):
        return []

    def get_lang_developers(self, language):
        return []

    def is_frequent_client(self, client_name):
        return False

    def close_project(self, project):
        pass

    def solving(self, order):
        return False

    def can_solve_order(self, order):
        return False

    def simulate_day(self, day_no):
        pass


if __name__ == '__main__':
    # you can do some independent testing here
    pass
