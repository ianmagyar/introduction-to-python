def load_example(file_path):  # 2
    return


def get_avg_satisfaction(employees, car_no):  # 0.5
    return


def get_all_seatings(employees, car_no):  # 2
    return


def get_optimal_satisfaction(employees, car_no):  # 0.5
    return


def get_seating_order(employees, car_no):  # 1
    return
