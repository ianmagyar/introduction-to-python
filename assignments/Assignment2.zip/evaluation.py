class Step:
    def __init__(self, step_desc, duration, req):
        pass

    def can_contribute(self, expert_type):
        return False


class EvaluationProtocol:
    def __init__(self, protocol_name):
        pass

    def add_step(self, step_info):
        pass

    def get_all_experts(self):
        return []

    def get_total_duration(self):
        return 0

    def get_hours_for_expert(self, expert):
        return 0
