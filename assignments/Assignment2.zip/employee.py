class Employee:  # 3 points
    def __init__(self, driver, front_seater=True):  # 0.25
        pass

    def set_contacts(self, contacts):  # 0.25
        pass

    def get_car_weight(self, car):  # 0.5
        return

    def get_satisfaction(self, car):  # 0.5
        return

    def choose_car(self, cars):  # 0.5
        return

    def take_seat(self, cars):  # 1
        return
