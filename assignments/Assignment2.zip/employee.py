class Employee:
    def __init__(self, name, level, wage):
        pass


class Tester:
    def __init__(self, name, level, wage):
        pass


class Developer:
    def __init__(self, name, level, wage, languages):
        pass

    def can_program(self, language):
        return False


class Manager:
    def __init__(self, name, level, wage):
        pass

    def get_project_time(self, orig_time):
        return 0


if __name__ == '__main__':
    # you can do some independent testing here
    pass
