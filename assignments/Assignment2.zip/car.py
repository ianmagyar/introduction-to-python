class Car:  # 1 point
    def __init__(self):  # 0.1
        pass

    def has_driver(self):  # 0.1
        return

    def has_empty_front(self):  # 0.1
        return

    def has_empty_back(self):  # 0.1
        return

    def get_number_of_empty(self):  # 0.1
        return

    def add_passenger(self, p, pos):  # 0.3
        pass

    def get_car_satisfaction(self):  # 0.2
        return
