import pickle
import random

from person import Person


def test_structure(test):
    try:
        if not isinstance(test.threshold, float):
            raise TypeError(
                "Person item has wrong type of threshold attribute. Threshold should be float, is {}".format(type(test.threshold))
            )
    except AttributeError:
        raise AttributeError(
            "Person item missing attribute threshold. Do not alter class structure")

    try:
        if not isinstance(test.interested_in, list):
            raise TypeError(
                "Person item has wrong type of interested_in attribute. Interested_in should be list, is {}".format(type(test.interested_in))
            )
    except AttributeError:
        raise AttributeError(
            "Person item missing attribute interested_in. Do not alter class structure")

    try:
        if not isinstance(test.friends_list, list):
            raise TypeError(
                "Person item has wrong type of friends_list attribute. Friends_list should be list, is {}".format(type(test.friends_list))
            )
    except AttributeError:
        raise AttributeError(
            "Person item missing attribute friends_list. Do not alter class structure")

    try:
        if not isinstance(test.has_read, list):
            raise TypeError(
                "Person item has wrong type of has_read attribute. has_read should be list, is {}".format(type(test.has_read))
            )
    except AttributeError:
        raise AttributeError(
            "Person item missing attribute has_read. Do not alter class structure")


def test_is_interested_in():
    with open('is_interested_in_tests.pkl', 'rb') as f:
        test_list = pickle.load(f)

    test_count = len(test_list)
    correct = 0
    for threshold, interests, cat, res in test_list:
        is_good = True
        try:
            person = Person(threshold, interests)
        except Exception:
            is_good = False

        test_structure(person)

        try:
            stud_res = person.is_interested_in(cat)
        except Exception:
            is_good = False

        if not isinstance(stud_res, bool):
            is_good = False

        if stud_res != res:
            is_good = False

        correct += is_good

    return round((correct / test_count) * 0.1, 2)


def test_has_read_news():
    with open('has_read_news_tests.pkl', 'rb') as f:
        test_list = pickle.load(f)

    test_count = len(test_list)
    correct = 0

    for threshold, interests, news, news_piece, res in test_list:
        is_good = True
        try:
            person = Person(threshold, interests)
        except Exception:
            is_good = False

        test_structure(person)
        person.has_read = news

        try:
            stud_res = person.has_read_news(news_piece)
        except Exception:
            is_good = False

        if not isinstance(stud_res, bool):
            is_good = False

        if stud_res != res:
            is_good = False

        correct += is_good

    return round((correct / test_count) * 0.1, 2)


def test_make_friends():
    with open('make_friends_tests.pkl', 'rb') as f:
        test_list = pickle.load(f)

    test_count = len(test_list)
    correct = 0

    for population, count in test_list:
        is_good = True
        try:
            person = Person(random.random(), ["world", "tech", "sport"])
        except Exception:
            is_good = False

        test_structure(person)

        try:
            stud_res = person.make_friends(population, count)
        except Exception:
            is_good = False

        if stud_res is not None:
            is_good = False

        try:
            if len(person.friends_list) != count:
                is_good = False

            unique_friends = set(person.friends_list)
            if len(unique_friends) != count:
                is_good = False

            for friend in unique_friends:
                if friend == person:
                    is_good = False
                if friend not in population:
                    is_good = False
        except AttributeError:
            is_good = False
        except Exception:
            is_good = False

        correct += is_good

    return round((correct / test_count) * 0.3, 2)


def test_process_news():
    with open('process_news_tests.pkl', 'rb') as f:
        test_list = pickle.load(f)

    test_count = len(test_list)
    correct = 0

    for person, news_read, test_news, step, res in test_list:
        is_good = True
        try:
            person.has_read = news_read
            stud_res = person.process_news(test_news, step)
        except Exception as e:
            print(e)
            is_good = False

        if not isinstance(stud_res, list):
            is_good = False

        if is_good and len(stud_res) != len(res):
            is_good = False

        if is_good and len(set(stud_res)) != len(stud_res):
            is_good = False

        correct += is_good

    return round((correct / test_count) * 1.0, 2)


def main():
    print("Testing PERSON:")

    p2_1_points = test_is_interested_in()
    print("\tPerson.is_interested_in(): {:.2f}/0.1".format(p2_1_points))

    p2_2_points = test_has_read_news()
    print("\tPerson.has_read_news(): {:.2f}/0.1".format(p2_2_points))

    p2_3_points = test_make_friends()
    print("\tPerson.make_friends(): {:.2f}/0.3".format(p2_3_points))

    p2_4_points = test_process_news()
    print("\tPerson.process_news(): {:.2f}/1.0".format(p2_4_points))

    total = p2_1_points + p2_2_points + p2_3_points + p2_4_points
    print("Person: {:.2f}/1.5".format(total))

    return total


if __name__ == '__main__':
    main()
