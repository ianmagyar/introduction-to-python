import pickle

from news import News


def test_structure(test):
    try:
        if not isinstance(test.category, str):
            raise TypeError(
                "News item has wrong type of category attribute. Category should be string, is {}".format(type(test.category))
            )
    except AttributeError:
        raise AttributeError(
            "News item missing attribute category. Do not alter class structure")

    try:
        if not isinstance(test.excitement_rate, float):
            raise TypeError(
                "News item has wrong type of excitement_rate attribute. Excitement_rate should be float, is {}".format(type(test.excitement_rate))
            )
    except AttributeError:
        raise AttributeError(
            "News item missing attribute excitement_rate. Do not alter class structure")

    try:
        if not isinstance(test.validity_length, int):
            raise TypeError(
                "News item has wrong type of validity_length attribute. validity_length should be int, is {}".format(type(test.validity_length))
            )
    except AttributeError:
        raise AttributeError(
            "News item missing attribute validity_length. Do not alter class structure")

    try:
        if not isinstance(test.created, int):
            raise TypeError(
                "News item has wrong type of created attribute. created should be int, is {}".format(type(test.created))
            )
    except AttributeError:
        raise AttributeError(
            "News item missing attribute created. Do not alter class structure")


def test_check_data():
    total = 0.05

    for cat in ["world", "culture", "tech"]:
        for er in [0.0, 0.3, 0.5, 1.0]:
            for valid in [1, 5, 10]:
                for created in [1, 5, 10]:
                    try:
                        test = News(cat, er, valid, created)
                        test_structure(test)
                    except Exception:
                        total = 0.0

    try:
        test = News("gossip", 0.5, 5, 1)
    except ValueError:
        total += 0.05
    except Exception:
        pass
    else:
        pass

    try:
        test = News("world", "a", 5, 1)
    except TypeError:
        total += 0.05
    except Exception:
        pass
    else:
        pass

    try:
        test = News("world", 1.1, 5, 1)
    except ValueError:
        total += 0.05
    except Exception:
        pass
    else:
        pass

    try:
        test = News("world", -0.5, 5, 1)
    except ValueError:
        total += 0.05
    except Exception:
        pass
    else:
        pass

    try:
        test = News("world", 0.5, 5.4, 1)
    except TypeError:
        total += 0.05
    except Exception:
        pass
    else:
        pass

    try:
        test = News("world", 1.1, 15, 1)
    except ValueError:
        total += 0.05
    except Exception:
        pass
    else:
        pass

    try:
        test = News("world", 1.1, 0, 1)
    except ValueError:
        total += 0.05
    except Exception:
        pass
    else:
        pass

    try:
        test = News("world", 0.5, 5, 1.4)
    except TypeError:
        total += 0.05
    except Exception:
        pass
    else:
        pass

    try:
        test = News("world", 1.1, 5, 1)
    except ValueError:
        total += 0.05
    except Exception:
        pass
    else:
        pass

    if total == 0.05:
        total = 0

    return round(total, 2)


def test_get_excitement():
    with open('get_excitement_tests.pkl', 'rb') as f:
        test_list = pickle.load(f)

    all_tests = len(test_list)
    correct = 0
    for cat, er, valid, created, step, res in test_list:
        is_good = True
        news_item = News(cat, er, valid, created)
        test_structure(news_item)

        try:
            stud_res = news_item.get_excitement(step)
        except Exception:
            is_good = False

        if is_good and not isinstance(stud_res, float):
            is_good = False

        if is_good and abs(stud_res - res) > 0.001:
            is_good = False

        correct += is_good

    return round((correct / all_tests) * 0.5, 2)


def main():
    print("Testing NEWS:")

    p1_1_points = test_check_data()
    print("\tNews.check_data(): {:.2f}/0.5".format(p1_1_points))

    p1_2_points = test_get_excitement()
    print("\tNews.get_excitement(): {:.2f}/0.5".format(p1_2_points))

    print("News: {:.2f}/1".format(p1_1_points + p1_2_points))

    return p1_1_points + p1_2_points


if __name__ == '__main__':
    main()
