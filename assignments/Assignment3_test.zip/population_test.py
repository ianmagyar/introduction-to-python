import pickle
import random

from news import News
from person import Person
from population import Population, HomogeneousPopulation


def test_structure(test):
    try:
        if not isinstance(test.people, list):
            raise TypeError(
                "Population item has wrong type of people attribute. People should be list, is {}".format(type(test.people))
            )
    except AttributeError:
        raise AttributeError(
            "Population item missing attribute people. Do not alter class structure")

    try:
        if not isinstance(test.active_news, list):
            raise TypeError(
                "Population item has wrong type of active_news attribute. Active_news should be list, is {}".format(type(test.active_news))
            )
    except AttributeError:
        raise AttributeError(
            "Population item missing attribute active_news. Do not alter class structure")

    if isinstance(test, HomogeneousPopulation):
        try:
            if not isinstance(test.category, str):
                raise TypeError(
                    "HomogeneousPopulation item has wrong type of category attribute. Category should be string, is {}".format(type(test.category))
                )
        except AttributeError:
            raise AttributeError(
                "HomogeneousPopulation item missing attribute category. Do not alter class structure")


def test_generate_population():
    correct = 0
    all_tests = 0
    for _ in range(10):
        is_good = True
        size = random.choice([50, 100, 250, 500, 1000])
        friend_count = random.randint(1, 10)

        all_tests += 1
        test = None
        try:
            test = Population(size, friend_count)
        except Exception:
            is_good = False

        if is_good:
            test_structure(test)

        if is_good and len(test.people) != size:
            is_good = False

        if is_good:
            for elem in test.people:
                if not isinstance(elem, Person):
                    is_good = False

                try:
                    if len(elem.friends_list) != friend_count:
                        is_good = False
                except AttributeError:
                    is_good = False
                except TypeError:
                    is_good = False

                unique_friends = set(elem.friends_list)
                if len(unique_friends) != friend_count:
                    is_good = False

                if elem in unique_friends:
                    is_good = False

        correct += is_good

    return round((correct / all_tests) * 0.5, 2)


def test_generate_population_homogeneous():
    correct, all_tests = 0, 0

    for cat in ["politics", "world", "culture", "tech", "local", "sport"]:
        is_good = True
        size = random.choice([50, 100, 250, 500, 1000])
        friend_count = random.randint(1, 10)

        all_tests += 1
        try:
            test = HomogeneousPopulation(size, friend_count, cat)
        except Exception:
            is_good = False

        if is_good:
            test_structure(test)

        if is_good and len(test.people) != size:
            is_good = False

        if is_good:
            for elem in test.people:
                if not isinstance(elem, Person):
                    is_good = False

                try:
                    if len(elem.friends_list) != friend_count:
                        is_good = False
                except AttributeError:
                    is_good = False
                except TypeError:
                    is_good = False

                unique_friends = set(elem.friends_list)
                if len(unique_friends) != friend_count:
                    is_good = False

                if elem in unique_friends:
                    is_good = False

                try:
                    if cat not in elem.interested_in:
                        is_good = False
                except AttributeError:
                    is_good = False
                except TypeError:
                    is_good = False

        correct += is_good

    return round((correct / all_tests) * 0.5, 2)


def test_introduce_news():
    with open('introduce_news_tests.pkl', 'rb') as f:
        test_list = pickle.load(f)

    correct = 0
    all_tests = len(test_list)
    for active, to_add in test_list:
        is_good = True
        size = random.choice([50, 100, 250, 500, 1000])
        friend_count = random.randint(1, 10)

        try:
            test_pop = Population(size, friend_count)
        except Exception:
            is_good = False

        if is_good:
            test_structure(test_pop)

        orig_length = len(active)
        test_pop.active_news = active

        try:
            res = test_pop.introduce_news(to_add)
        except Exception:
            is_good = False

        if is_good:
            test_structure(test_pop)

            new_length = len(test_pop.active_news)
            if is_good and new_length != orig_length + 1:
                is_good = False

            if is_good and to_add not in test_pop.active_news:
                is_good = False

            if is_good and not isinstance(res, list):
                is_good = False

            if is_good and len(res) != 5:
                is_good = False

            if is_good:
                unique_people = set(res)
                if len(unique_people) != 5:
                    is_good = False

                if is_good:
                    for elem in res:
                        if not isinstance(elem, Person):
                            is_good = False

                        if to_add.category not in elem.interested_in:
                            is_good = False

        correct += is_good

    return round((correct / all_tests) * 0.5, 2)


def test_update_news():
    with open('update_news_tests.pkl', 'rb') as f:
        test_list = pickle.load(f)

    all_tests = len(test_list)
    points = 0
    for orig, step, correct in test_list:
        is_good = True
        size = random.choice([50, 100, 250, 500, 1000])
        friend_count = random.randint(1, 10)

        try:
            test_pop = Population(size, friend_count)
        except Exception:
            is_good = False

        if is_good:
            test_structure(test_pop)

        corr_length = len(correct)

        test_pop.active_news = orig
        try:
            res = test_pop.update_news(step)
        except Exception:
            is_good = False

        if is_good and res is not None:
            is_good = False

        if is_good:
            test_structure(test_pop)

        new_length = len(test_pop.active_news)
        if is_good and new_length != corr_length:
            is_good = False

        if is_good:
            for elem in test_pop.active_news:
                if not isinstance(elem, News):
                    is_good = False

        points += is_good

    # an empty implementation gives you 84 passes
    if points == 84:
        points = 0

    return round((points / all_tests) * 0.5, 2)


def test_count_readers():
    with open('count_readers_tests.pkl', 'rb') as f:
        test_list = pickle.load(f)

    all_tests = len(test_list)
    correct = 0
    for people, news, corr in test_list:
        is_good = True
        try:
            test_pop = Population(100, 6)
        except Exception:
            is_good = False

        if is_good:
            test_structure(test_pop)
            test_pop.people = people

            try:
                res = test_pop.count_readers(news)
            except Exception:
                is_good = False

            if is_good and not isinstance(res, int):
                is_good = False

            if is_good and res != corr:
                is_good = False

        correct += is_good

    return round((correct / all_tests) * 0.25, 2)


def test_get_number_of_interested():
    with open('get_number_of_interested_tests.pkl', 'rb') as f:
        test_list = pickle.load(f)

    correct = 0
    all_tests = len(test_list)
    for people, cat, corr in test_list:
        is_good = True
        try:
            test_pop = Population(100, 6)
        except Exception:
            is_good = False

        if is_good:
            test_structure(test_pop)
            test_pop.people = people

            try:
                res = test_pop.get_number_of_interested(cat)
            except Exception:
                is_good = False

            if is_good and not isinstance(res, int):
                is_good = False

            if is_good and res != corr:
                is_good = False

        correct += is_good

    return round((correct / all_tests) * 0.25, 2)


def main():
    print("Testing POPULATION:")

    p3_1_points = test_generate_population()
    print("\tPopulation.generate_population(): {:.2f}/0.5".format(p3_1_points))

    p3_2_points = test_introduce_news()
    print("\tPopulation.introduce_news(): {:.2f}/0.5".format(p3_2_points))

    p3_3_points = test_update_news()
    print("\tPopulation.update_news(): {:.2f}/0.5".format(p3_3_points))

    p3_4_points = test_count_readers()
    print("\tPopulation.count_readers(): {:.2f}/0.25".format(p3_4_points))

    p3_5_points = test_get_number_of_interested()
    print("\tPopulation.get_number_of_interested(): {:.2f}/0.25".format(p3_5_points))

    p3_6_points = test_generate_population_homogeneous()
    print("\tHomogeneousPopulation.generate_population(): {:.2f}/0.5".format(p3_6_points))

    total = sum([p3_1_points, p3_2_points, p3_3_points,
                 p3_4_points, p3_5_points, p3_6_points])
    print("Population: {:.2f}/2.5".format(total))

    return total


if __name__ == '__main__':
    main()
