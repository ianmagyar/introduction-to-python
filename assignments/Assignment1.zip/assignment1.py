import datetime


def load_line_infos(path):  # 2 points
    # loads timetables from the specified path and returns them in a dictionary
    # dictionary structure:
    #  - keys are line numbers (as integers)
    #  - each value is a list of tuples describing information on a stop
    #  - for the first stop, the tuple contains the name of the city
    #    and a list of all start times
    #  - start times are tuples with hour and minutes as integers
    #  - for all other stops, the tuple contains the city name
    #    and the number of minutes it takes to get there from the previous stop
    return dict()


def find_next_train(line_infos, line, hour, minute=0):  # 1
    # the function generates the scheduled timetable for the next train
    # on a given line
    # inputs:
    #  - line_infos: dictionary with line information (as loaded by load_line_infos)
    #  - line: the number of the line we are interested in (integer)
    #  - hour: the hour when we start our search (integer)
    #  - minute: the minute when we start our search (integer, by default 0)
    # the function returns a list of tuples where each tuple has two values:
    #  - city name (string)
    #  - a tuple representing the time when the train is scheduled to arrive
    #  - the train stands for a minute at each stop (if it arrives at 10:15,
    #    it leaves at 10:16, if the next stop is 5 minute away, it will arrive
    #    there at 10:21, not 10:20)
    return list()


def get_city_timetable(line_infos, city):  # 2
    # the function generates the timetable for an arbitrary city
    # for each line with regards to the end station
    # inputs:
    #  - line_infos: dictionary with timetable (as loaded by load_line_infos)
    #  - city: the city for which we want to generate the timetable (string)
    # the function returns a timetable for the given city as a dictionary
    #  - keys are names of possible end stations
    #  - values are lists of departure times as tuples (hour, minute)
    #    regardless of the concrete line that goes there
    return dict()


def load_arrival_times(path, line_infos):  # 2
    # the function loads real arrival data from a file
    # inputs:
    #  - path: path to a csv file with real arrival and departure times
    #  - line_infos: dictionary with timetable (as loaded by load_line_infos)
    # the function returns a dictionary with the following structure:
    #  - keys are line numbers (integers)
    #  - values are dictionaries:
    #     - keys are scheduled departure times (tuple of two ints)
    #     - values are dictionaries:
    #         - values are dates (string format: YYYY-MM-DD)
    #         - values are lists with tuples
    #           each tuple has four values:
    #            - city name (string - one tuple for each stop)
    #            - scheduled arrival (tuple (hour, minute))
    #            - real arrival (tuple (hour, minute))
    #            - delay in minutes (int - always round down)
    return dict()


def get_most_delayed_line(loaded_arrivals):  # 1
    # finds the line that accrued the most delays on average on the final stop
    # input:
    #  - loaded_arrivals: dictionary with arrival information
    #    (as loaded by load_arrival_times)
    # output:
    #  - tuple of two values:
    #    - line number (int)
    #    - average delay in minutes (float)
    return tuple()


def get_most_delayed_city(loaded_arrivals):  # 1
    # finds the city where trains arrive with the most delay on average
    # input:
    #  - loaded_arrivals: dictionary with arrival information
    #    (as loaded by load_arrival_times)
    # output:
    #  - tuple of two values:
    #    - city name (string)
    #    - average delay in minutes (float)
    return tuple()


if __name__ == '__main__':
    # test your functions here
    pass
