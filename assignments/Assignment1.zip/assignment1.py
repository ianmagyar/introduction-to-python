def load_data(file_path):  # 2 points
    # loads marathon results from the specified CSV file
    # input:
    #  - file_path: path to the CSV file (string)
    # output:
    #  - list of dictionaries, each dictionary represents one runner
    # dictionary structure:
    #  - "bib": start number (int)
    #  - "name": runner's name (string)
    #  - "gender": category ("M" or "F")
    #  - "splits": dictionary
    #       - keys are distances (e.g. 5, 10, 21, ...)
    #       - values are cumulative times in seconds (int)
    #  - "gun_time": official time in seconds (int or -1 if invalid)
    #  - "net_time": chip time in seconds (int or -1 if invalid)
    return list()


def find_fastest(all_results, category, n):  # 0.5
    # finds the n fastest runners in a given category
    # inputs:
    #  - all_results: list of runner dictionaries (from load_data)
    #  - category: "M" or "F"
    #  - n: number of runners to return (default 100)
    # output:
    #  - list of runner names (strings)
    return list()


def get_position(all_results, station, bib):  # 0.5
    # determines the position of a runner at a given split
    # inputs:
    #  - all_results: list of runner dictionaries
    #  - station: split distance (e.g. "10", "21")
    #  - bib: start number of the runner (int)
    # output:
    #  - integer representing the position within the runner's category
    return 0


def save_results(all_results, category, station):  # 1
    # generates a CSV file with ordered results at a given split
    # inputs:
    #  - all_results: list of runner dictionaries
    #  - category: "M" or "F"
    #  - station: split distance
    # output:
    #  - None (function creates a file)
    # file name format:
    #  results_<category>_<station>K.csv
    # file content format:
    #  position,bib,name,time_at_split
    return None


def get_gender_results(all_results, category):  # 1
    # generates basic statistics for a given category
    # inputs:
    #  - all_results: list of runner dictionaries
    #  - category: "M" or "F"
    # output:
    #  - dictionary with keys:
    #       "Winner"  -> runner name (string)
    #       "Best"    -> best time (string H:MM:SS)
    #       "Average" -> average time (string H:MM:SS)
    #       "Worst"   -> worst time (string H:MM:SS)
    #       "DNF"     -> number of runners who did not finish (int)
    return dict()


def find_most_consistent(all_results, category=None):  # 2
    # finds the runner with the most consistent pace
    # inputs:
    #  - all_results: list of runner dictionaries
    #  - category: optional ("M", "F", or None)
    # output:
    #  - tuple of three values:
    #       runner name (string)
    #       consistency measure (float)
    #       average pace (float, seconds per kilometer)
    return ("", 0.0, 0.0)


def get_target_pace_for_position(all_results, pos, category=None):  # 1
    # calculates the required average pace to achieve a given position
    # inputs:
    #  - all_results: list of runner dictionaries
    #  - pos: target finishing position (int, starting from 1)
    #  - category: optional ("M", "F", or None)
    # output:
    #  - string in format "MM:SS" representing pace per kilometer
    return ""


def calculate_target_pace(section, section_time, target_time):  # 1
    # calculates required pace for the remaining distance
    # inputs:
    #  - section: distance already completed (float or int)
    #  - section_time: time at that distance (string H:MM:SS)
    #  - target_time: desired finish time (string H:MM:SS)
    # output:
    #  - string "MM:SS" representing required pace
    #  - or None if required pace is unrealistically low (less than 3:00/km)
    return ""


def find_slowest_starter(all_results):  # 0.5
    # finds the runner with the largest difference between
    # gun_time and net_time
    # input:
    #  - all_results: list of runner dictionaries
    # output:
    #  - tuple:
    #       runner name (string)
    #       difference in seconds (int)
    return ("", 0)


def calculate_split(all_results, bib):  # 0.5
    # calculates the time difference between a runner and
    # the winner of their category
    # inputs:
    #  - all_results: list of runner dictionaries
    #  - bib: start number (int)
    # output:
    #  - formatted string:
    #       "H:MM:SS" if >= 1 hour
    #       "M:SS" if < 1 hour
    #  - empty string if runner does not exist
    return ""


if __name__ == '__main__':
    # test your functions here
    pass
