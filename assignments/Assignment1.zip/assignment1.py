def throw_to_points(throw):  # 0.5
    return


def parse_throws(throw_list):  # 2
    return []


def save_throws(throw_pairs, path):  # 1
    pass


def split_into_sets(throw_pairs):  # 2
    return []


def get_match_result(structured_throws):  # 1
    return tuple()


def get_180s(structured_throws):  # 0.5
    return tuple()


def get_average_throws(structured_throws):  # 1
    return []


def generate_finishes(points):  # 2
    return []


if __name__ == '__main__':
    # you can test your code here
    pass
