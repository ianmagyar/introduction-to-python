class Cinema:
    def __init__(self, auditoriums):
        self.auditoriums = auditoriums
        self.screenings = list()

    def add_movie(self, movie, screening_times):
        pass

    def get_movies_shown(self):
        return list()

    def get_screenings_for_movie(self, movie):
        return list()


if __name__ == '__main__':
    # you can run your tests here
    pass
