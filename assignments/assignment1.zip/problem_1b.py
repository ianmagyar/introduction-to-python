from copy import deepcopy
import random
import string


PLAYER_KNOWLEDGE = [(letter, None, -1)
                    for letter in string.ascii_lowercase]
SMART_PLAYER_KNOWLEDGE = [[letter, None, [0, 1, 2, 3, 4]]
                          for letter in string.ascii_lowercase]


def load_words(dataset_path):
    # load word list from txt file into a list of strings
    # returns a list of strings 5 letters long
    return list()


def get_puzzle(word_list):
    # returns a random word from the word list given as parameter
    return


def is_game_finished(guess, puzzle):
    # returns if the guess is the same as the puzzle
    # disregards letter case
    # returns a boolean value
    return False


def evaluate_guess(guess, puzzle):
    # evaluates the player's guess and returns feedback on its correctness
    # return value is a list of tuples, where each tuple has three values:
    #  - letter - string; maintain letter order in guess
    #  - containts - boolean; whether the letter is in the puzzle
    #  - position - boolean; whether the letter is in the correct position
    return


def get_player_guess(word_list, knowledge):
    # returns the guess of the simple bot based on the word list and current
    # knowledge of the player
    # creates a copy of the word list and removes from it words that cannot
    # be the correct solution based on the knowledge:
    #  - remove words that don't contain a letter that must be in the solution
    #  - remove words that contain a letter that cannot be in the solution
    #  - remove words that don't have the correct letter in a known position
    # the function returns two values:
    #  - a list of available words after elimination
    #  - a random guess from the list
    return None, None


def process_result(result, knowledge):
    # updates the player knowledge based on the feedback for the last guess
    # result is provided as output from evaluate_guess, knowledge has the
    # structure of PLAYER_KNOWLEDGE
    # updates information on a letter's existence in the solution and
    # its position in the word
    # has no return value, directly updates knowledge
    pass


def get_smart_player_guess(word_list, knowledge):
    # returns the guess of the smart bot based on the word list and current
    # knowledge of the player
    # creates a copy of the word list and removes from it words that cannot
    # be the correct solution based on the knowledge:
    #  - remove words that don't contain a letter that must be in the solution
    #  - remove words that contain a letter that cannot be in the solution
    #  - remove words that have a letter in an incorrect position
    # the function returns two values:
    #  - a list of available words after elimination
    #  - a random guess from the list
    return None, None


def smart_process_result(result, knowledge):
    # updates the player knowledge based on the feedback for the last guess
    # result is provided as output from evaluate_guess, knowledge has the
    # structure of SMART_PLAYER_KNOWLEDGE
    # updates information on a letter's existence in the solution and
    # its position in the word - remove invalid positions
    # has no return value, directly updates knowledge
    pass


def human_game(dataset_path):
    # nepovinne - iba pre testovanie
    word_list = load_words(dataset_path)
    puzzle = get_puzzle(word_list)
    print(puzzle)

    for _ in range(6):
        guess = input("Enter your guess: ")
        while guess not in word_list:
            print("Sorry, I did not find that word!")
            guess = input("Enter your guess: ")

        result = evaluate_guess(guess, puzzle)
        print(result)

        if is_game_finished(guess, puzzle):
            print("You win!")
            return


def main(dataset_path):
    word_list = load_words(dataset_path)
    player_words = word_list.copy()
    player_knowledge = deepcopy(PLAYER_KNOWLEDGE)

    puzzle = get_puzzle(word_list)
    print(puzzle)

    guess = ""
    while not is_game_finished(guess, puzzle):
        player_words, guess = get_player_guess(player_words, player_knowledge)
        print(player_words)
        player_words.remove(guess)
        print(guess)

        result = evaluate_guess(guess, puzzle)
        print(result)

        process_result(result, player_knowledge)


def smart_main(dataset_path):
    word_list = load_words(dataset_path)
    player_words = word_list.copy()
    player_knowledge = deepcopy(SMART_PLAYER_KNOWLEDGE)

    puzzle = get_puzzle(word_list)
    print(puzzle)

    guess = ""
    while not is_game_finished(guess, puzzle):
        player_words, guess = get_smart_player_guess(player_words, player_knowledge)
        print(player_words)
        player_words.remove(guess)
        print(guess)

        result = evaluate_guess(guess, puzzle)
        print(result)

        smart_process_result(result, player_knowledge)


if __name__ == '__main__':
    pass
    # human_game("1b_dataset.txt")
    # main("1b_dataset.txt")
    # smart_main("1b_dataset.txt")
