# -*- coding: utf-8 -*-

# Zadanie 2 - Sudoku Solver

# Meno: 
# Spolupráca: 
# Použité zdroje: 
# Čas: 


def loadSudoku(grid_string):
    # the function loads a string representing a grid and returns it as a list
    pass


def findNextEmptyCell(grid):
    # this function finds the next empty cell and returns its coordinates
    pass


def isSolved(grid):
    # this function returns True if sudoku puzzle is solved, False otherwise
    pass


def isValid(grid, i, j, e):
    # the function checks if cell (i, j) could be set to value e
    pass


def fillSure(grid):
    # the function fills each cell where only one value is possible
    pass


def solveSudoku(grid_string):
    # the main function that loads the sudoku and solves the grid
    pass


def printSudoku(grid):
    # the function prints out a grid of sudoku puzzle
    pass
