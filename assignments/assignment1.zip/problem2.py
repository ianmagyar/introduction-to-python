# -*- coding: utf-8 -*-

# Zadanie 1.2 - Fold, Check, Call, Raise...

# Meno: 
# Spolupráca: 
# Použité zdroje: 
# Čas: 

from copy import deepcopy

# hearts, clubs, spades, diamonds
SUITS = ['H', 'C', 'S', 'D']
VALUES = [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14]
DECK = [(s, v) for s in SUITS for v in VALUES]


def generate_setup():
    # helper function for generating test cases
    from random import sample
    deck = deepcopy(DECK)
    player1_hand = sample(deck, 2)
    for card in player1_hand:
        deck.remove(card)
    player2_hand = sample(deck, 2)
    for card in player2_hand:
        deck.remove(card)
    flop = sample(deck, 3)
    for card in flop:
        deck.remove(card)
    turn = sample(deck, 1)
    for card in turn:
        deck.remove(card)

    return player1_hand, player2_hand, flop, turn


def is_royal_flush(hand):
    return None, None


def is_straight_flush(hand):
    return None, None


def is_four_of_a_kind(hand):
    return None, None


def is_full_house(hand):
    return None, None


def is_flush(hand):
    return None, None


def is_straight(hand):
    return None, None


def is_three_of_a_kind(hand):
    return None, None


def is_two_pairs(hand):
    return None, None


def is_pair(hand):
    return None, None


def evaluate_hand(hand):
    res = is_royal_flush(hand)
    if res[0]:
        return 9, res[1]

    res = is_straight_flush(hand)
    if res[0]:
        return 8, res[1]

    res = is_four_of_a_kind(hand)
    if res[0]:
        return 7, res[1]

    res = is_full_house(hand)
    if res[0]:
        return 6, res[1]

    res = is_flush(hand)
    if res[0]:
        return 5, res[1]

    res = is_straight(hand)
    if res[0]:
        return 4, res[1]

    res = is_three_of_a_kind(hand)
    if res[0]:
        return 3, res[1]

    res = is_two_pairs(hand)
    if res[0]:
        return 2, res[1]

    res = is_pair(hand)
    if res[0]:
        return 1, res[1]

    return 0, None


def compare_highest_card(hand_1, hand_2):
    return None


def get_all_combinations(hand, flop, turn, river):
    return None


def find_better(hand_1, hand_2):
    return None


def select_best(hand, flop, turn, river):
    return None


def calculate_chances(player1_hand, player2_hand, flop, turn):
    return None, None, None


if __name__ == '__main__':
    player1_hand, player2_hand, flop, turn = generate_setup()

    print("PLAYER 1:", player1_hand)
    print("PLAYER 2:", player2_hand)
    print("FLOP:", flop)
    print("TURN:", turn)

    p1_win, p2_win, draw = calculate_chances(
        player1_hand, player2_hand, flop, turn)

    print("PLAYER 1 has a {} chance of winning".format(p1_win))
    print("PLAYER 2 has a {} chance of winning".format(p2_win))
    print('There\'s a {} chance of a draw'.format(draw))
