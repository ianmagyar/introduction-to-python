import pandas as pd


def load_meals(file_path):
    # loads csv file from file_path into a pandas dataframe
    # replace all missing value with 0
    # returns the dataframe
    return None


def split_into_categories(meal_list):
    # splits the dataframe meal_list into four dataframes
    # with different types of meals:
    # soups, main dishes, sidedishes and desserts
    # returns four dataframe
    return None, None, None, None


def check_intervals(intervals):
    # checks the validity of the loaded intervals
    # raises TypeError if intervals is not a dictionary
    # raises KeyError if one limit name is missing
    #     should contain calories, protein, fat, carbs and price
    # raises TypeError if interval limits are not given as tuples
    # raises ValueError if interval limits are not given as tuples of two
    # raises TypeError if interval limit values are not of the correct type
    #     float for price, int for others
    # raises ValueError if the upper limit is smaller than the lower limit
    # has no return value
    pass


def load_intervals(file_path):
    # loads intervals for calories, protein, fat, carbs and price from file
    # returns a dictionary with limit names as keys
    # and lower and upper limits as tuples values
    # limits are set as integers for calories, protein, fat and carbs
    # price has float limits
    return None


def calculate_stats(meal):
    # input: meal as a pandas dataframe row - Series
    # calculates calories, protein, fat and carbs for a serving of the meal
    # based on the meal's total amount
    # returns for floats: total calories, protein, fat and carbs in serving
    return 0, 0, 0, 0


def evaluate_lunch(soup, main, side, dessert, intervals):
    # determines if the proposed lunch consisting of
    # soup, main, side and dessert meets all limit requirements
    # inputs: soup, main, side, dessert - pandas Series
    #         intervals - dictionary with limit requirements
    # returns True if the lunch meets requirements, False otherwise
    return False


def get_lunch_price(soup, main, side, dessert):
    # returns the total price of the lunch consisting of
    # soup, main, side, dessert
    # inputs: soup, main, side, dessert - pandas Series
    # returns: float representing total price
    return 0.0


def generate_combinations(soups, mains, sides, desserts):
    # generates all possible lunches where each lunch consists of
    # one soup, one main dish, one sidedish, and one dessert
    # inputs: soups, mains, sides, desserts - pandas Dataframes
    # returns: list of combinations where each element
    #          is a tuple of four values
    return list()


def find_best_meal(soups, mains, sides, desserts, intervals):
    # finds the cheapest possible lunch combination conforming to
    # interval limits for nutrients based on the available meals
    # inputs: soups, mains, sides, desserts - pandas Dataframes
    #         intervals - dictionary with limit requirements
    # returns: cheapest possible lunch - list of four pandas Series (rows)
    #          price of the cheapest lunch - float
    #          if no combination meets the limits, it returns None and infinity
    return None, float('inf')


def main(meal_file_path, interval_file_path):
    meal_df = load_meals(meal_file_path)
    intervals = load_intervals(interval_file_path)

    soups, mains, sides, desserts = split_into_categories(meal_df)

    return find_best_meal(soups, mains, sides, desserts, intervals)


if __name__ == '__main__':
    result = main(
        '1a_sample_meals.csv',
        '1a_sample_interval.txt'
    )
    print(result)
