# -*- coding: utf-8 -*-

# Zadanie 1 - Kedy na Jedlicku?

# Meno: 
# Spolupráca: 
# Použité zdroje: 
# Čas: 


def loadIntervals(path):
    # returns a list of intervals as tuples
    pass


def whenToGo(path):
    # load intervals from path
    # call function to calculate best time for party
    # print results
    pass


def chooseTime(interval_list):
    # return best time to party and number of friends present
    pass


def chooseTimeConstrained(interval_list, ystart, yend):
    # return best time to party and number of friends present
    # look only in interval <ystart, yend)
    pass


def chooseTimeWithWeights(interval_list):
    # return best time to party and total weight
    pass
