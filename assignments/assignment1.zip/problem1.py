# -*- coding: utf-8 -*-

# Zadanie 1.1 - Čakáme a čakáme

# Meno: 
# Spolupráca: 
# Použité zdroje: 
# Čas: 


def load_queue_data(file_path):
    # returns the queues information as a dictionary with:
    # key -- a tuple with cashier information
    # value -- a list of tuples with customer information
    return


def calculate_customer_time(cashier_speed, customer):
    # calculates the amount of time of serving a customer in seconds
    # returns an integer
    return


def choose_queue(queues):
    # returns the name of the cashier whose queue the user should join
    return


def where_to_send(queues, customer):
    # returns the name of the cashier whose queue we should send the customer
    # to minimze overall waiting time among all queues
    return


def should_use_cashier(cashier, queues, save_at_least=30):
    # determines whether it would pay off to open a new cash register
    # returns a boolean
    # -- True if the waiting time saved by opening the cash register is
    #    more than the minimal amount of time where it pays off to open it
    # -- False otherwise
    return


if __name__ == '__main__':
    # use this function to test your solutions at your convenience
    pass
