SENIORITY = ['junior', 'medior', 'senior']
WAGES = {
    'junior': (15, 25),
    'medior': (20, 30),
    'senior': (30, 50)
}
