from boarding import BoardingFTB, BoardingBTF, BoardingATW, BoardingWTA, BoardingRandom, BoardingSteffen


def test_FTB():
    print("Testing Front-to-Back")

    boarding = BoardingFTB()

    res = boarding.run_simulation(8)
    res_type = type(res)
    assert res_type == int, "\trun_simulation() expected return type of int, got {}".format(res_type)

    res = boarding.test_boarding_method(8, 5)
    res_len = len(res)
    assert res_len == 2, "\ttest_boarding_method() expected two return values, got {}".format(res_len)

    avg, steps = res
    avg_type = type(avg)
    steps_type = type(steps)
    assert avg_type == float, "\ttest_boarding_method() expected average as float, got {}".format(avg_type)
    assert steps_type == list, "\ttest_boarding_method() expected list of steps, got {}".format(steps_type)

    boarding.generate_boarding(8)

    psg_list = boarding.plane.seats[3][0]

    order = [(psg.row, psg.seat) for psg in psg_list]

    group_length = 2
    for sgroup in range(4):
        group_psg = order[sgroup * 12:(sgroup + 1) * 12]
        for row, seat in group_psg:
            if row < sgroup * group_length or row > (sgroup + 1) * group_length:
                raise AssertionError("Wrong passengers ({}{}) in Group {}".format(
                    row, seat, sgroup + 1))
            if seat not in ['A', 'B', 'C', 'D', 'E', 'F']:
                raise AssertionError("Unknown seat {}".format(seat))
            for stype in ['A', 'B', 'C', 'D', 'E', 'F']:
                selected = [x for x in group_psg if x[1] == stype]
                if len(selected) != group_length:
                    raise AssertionError("Unexpected number of seats {} in group {}: {}".format(
                        stype, sgroup + 1, len(selected)))

    boarding.generate_boarding(8)
    psg_list2 = boarding.plane.seats[3][0]
    order2 = [(psg.row, psg.seat) for psg in psg_list2]

    boarding.generate_boarding(8)
    psg_list3 = boarding.plane.seats[3][0]
    order3 = [(psg.row, psg.seat) for psg in psg_list3]

    if order == order2 and order == order3:
        raise AssertionError("You should randomize the order of your passengers")

    print("Testing Front-to-Back finished; correct solution")


def test_BTF():
    print("Testing Back-to-Front")

    boarding = BoardingBTF()

    res = boarding.run_simulation(8)
    res_type = type(res)
    assert res_type == int, "\trun_simulation() expected return type of int, got {}".format(res_type)

    res = boarding.test_boarding_method(8, 5)
    res_len = len(res)
    assert res_len == 2, "\ttest_boarding_method() expected two return values, got {}".format(res_len)

    avg, steps = res
    avg_type = type(avg)
    steps_type = type(steps)
    assert avg_type == float, "\ttest_boarding_method() expected average as float, got {}".format(avg_type)
    assert steps_type == list, "\ttest_boarding_method() expected list of steps, got {}".format(steps_type)

    boarding.generate_boarding(8)

    psg_list = boarding.plane.seats[3][0]

    order = [(psg.row, psg.seat) for psg in psg_list]

    group_length = 2
    for sgroup in range(4):
        group_psg = order[sgroup * 12:(sgroup + 1) * 12]
        for row, seat in group_psg:
            if row <= 8 - ((sgroup + 1) * 2) or row > 8 - (sgroup * 2):
                raise AssertionError("Wrong passengers ({}{}) in Group {}".format(
                    row, seat, sgroup + 1))
            if seat not in ['A', 'B', 'C', 'D', 'E', 'F']:
                raise AssertionError("Unknown seat {}".format(seat))
            for stype in ['A', 'B', 'C', 'D', 'E', 'F']:
                selected = [x for x in group_psg if x[1] == stype]
                if len(selected) != group_length:
                    raise AssertionError("Unexpected number of seats {} in group {}: {}".format(
                        stype, sgroup + 1, len(selected)))

    boarding.generate_boarding(8)
    psg_list2 = boarding.plane.seats[3][0]
    order2 = [(psg.row, psg.seat) for psg in psg_list2]

    boarding.generate_boarding(8)
    psg_list3 = boarding.plane.seats[3][0]
    order3 = [(psg.row, psg.seat) for psg in psg_list3]

    if order == order2 and order == order3:
        raise AssertionError("You should randomize the order of your passengers")

    print("Testing Back-to-Front finished; correct solution")


def test_WTA():
    print("Testing Window-to-Aisle")

    boarding = BoardingWTA()

    res = boarding.run_simulation(8)
    res_type = type(res)
    assert res_type == int, "\trun_simulation() expected return type of int, got {}".format(res_type)

    res = boarding.test_boarding_method(8, 5)
    res_len = len(res)
    assert res_len == 2, "\ttest_boarding_method() expected two return values, got {}".format(res_len)

    avg, steps = res
    avg_type = type(avg)
    steps_type = type(steps)
    assert avg_type == float, "\ttest_boarding_method() expected average as float, got {}".format(avg_type)
    assert steps_type == list, "\ttest_boarding_method() expected list of steps, got {}".format(steps_type)

    boarding.generate_boarding(8)

    psg_list = boarding.plane.seats[3][0]

    order = [(psg.row, psg.seat) for psg in psg_list]
    group_seats = [["A", "F"], ["B", "E"], ["C", "D"]]

    for sgroup in range(3):
        group_psg = order[sgroup * 16:(sgroup + 1) * 16]
        for row, seat in group_psg:
            if seat not in group_seats[sgroup]:
                raise AssertionError("Unknown seat {}".format(seat))
        rows = [x[0] for x in group_psg]
        for row in rows:
            if rows.count(row) != 2:
                raise AssertionError("Row {} incorrect in group {}".format(row, sgroup + 1))

    boarding.generate_boarding(8)
    psg_list2 = boarding.plane.seats[3][0]
    order2 = [(psg.row, psg.seat) for psg in psg_list2]

    boarding.generate_boarding(8)
    psg_list3 = boarding.plane.seats[3][0]
    order3 = [(psg.row, psg.seat) for psg in psg_list3]

    if order == order2 and order == order3:
        raise AssertionError("You should randomize the order of your passengers")

    print("Testing Window-to-Aisle finished; correct solution")


def test_ATW():
    print("Testing Aisle-to-Window")

    boarding = BoardingATW()

    res = boarding.run_simulation(8)
    res_type = type(res)
    assert res_type == int, "\trun_simulation() expected return type of int, got {}".format(res_type)

    res = boarding.test_boarding_method(8, 5)
    res_len = len(res)
    assert res_len == 2, "\ttest_boarding_method() expected two return values, got {}".format(res_len)

    avg, steps = res
    avg_type = type(avg)
    steps_type = type(steps)
    assert avg_type == float, "\ttest_boarding_method() expected average as float, got {}".format(avg_type)
    assert steps_type == list, "\ttest_boarding_method() expected list of steps, got {}".format(steps_type)

    boarding.generate_boarding(8)

    psg_list = boarding.plane.seats[3][0]

    order = [(psg.row, psg.seat) for psg in psg_list]
    group_seats = [["C", "D"], ["B", "E"], ["A", "F"]]

    for sgroup in range(3):
        group_psg = order[sgroup * 16:(sgroup + 1) * 16]
        for row, seat in group_psg:
            if seat not in group_seats[sgroup]:
                raise AssertionError("Unknown seat {}".format(seat))
        rows = [x[0] for x in group_psg]
        for row in rows:
            if rows.count(row) != 2:
                raise AssertionError("Row {} incorrect in group {}".format(row, sgroup + 1))

    boarding.generate_boarding(8)
    psg_list2 = boarding.plane.seats[3][0]
    order2 = [(psg.row, psg.seat) for psg in psg_list2]

    boarding.generate_boarding(8)
    psg_list3 = boarding.plane.seats[3][0]
    order3 = [(psg.row, psg.seat) for psg in psg_list3]

    if order == order2 and order == order3:
        raise AssertionError("You should randomize the order of your passengers")

    print("Testing Aisle-to-Window finished; correct solution")


def test_Random():
    print("Testing Random")

    boarding = BoardingRandom()

    res = boarding.run_simulation(8)
    res_type = type(res)
    assert res_type == int, "\trun_simulation() expected return type of int, got {}".format(res_type)

    res = boarding.test_boarding_method(8, 5)
    res_len = len(res)
    assert res_len == 2, "\ttest_boarding_method() expected two return values, got {}".format(res_len)

    avg, steps = res
    avg_type = type(avg)
    steps_type = type(steps)
    assert avg_type == float, "\ttest_boarding_method() expected average as float, got {}".format(avg_type)
    assert steps_type == list, "\ttest_boarding_method() expected list of steps, got {}".format(steps_type)

    boarding.generate_boarding(8)

    psg_list = boarding.plane.seats[3][0]

    order = [(psg.row, psg.seat) for psg in psg_list]

    for seat in ["A", "B", "C", "D", "E", "F"]:
        selected = [x for x in order if x[1] == seat]
        if len(selected) != 8:
            raise AssertionError("Missing or extra passengers for seat {}".format(seat))

    for row in range(1, 9):
        selected = [x for x in order if x[0] == row]
        if len(selected) != 6:
            raise AssertionError("Missing or extra passengers for row {}".format(row))

    boarding.generate_boarding(8)
    psg_list2 = boarding.plane.seats[3][0]
    order2 = [(psg.row, psg.seat) for psg in psg_list2]

    boarding.generate_boarding(8)
    psg_list3 = boarding.plane.seats[3][0]
    order3 = [(psg.row, psg.seat) for psg in psg_list3]

    if order == order2 and order == order3:
        raise AssertionError("You should randomize the order of your passengers")

    print("Testing Random finished; correct solution")


def test_Steffen():
    print("Testing Steffen's")

    boarding = BoardingSteffen()

    res = boarding.run_simulation(8)
    res_type = type(res)
    assert res_type == int, "\trun_simulation() expected return type of int, got {}".format(res_type)

    res = boarding.test_boarding_method(8, 5)
    res_len = len(res)
    assert res_len == 2, "\ttest_boarding_method() expected two return values, got {}".format(res_len)

    avg, steps = res
    avg_type = type(avg)
    steps_type = type(steps)
    assert avg_type == float, "\ttest_boarding_method() expected average as float, got {}".format(avg_type)
    assert steps_type == list, "\ttest_boarding_method() expected list of steps, got {}".format(steps_type)

    boarding.generate_boarding(8)

    psg_list = boarding.plane.seats[3][0]

    real_order = [(psg.row, psg.seat) for psg in psg_list]
    expected_order = [
        (8, 'A'), (6, 'A'), (4, 'A'), (2, 'A'), (8, 'F'), (6, 'F'), (4, 'F'), (2, 'F'),
        (7, 'A'), (5, 'A'), (3, 'A'), (1, 'A'), (7, 'F'), (5, 'F'), (3, 'F'), (1, 'F'),
        (8, 'B'), (6, 'B'), (4, 'B'), (2, 'B'), (8, 'E'), (6, 'E'), (4, 'E'), (2, 'E'),
        (7, 'B'), (5, 'B'), (3, 'B'), (1, 'B'), (7, 'E'), (5, 'E'), (3, 'E'), (1, 'E'),
        (8, 'C'), (6, 'C'), (4, 'C'), (2, 'C'), (8, 'D'), (6, 'D'), (4, 'D'), (2, 'D'),
        (7, 'C'), (5, 'C'), (3, 'C'), (1, 'C'), (7, 'D'), (5, 'D'), (3, 'D'), (1, 'D'),
    ]

    if real_order != expected_order:
        raise AssertionError("Wrongly generated order of passengers!")

    boarding.generate_boarding(8)
    psg_list2 = boarding.plane.seats[3][0]
    order2 = [(psg.row, psg.seat) for psg in psg_list2]

    boarding.generate_boarding(8)
    psg_list3 = boarding.plane.seats[3][0]
    order3 = [(psg.row, psg.seat) for psg in psg_list3]

    if real_order != order2 and real_order != order3:
        raise AssertionError("You should generate the same order of your passengers")

    print("Testing Steffen's finished; correct solution")


def test_boarding():
    test_FTB()

    test_BTF()

    test_WTA()

    test_ATW()

    test_Random()

    test_Steffen()


if __name__ == '__main__':
    test_boarding()
