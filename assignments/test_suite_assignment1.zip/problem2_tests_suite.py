from io import StringIO
import sys

import problem2 as impl
from sudokus_results import *


def test_loadSudoku():
    total = 0.0
    for x in range(len(sudoku_strs)):
        line = sudoku_strs[x]
        correct = sudoku_grids[x]
        try:
            student = impl.loadSudoku(line)
        except AttributeError:
            print("Could not find loadSudoku")
            return 0.0
        except:
            print("Could not execute student solution - loadSudoku")
            return total

        if len(student) == 9:
            for row in student:
                if len(row) != 9:
                    print("FAILURE - wrong format")
                    continue
            if student == correct:
                total += 0.1
        else:
            print("FAILURE - wrong format")

    errors = [
        "12345",
        "0b0430a00630010009000009503008003100410796085007800600106900000900020016000068000"
    ]
    for line in errors:
        saved_stdout = sys.stdout
        try:
            out = StringIO()
            sys.stdout = out

            try:
                impl.loadSudoku(line)
            except AttributeError:
                print("Could not find loadSudoku")
                return 0.0
            except:
                print("Could not execute student solution - loadSudoku")
                return total
            output = out.getvalue().strip()
            out.truncate(0)
            out.seek(0)
            if output:
                total += 0.1
        except:
            sys.stdout = saved_stdout
            print("student did not deal with erroneous input")
        finally:
            sys.stdout = saved_stdout

    return total


def test_findNextEmptyCell():
    total = 0.0

    # check return values for fill grid
    solved = solution_grids[0]
    try:
        st_i, st_j = impl.findNextEmptyCell(solved)
    except AttributeError:
        print("Could not find student solution - findNextEmptyCell")
        return 0.0
    except:
        print("Could not execute student solution - findNextEmptyCell")
        return total
    if st_i == -1 and st_j == -1:
        total += 0.1

    for x in range(len(sudoku_grids)):
        try:
            st_i, st_j = impl.findNextEmptyCell(sudoku_grids[x])
        except AttributeError:
            print("Could not find student solution - findNextEmptyCell")
            return 0.0
        except:
            print("Could not execute student solution - findNextEmptyCell")
            return total
        corr_i, corr_j = next_empty[x]

        if st_i == corr_i and st_j == corr_j:
            total += 0.05

    return total


def test_isSolved():
    total = 0.0

    for grid in sudoku_grids[:5]:
        try:
            st_output = impl.isSolved(grid)
        except AttributeError:
            print("Could not find student solution - isSolved")
            return 0.0
        except:
            print("Could not execute student solution - isSolved")
            return total

        if st_output == False:
            total += 0.05

    for grid in solution_grids[:5]:
        try:
            st_output = impl.isSolved(grid)
        except AttributeError:
            print("Could not find student solution - isSolved")
            return 0.0
        except:
            print("Could not execute student solution - isSolved")
            return total

        if st_output == True:
            total += 0.05

    return total


def test_isValid():
    total = 0.0
    grid = sudoku_grids[-1]

    for i, j, num, res in is_valid_tests:
        try:
            st_output = impl.isValid(grid, i, j, num)
        except AttributeError:
            print("Could not find student solution - isValid")
            return 0.0
        except:
            print("Could not execute student solution - isValid")
            return total

        if st_output == res:
            total += 0.05

    try:
        impl.isValid(grid, 5.4, 2.3, 1)
    except:
        total += 0.025

    try:
        impl.isValid(grid, 1, 1, 2.3)
    except:
        total += 0.025

    try:
        impl.isValid(grid, 11, -2, 1)
    except:
        total += 0.025

    try:
        impl.isValid(grid, 1, 1, 12)
    except:
        total += 0.025

    return total


def test_printSudoku(grid):
    saved_stdout = sys.stdout
    try:
        out = StringIO()
        sys.stdout = out

        try:
            impl.printSudoku(grid)
        except AttributeError:
            print("Could not find student solution - printSudoku")
            return None
        output = out.getvalue().strip()
    except:
        sys.stdout = saved_stdout
        print("could not execute student solution - printSudoku")
        return None
    finally:
        sys.stdout = saved_stdout

    return output


def test_solveSudoku():
    total = 0.0

    for x in range(len(sudoku_strs)):
        try:
            st_res = impl.solveSudoku(sudoku_strs[x])
        except AttributeError:
            print("Could not find student solution - solveSudoku")
            return 0.0
        except:
            print("Could not execute student solution - solveSudoku")
            return total
        corr_res = solution_grids[x]
        pts = 0.25

        for i in range(len(corr_res)):
            for j in range(len(corr_res[0])):
                if st_res[i][j] != corr_res[i][j]:
                    pts = 0.0

        total += pts

    return total


def count_zeros(grid):
    zeros = 0

    for i in range(len(grid)):
        for j in range(len(grid[0])):
            if grid[i][j] == 0:
                zeros += 1

    return zeros


def test_fillSure(grids):
    total = 0.0

    for grid in sudoku_grids:
        initial_zero_count = count_zeros(grid)
        try:
            new_grid = impl.fillSure(grid)
        except AttributeError:
            print("Could not find student solution - fillSure")
            return 0.0
        except:
            print("Could not execute student solution - fillSure")
            return total
        post_zero_count = count_zeros(new_grid)

        if post_zero_count < initial_zero_count:
            total += 0.05

    return total


def test_student_solution():
    total = 0.0

    print("Testing problem 1 - loadSudoku")
    try:
        p1 = test_loadSudoku()
    except:
        p1 = 0.0
    total += p1
    print("Points: {0:.2f} / 1".format(p1))
    print()

    print("Testing problem 2 - findNextEmptyCell")
    try:
        p2 = test_findNextEmptyCell()
    except:
        p2 = 0.0
    total += p2
    print("Points: {0:.2f} / 0.5".format(p2))
    print()

    print("Testing problem 3 - isSolved")
    try:
        p3 = test_isSolved()
    except:
        p3 = 0.0
    total += p3
    print("Points: {0:.2f} / 0.5".format(p3))
    print()

    print("Testing problem 4 - isValid")
    try:
        p4 = test_isValid()
    except:
        p4 = 0.0
    total += p4
    print("Points: {0:.2f} / 0.5".format(p4))
    print()

    print("Testing problem 5 - printSudoku")
    try:
        p5_output = test_printSudoku(sudoku_grids[0])
    except:
        p5_output = None
    print("Function prints:")
    print(p5_output)
    print()

    print("Testing problem 6 - solveSudoku")
    try:
        p6 = test_solveSudoku()
    except:
        p6 = 0.0
    total += p6
    print("Points: {0:.2f} / 2".format(p6))
    print()

    print("Testing problem 7 - fillSure")
    try:
        p7 = test_fillSure(sudoku_grids)
    except:
        p7 = 0.0
    total += p7
    print("Points: {0:.2f} / 1".format(p7))
    print()

    total = p1 + p2 + p3 + p4 + p6 + p7
    print("TOTAL: {0:.2f} / 6.00".format(total))
    print("NOTE: Print sudoku is graded manually - 0.5 points")

    return [p1, p2, p3, p4, p6, p7], p5_output


if __name__ == '__main__':
    test_student_solution()
