from os import listdir
from os.path import join, basename
from io import StringIO
import sys

from random import choices

import problem1 as impl


TESTS = [
    ["test_schedules\\sched1.txt", [10, 10], [11, 10]],
    ["test_schedules\\sched2.txt", [10, 11], [11, 6]],
    ["test_schedules\\sched3.txt", [10, 6], [11, 4]],
    ["test_schedules\\sched4.txt", [10, 6], [11, 6]],
    ["test_schedules\\sched5.txt", [9, 9], [11, 3]]
]
TESTS_W = [
    ["test_schedules_weights\\sched1.txt", [11, 28]],
    ["test_schedules_weights\\sched2.txt", [10, 21]],
    ["test_schedules_weights\\sched3.txt", [10, 12]]
]


def test_load_intervals_1(path):
    """
    Unit test for problem 1 - implementing loadIntervals
    """

    try:
        student_result = impl.loadIntervals(path)
    except AttributeError:
        try:
            student_result = impl.load_intervals(path)
        except AttributeError:
            print("Could not find loadIntervals")
            return 0.0
        except:
            print("Could not execute student solution - loadIntervals")
            return 0.0
    except:
        print("Could not execute student solution - loadIntervals")
        return 0.0

    src_file = open(path, 'r')
    lines = src_file.readlines()
    src_file.close()
    points = 0.0

    # first we check the type of the result
    print("Problem 1 - testing {}".format(basename(path)))
    print("Problem 1 - Checking return types:")
    if type(student_result) != list:
        print("FAILURE: test_problem_1()")
        print("\tUnexpected return type", type(student_result),
              "(expected list)")
    else:
        print("PASSED: got list")
        points += 0.2

    # testing whether the return list is of expected length
    print("Problem 1 - Checking length of return list:")
    if len(student_result) != len(lines):
        print("FAILURE: test_problem_1()")
        print("\tLength of list is not equal to expected ({}): {}"
              .format(len(lines), len(student_result)))
    else:
        print("PASSED: list length is correct")
        points += 0.2

    # checking if list contains only tuples
    print("Problem 2 - Checking type of list elements:")
    errors = [elem for elem in student_result if type(elem) != tuple]
    if len(errors) != 0:
        print("FAILURE: test_problem_1()")
        print("\tList must contain only tuples. Found {} erors."
              .format(len(errors)))
    else:
        print("PASSED: list contains only tuples")
        points += 0.2

    return points


def test_chooseTime(path, result):
    """
    Unit test for problem 2 - implementing chooseTime
    """
    try:
        st_intervals = impl.loadIntervals(path)
        student_time, student_max = impl.chooseTime(st_intervals)
    except AttributeError:
        print("Could not find chooseTime")
        return 0.0
    except:
        print("Could not execute student solution - chooseTime")
        return 0.0

    correct_time, correct_max = result
    points = 0.0
    type_check = False


    # first we check the type of the result
    if type(student_time) != int or type(student_max) != int:
        print("FAILURE: test_problem_2()")
        print("\tUnexpected return types", type(student_time), type(student_max))
    else:
        print("PASSED: got two integers")
        type_check = True

    if student_max == correct_max:
        print("PASSED: got correct return values")
        points = 0.1
    else:
        print("FAILURE: got incorrect return values ({}, {}) instead of ({}, {})"
              .format(student_time, student_max, correct_time, correct_max))

    return type_check, points


def test_whenToGo(path, results):
    saved_stdout = sys.stdout
    try:
        out = StringIO()
        sys.stdout = out

        try:
            impl.whenToGo(path)
        except AttributeError:
            print("Could not find whenToGo")
            raise AssertionError
        except:
            print("Could not execute student solution - whenToGo")
            raise AssertionError
        student_output = out.getvalue().strip()
        out.truncate(0)
        out.seek(0)

        assert "The best time to attend Jedlicka is at" in student_output
        assert "o'clock when you'll meet {} of your friends".format(results[1]) in student_output
    finally:
        sys.stdout = saved_stdout


def test_whenToGoConstrained(path, ystart, yend, results):
    saved_stdout = sys.stdout
    try:
        out = StringIO()
        sys.stdout = out

        try:
            impl.whenToGo(path, ystart, yend)
        except AttributeError:
            print("Could not find whenToGo")
            raise AssertionError
        except:
            print("Could not execute student solution - whenToGo")
            raise AssertionError
        student_output = out.getvalue().strip()
        out.truncate(0)
        out.seek(0)

        assert "The best time to attend Jedlicka is at" in student_output
        assert "o'clock when you'll meet {} of your friends".format(results[1]) in student_output
    finally:
        sys.stdout = saved_stdout


def test_whenToGoWithWeights(path, results):
    saved_stdout = sys.stdout
    try:
        out = StringIO()
        sys.stdout = out

        try:
            impl.whenToGo(path)
        except AttributeError:
            print("Could not find whenToGo")
            raise AssertionError
        except:
            print("Could not execute student solution - whenToGo")
            raise AssertionError
        student_output = out.getvalue().strip()
        out.truncate(0)
        out.seek(0)

        assert "The best time to attend Jedlicka is at" in student_output
        assert "o'clock when you'll meet friends with a weight of {}".format(results[1]) in student_output
    finally:
        sys.stdout = saved_stdout


def test_chooseTimeConstrained(path, ystart, yend, results):
    """
    Unit test for problem 2 - implementing chooseTime
    """
    try:
        intervals = impl.loadIntervals(path)
        student_time, student_max = impl.chooseTimeConstrained(intervals, ystart, yend)
    except AttributeError:
        print("Could not find chooseTimeConstrained")
        return 0.0
    except:
        print("Could not execute student solution - chooseTimeConstrained")
        return 0.0
    correct_time, correct_max = results
    points = 0.0
    type_check = False


    # first we check the type of the result
    if type(student_time) != int or type(student_max) != int:
        print("FAILURE: test_problem_2()")
        print("\tUnexpected return types", type(student_time), type(student_max))
    else:
        print("PASSED: got two integers")
        type_check = True

    if student_max == correct_max:
        print("PASSED: got correct return values")
        points = 0.1
    else:
        print("FAILURE: got incorrect return values ({}, {}) instead of ({}, {}"
              .format(student_time, student_max, correct_time, correct_max))

    return type_check, points


def test_load_intervals_2(path):
    """
    Unit test for problem 1 - implementing loadIntervals
    """

    try:
        student_result = impl.loadIntervals(path)
    except AttributeError:
        try:
            student_result = impl.load_intervals(path)
        except AttributeError:
            print("Could not find loadIntervals")
            return 0.0
        except:
            print("Could not execute student solution - loadIntervals")
            return 0.0
    except:
        print("Could not execute student solution - loadIntervals")
        return 0.0

    src_file = open(path, 'r')
    lines = src_file.readlines()
    src_file.close()
    points = 0.0

    # first we check the type of the result
    print("Problem 1 - Checking return types:")
    if type(student_result) != list:
        print("FAILURE: test_problem_1()")
        print("\tUnexpected return type", type(student_result),
              "(expected list)")
    else:
        print("PASSED: got list")
        points += 0.05

    # testing whether the return list is of expected length
    print("Problem 1 - Checking length of return list:")
    if len(student_result) != len(lines):
        print("FAILURE: test_problem_1()")
        print("\tLength of list is not equal to expected ({}): {}"
              .format(len(lines), len(student_result)))
    else:
        print("PASSED: list length is correct")
        points += 0.05

    # checking if list contains only tuples
    print("Problem 2 - Checking type of list elements:")
    errors = [elem for elem in student_result if type(elem) != tuple]
    if len(errors) != 0:
        print("FAILURE: test_problem_1()")
        print("\tList must contain only tuples. Found {} erors."
              .format(len(errors)))
    else:
        print("PASSED: list contains only tuples")
        points += 0.1

    return points


def test_chooseTimeWithWeights(path, results):
    """
    Unit test for problem 2 - implementing chooseTime
    """
    try:
        intervals = impl.loadIntervals(path)
        student_time, student_max = impl.chooseTimeWithWeights(intervals)
    except AttributeError:
        print("Could not find chooseTimeWithWeights")
        return 0.0
    except:
        print("Could not execute student solution - chooseTimeWithWeights")
        return 0.0

    correct_time, correct_max = results
    points = 0.0
    type_check = False


    # first we check the type of the result
    if type(student_time) != int or type(student_max) != int:
        print("FAILURE: test_problem_2()")
        print("\tUnexpected return types", type(student_time), type(student_max))
    else:
        print("PASSED: got two integers")
        type_check = True

    if student_max == correct_max:
        print("PASSED: got correct return values")
        points = 0.1
    else:
        print("FAILURE: got incorrect return values ({}, {}) instead of ({}, {}"
              .format(student_time, student_max, correct_time, correct_max))

    return type_check, points


def test_problem_1():
    points = list()

    for test_file in TESTS:
        print("testing", basename(test_file[0]))
        try:
            points.append(test_load_intervals_1(test_file[0]))
        except:
            points.append(0.0)
        print("-----\n")

    return sum(points) / len(points)


def test_problem_2():
    points = 0.0
    type_pts = 0.1
    whenToGoPoints = 0.2

    for test_file in TESTS:
        print("TESTING: {}".format(basename(test_file[0])))
        try:
            type_check, pts = test_chooseTime(test_file[0], test_file[1])
        except:
            type_check, pts = True, 0.0
        points += pts
        if not type_check:
            type_pts = 0.0

        try:
            test_whenToGo(test_file[0], test_file[1])
        except AssertionError:
            print("error")
            whenToGoPoints = 0.0

    print(points, type_pts, whenToGoPoints)

    return points + type_pts + whenToGoPoints


def test_problem_3():
    points = 0.0
    type_pts = 0.1
    whenToGoPoints = 0.2

    for test_file in TESTS:
        try:
            type_check, pts = test_chooseTimeConstrained(test_file[0], 11, 1, test_file[2])
        except:
            type_check, pts = True, 0.0
        points += pts
        if not type_check:
            type_pts = 0.0

        try:
            test_whenToGoConstrained(test_file[0], 11, 1, test_file[2])
        except AssertionError:
            print("error")
            whenToGoPoints = 0.0

    print(points, type_pts, whenToGoPoints)

    return points + type_pts + whenToGoPoints


def test_problem_4():
    points = 0.0
    whenToGoPoints = 0.2
    load_points = list()
    type_pts = 0.1

    for test_file in TESTS_W:
        load_points.append(test_load_intervals_2(test_file[0]))
        try:
            type_check, pts = test_chooseTimeWithWeights(test_file[0], test_file[1])
        except:
            type_check, pts = True, 0.0
        points += pts
        if not type_check:
            type_pts = 0.0

        try:
            test_whenToGoWithWeights(test_file[0], test_file[1])
        except AssertionError:
            whenToGoPoints = 0.0

    print(points, type_pts, whenToGoPoints, load_points)

    return points + type_pts + whenToGoPoints + sum(load_points) / len(load_points)


def test_student_solution():
    print("Testing problem 1 - loadIntervals")
    print()
    p1 = test_problem_1()
    print("Points: {0:.2f} / 0.6".format(p1))

    print("Testing problem 2 - chooseTime and whenToGo")
    print()
    p2 = test_problem_2()
    print("Points: {0:.2f} / 0.8".format(p2))

    print("Testing problem 3 - chooseTimeConstrained")
    print()
    p3 = test_problem_3()
    print("Points: {0:.2f} / 0.8".format(p3))

    print("Testing problem 4 - test_chooseTimeWithWeights")
    print()
    p4 = test_problem_4()
    print("Points: {0:.2f} / 0.8".format(p4))

    print("TOTAL POINTS: {0:.2f} / 3".format(p1 + p2 + p3 + p4))

    return [p1, p2, p3, p4]


if __name__ == '__main__':
    test_student_solution()
