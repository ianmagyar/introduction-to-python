# -*- coding: utf-8 -*-

# Zadanie 1 - Kedy na Jedlicku?

# Meno: Ján Magyar
# Spolupráca: -
# Použité zdroje: Sample solution
# Čas: 


def loadIntervals(path):
    try:
        src_file = open(path, 'r')
    except FileNotFoundError:
        print("Could not open file specified. Path does not exist:", path)
        return

    lines = src_file.readlines()
    lines[-1] += '\n'
    intervals = list()

    for line in lines:
        values = line[:-1].split(',')
        if len(values) != 3 and len(values) != 4:
            print("Wrong formatting of source file. Line must have 3 or 4 values.")
            return
        try:
            values[1] = int(values[1])
            values[2] = int(values[2])
            values[3] = int(values[3])
        except ValueError:
            print("Wrong formatting of source file.")
            return
        except IndexError:
            pass

        if len(values) == 3:
            intervals.append((values[1], values[2]))
        else:
            intervals.append((values[1], values[2], values[3]))

    return intervals


def process_intervals(interval_list):
    intervals = list()

    for time in interval_list:
        if len(time) == 2:
            intervals.append((time[0], 'start'))
            if time[1] < time[0]:
                intervals.append((time[1] + 12, 'end'))
            else:
                intervals.append((time[1], 'end'))
        else:
            intervals.append((time[0], 'start', time[2]))
            if time[1] < time[0]:
                intervals.append((time[1] + 12, 'end', time[2]))
            else:
                intervals.append((time[1], 'end', time[2]))

    intervals.sort()

    return intervals


def whenToGo(path, ystart=None, yend=None):
    # load intervals from path
    # call function to calculate best time for party
    # print results
    intervals = loadIntervals(path)
    if len(intervals[0]) != 2:
        time, weight = chooseTimeWithWeights(intervals)
        print("The best time to attend Jedlicka is at {} o'clock when you'll meet friends with a weight of {}."
              .format(time, weight))
        return
    if ystart is None and yend is None:
        time, student_count = chooseTime(intervals)
    else:
        time, student_count = chooseTimeConstrained(intervals, ystart, yend)

    print("The best time to attend Jedlicka is at {} o'clock when you'll meet {} of your friends"
          .format(time, student_count))
    return


def chooseTime(interval_list):
    # return best time to party and number of friends present
    intervals = process_intervals(interval_list)

    student_count = 0
    max_count = 0
    time = 0

    # Range through the times computing a running count of celebrities
    for t in intervals:
        if t[1] == 'start':
            student_count += 1
        elif t[1] == 'end':
            student_count -= 1
        if student_count > max_count:
            max_count = student_count
            time = t[0]

    if time > 12:
        time -= 12

    return time, max_count


def chooseTimeConstrained(interval_list, ystart, yend):
    # return best time to party and number of friends present
    # look only in interval <ystart, yend)
    intervals = process_intervals(interval_list)

    if yend < ystart:
        yend += 12

    student_count = 0
    max_count = 0
    time = 0

    # Range through the times computing a running count of celebrities
    for t in intervals:
        if t[1] == 'start':
            student_count += 1
        elif t[1] == 'end':
            student_count -= 1
        if student_count > max_count and t[0] >= ystart and t[0] < yend:
            max_count = student_count
            time = t[0]
        # print("At time {} I'll meet {} students, max is {}"
        #       .format(t[0], student_count, max_count))

    if time > 12:
        time -= 12

    return time, max_count


def chooseTimeWithWeights(interval_list):
    # return best time to party and total weight
    intervals = process_intervals(interval_list)

    total_weight = 0
    max_weight = 0
    time = 0

    # Range through the times computing a running count of celebrities
    for t in intervals:
        if t[1] == 'start':
            total_weight += t[2]
        elif t[1] == 'end':
            total_weight -= t[2]
        if total_weight > max_weight:
            max_weight = total_weight
            time = t[0]
        # print("At time {} I'll meet {} weights, max is {}"
        #       .format(t[0], total_weight, max_weight))

    if time > 12:
        time -= 12

    return time, max_weight


if __name__ == '__main__':
    from os import listdir
    from os.path import join

    src_dir = "C:\\Users\\Ian\\Desktop\\test_suite\\test_schedules_weights"
    files = [join(src_dir, x) for x in listdir(src_dir)]

    for f in files:
        print(f)
        print("LOAD INTERVALS results:")
        intervals = loadIntervals(f)
        print(intervals)
        print("CHOOSETIME results:")
        print(chooseTime(intervals))
        print(f)
        whenToGo(f)
        print("-----")
