# -*- coding: utf-8 -*-

# Zadanie 1.2 - Sudoku Solver

# Meno: Ján Magyar
# Spolupráca: -
# Použité zdroje: Sample solution
# Čas: 

sectors = [[0, 3, 0, 3], [3, 6, 0, 3], [6, 9, 0, 3],
           [0, 3, 3, 6], [3, 6, 3, 6], [6, 9, 3, 6],
           [0, 3, 6, 9], [3, 6, 6, 9], [6, 9, 6, 9]]


def loadSudoku(grid_string):
    # the function loads a string representing a grid and returns it as a list
    if type(grid_string) != str or len(grid_string) != 81:
        print("Incorrect input. Input must be string of length 81.")
        return

    for num in grid_string:
        if num not in "0123456789":
            print("Incorrect input. Input can only contain digits between 0 and 9")
            return

    grid = [[0 for j in range(9)] for i in range(9)]
    for x in range(len(grid_string)):
        new_row = x // 9
        new_col = x % 9

        grid[new_row][new_col] = int(grid_string[x])

    return grid


def findNextEmptyCell(grid):
    # this function finds the next empty cell and returns its coordinates
    for x in range(0, 9):
        for y in range(0, 9):
            if grid[x][y] == 0:
                return x, y
    return -1, -1


def isSolved(grid):
    # this function returns True if sudoku puzzle is solved, False otherwise
    i, j = findNextEmptyCell(grid)
    if i != -1 and j != -1:
        return False

    # check rows
    for row in grid:
        if len(set(row)) != 9:
            return False
        if set(row) != {1, 2, 3, 4, 5, 6, 7, 8, 9}:
            return False

    # check cols
    for i in range(9):
        col = [row[i] for row in grid]
        if len(set(col)) != 9:
            return False
        if set(col) != {1, 2, 3, 4, 5, 6, 7, 8, 9}:
            return False

    # check sectors
    for rows in [range(0, 3), range(3, 6), range(6, 9)]:
        for cols in [range(0, 3), range(3, 6), range(6, 9)]:
            sector = [grid[i][j] for i in rows for j in cols]
            if len(set(sector)) != 9:
                return False
            if set(sector) != {1, 2, 3, 4, 5, 6, 7, 8, 9}:
                return False

    return True


def isValid(grid, i, j, e):
    # the function checks if cell (i, j) could be set to value e
    if type(e) != int or type(i) != int or type(j) != int:
        raise TypeError("e, j, and i must be integers")
    if i < 0 or i > 8 or j < 0 or j > 8 or e < 1 or e > 9:
        raise ValueError("i and j must be between 0 and 8; e must be between 1 and 9")

    rowOk = all([e != grid[i][x] for x in range(9)])
    if rowOk:
        columnOk = all([e != grid[x][j] for x in range(9)])
        if columnOk:
            # finding the top left x,y co-ordinates of
            # the section or sub-grid containing the i,j cell
            secTopX, secTopY = 3 * (i // 3), 3 * (j // 3)
            for x in range(secTopX, secTopX + 3):
                for y in range(secTopY, secTopY + 3):
                    if grid[x][y] == e:
                        return False
            return True
    return False


def fillSure(grid):
    # the function fills each cell where only one value is possible
    return grid


def makeImplications(grid, i, j, e):

    global sectors

    grid[i][j] = e
    impl = [(i, j, e)]

    done = False

    # Keep going till you stop finding implications
    while not done:
        done = True

        for k in range(len(sectors)):

            sectinfo = []

            # find missing elements in ith sector
            vset = {1, 2, 3, 4, 5, 6, 7, 8, 9}
            for x in range(sectors[k][0], sectors[k][1]):
                for y in range(sectors[k][2], sectors[k][3]):
                    if grid[x][y] != 0:
                        vset.remove(grid[x][y])

            # attach copy of vset to each missing square in ith sector
            for x in range(sectors[k][0], sectors[k][1]):
                for y in range(sectors[k][2], sectors[k][3]):
                    if grid[x][y] == 0:
                        sectinfo.append([x, y, vset.copy()])

            for m in range(len(sectinfo)):
                sin = sectinfo[m]

                # find the set of elements on the row corresponding to m and remove them
                rowv = set()
                for y in range(9):
                    rowv.add(grid[sin[0]][y])
                left = sin[2].difference(rowv)

                # find the set of elements on the column corresponding to m and remove them
                colv = set()
                for x in range(9):
                    colv.add(grid[x][sin[1]])
                left = left.difference(colv)

                # check if the vset is a singleton
                if len(left) == 1:
                    val = left.pop()
                    if isValid(grid, sin[0], sin[1], val):
                        grid[sin[0]][sin[1]] = val
                        impl.append((sin[0], sin[1], val))
                        done = False

    return impl


def undoImplications(grid, impl):
    for i in range(len(impl)):
        grid[impl[i][0]][impl[i][1]] = 0
    return


def solve_helper(grid):
    i, j = findNextEmptyCell(grid)
    if i == -1:
        return True

    for e in range(1, 10):
        # Try different values in i, j location
        if isValid(grid, i, j, e):

            impl = makeImplications(grid, i, j, e)

            if solve_helper(grid):
                return grid
            # Undo the current cell for backtracking
            undoImplications(grid, impl)

    return False


def solveSudoku(grid_string):
    # the main function that loads the sudoku and solves the grid
    grid = loadSudoku(grid_string)
    if grid is None:
        return None

    grid = solve_helper(grid)

    return grid


def printSudoku(grid):
    # the function prints out a grid of sudoku puzzle
    for row in grid:
        row_str = ""
        for digit in row:
            row_str += "{} ".format(digit)
        print(row_str[:-1])


if __name__ == '__main__':
    f = open("sudokus.txt")
    lines = f.readlines()
    f.close()

    for line in lines:
        grid = loadSudoku(line[:-1])
        # print(grid)
        print(findNextEmptyCell(grid))
        # grid = solveSudoku(line[:-1])
        # if grid is not None:
        #     printSudoku(grid)
        #     if not isSolved(grid):
        #         raise ValueError("Could not solve a sudoku")
        #     print()
