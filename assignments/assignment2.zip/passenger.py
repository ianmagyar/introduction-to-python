class Passenger:
    def __init__(self, row, seat, no_of_bags):
        if seat not in ['A', 'B', 'C', 'D', 'E', 'F']:
            raise ValueError("Seat must be a letter from A to F")

        self.row = row
        self.seat = seat
        self.bags = no_of_bags * 4

        self.plane = None
        self.current_position = [None, None]

    def __str__(self):
        return "<Passenger in seat: {}{}>".format(self.row, self.seat)

    def get_position(self):
        # TODO
        return None, None

    def get_seat(self):
        # TODO
        return None, None

    def add_to_plane(self, plane):
        # TODO
        pass

    def can_sit(self):
        # TODO
        return True

    def forced_to_move(self, x, y):
        # TODO
        pass

    def move(self):
        # TODO
        return None, None
