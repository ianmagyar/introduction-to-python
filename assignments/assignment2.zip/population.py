class Population:
    def __init__(self, n, friends_count):
        self.people = list()
        self.active_news = list()

        self.generate_population(n, friends_count)

    def generate_population(self, n, friends_count):
        pass

    def introduce_news(self, news):
        return

    def update_news(self, time_step):
        pass

    def count_readers(self, news):
        return

    def get_number_of_interested(self, category):
        return


class HomogeneousPopulation(Population):
    def __init__(self, n, friends_count, category):
        self.category = category
        super().__init__(n, friends_count)

    def generate_population(self, n, friends_count):
        pass
