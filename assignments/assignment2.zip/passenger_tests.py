from passenger import Passenger
from plane import Plane
from random import randint


def test_get_position():
    # testing with plane None:
    print("Passenger - testing get_position():")
    test_p = Passenger(9, "D", 2)
    assert test_p.get_position() is None, "\tPassenger was not added to a plane yet, return value should be None"

    # testing when plane was added
    plane = Plane(12)
    test_p.add_to_plane(plane)

    for x in range(5):
        i = randint(1, 12)
        j = randint(0, 6)
        test_p.current_position = [i, j]
        res_j, res_i = test_p.get_position()
        assert res_j == j and res_i == i, "\tIncorrect result; expected {} {}, got {} {}".format(i, j, res_i, res_j)

    print("Passenger - testing get_position() finished; correct solution")


def test_get_seat():
    print("Passenger - testing get_seat():")
    test_inp = [[8, "A"], [4, "B"], [3, "C"], [4, "E"], [5, "F"]]
    test_outp = [[6, 8], [5, 4], [4, 3], [1, 4], [0, 5]]

    for x in range(len(test_inp)):
        test_p = Passenger(test_inp[x][0], test_inp[x][1], 4)
        i, j = test_outp[x]
        real_i, real_j = test_p.get_seat()
        assert i == real_i and j == real_j, "\tIncorrect result; expected {} {}, got {} {}".format(i, j, real_i, real_j)

    print("Passenger - testing get_seat() finished; correct solution")


def test_add_to_plane():
    print("Passenger - testing add_to_plane():")
    test_p = Passenger(9, "D", 4)
    plane = Plane(12)

    test_p.add_to_plane(plane)

    assert test_p.plane == plane, "\tMethod should update plane attribute of passenger"

    pos_i, pos_j = test_p.get_position()
    assert pos_i == 3 and pos_j == 0, "\tMethod should update passenger's position to [0, 3], got [{}, {}]".format(pos_j, pos_i)

    print("Passenger - testing add_to_plane() finished; correct solution")


def test_can_sit():
    print("Passenger - testing can_sit():")

    plane = Plane(4)
    test_p = Passenger(2, "D", 2)

    test_p.add_to_plane(plane)
    test_p.current_position = [2, 3]
    plane.seats[3][2].append(test_p)

    assert test_p.can_sit() is True, "\tMethod should return True for passengers sitting next to the aisle"

    test_p.seat = "E"
    plane.seats[2][2].append(Passenger(2, "D", 0))

    assert test_p.can_sit() is False, "\tMethod should return False if there is someone sitting between the passenger and his seat"

    print("Passenger - testing can_sit() finished; correct solution")


def test_forced_to_move():
    print("Passenger - testing forced_to_move():")

    test_p = Passenger(9, "D", 0)
    test_p.add_to_plane(Plane(20))
    for x in range(5):
        i = randint(1, 10)
        j = randint(0, 6)
        test_p.forced_to_move(j, i)
        res_j, res_i = test_p.get_position()

        assert res_j == j and res_i == i, "\tMethod should update current_position to [{}, {}]; got [{}, {}]".format(i, j, res_i, res_j)

    print("Passenger - testing forced_to_move() finished; correct solution")


def test_move():
    print("Passenger - testing move():")

    test_p = Passenger(3, "E", 4)
    plane = Plane(20)
    test_p.add_to_plane(plane)
    plane.seats[3][0].append(test_p)
    plane.seats[3][2].append(Passenger(3, "C", 0))
    plane.seats[2][3].append(Passenger(3, "D", 0))

    # path is clear
    new_r, new_s = test_p.move()
    assert new_r == 1 and new_s == 3, "\tPassenger should move one step forward when path is clear; expected 1, 3; got {}, {}".format(new_r, new_s)

    # move passenger forward; path is blocked
    test_p.current_position = [1, 3]
    plane.seats[3][0].remove(test_p)
    plane.seats[3][1].append(test_p)
    new_r, new_s == test_p.move()
    assert new_r == 1 and new_s == 3, "\tPassenger should not move when path is blocked; expected 2, 3; got {}, {}".format(new_r, new_s)

    # move passenger to his seat's row; path is blocked
    test_p.current_position = [3, 3]
    plane.seats[3][1].append(test_p)
    plane.seats[3][3].append(test_p)
    new_r, new_s = test_p.move()
    assert new_r == 3 and new_s == 3, "\tPassenger should not move when someone is sitting between him and his seat; expected 3, 3; got {}, {}".format(new_r, new_s)

    # remove passenger in way, passenger has bags
    plane.seats[2][3].clear()
    new_r, new_s = test_p.move()
    assert new_r == 3 and new_s == 3, "\tPassenger should not move when he still has bags; expected 3, 3; got {}, {}".format(new_r, new_s)

    test_p.bags = 0
    new_r, new_s = test_p.move()
    assert new_r == 3 and new_s == 1, "\tPassenger should sit down when path is clear; expected 3, 1; got {}, {}".format(new_r, new_s)

    print("Passenger - testing move() finished; correct solution")


def test_passenger():
    test_get_position()

    test_get_seat()

    test_add_to_plane()

    test_can_sit()

    test_forced_to_move()

    test_move()


if __name__ == '__main__':
    test_passenger()
