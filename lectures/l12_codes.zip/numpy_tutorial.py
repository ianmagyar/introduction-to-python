import numpy as np


my_array = np.array([2, 3, 4, 5])
print(my_array)

print(my_array.dtype)
print(my_array.shape)

my_2d_array = np.reshape(my_array, (2, 2))
print(my_2d_array)

print(my_2d_array.flatten())

# print(np.zeros((2, 3)))
# print(np.ones((2, 3)))

my_column = np.array([6, 7])
my_column = np.reshape(my_column, (2, 1))

my_2d_array = np.hstack((my_column, my_2d_array))
print(my_2d_array)

my_row = np.array([8, 9, 1])
my_row = np.reshape(my_row, (1, 3))

my_2d_array = np.vstack((my_row, my_2d_array))
print(my_2d_array)

# print(my_2d_array[0])
# print(my_2d_array[:, 1])
# print(my_2d_array[1, :2])

# print(my_2d_array + 2)

# print(np.min(my_2d_array))
# print(np.max(my_2d_array))
# print(np.mean(my_2d_array))
# print(np.median(my_2d_array))
# print(np.std(my_2d_array))

# print(my_2d_array)
# print(np.transpose(my_2d_array))

# my_3d_array = np.array([[[1], [3]], [[4], [8]], [[5], [7]]])
# print(my_3d_array)
# print(my_3d_array.shape)
# transposed = np.transpose(my_3d_array, (1, 0, 2))
# print(transposed)
# print(transposed.shape)

# v1 = np.array([1, 2, 3])
# v2 = np.array([4, 5, 6])
# print(np.dot(v1, v2))

# m1 = np.array([[2, 3, 4], [5, 6, 7]])
# m2 = np.array([[2, 5, 3], [4, 6, 1], [7, 3, 2]])
# print(np.matmul(m1, m2))


print(np.arange(1, 11, 1))
print(np.linspace(1, 100, 20))
