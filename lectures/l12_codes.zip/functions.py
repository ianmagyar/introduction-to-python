def power2(val):
    return val ** 2


def power3(val):
    return val ** 3


def power4(val):
    return val ** 4


def conditionals_power(val, power):
    if power == 2:
        return power2(val)
    elif power == 3:
        return power3(val)
    elif power == 4:
        return power4(val)
    else:
        raise ValueError("No function defined for power {}".format(power))


def function_power(val, power):
    if power == 2:
        call = power2
    elif power == 3:
        call = power3
    elif power == 4:
        call = power4
    else:
        raise ValueError("No function defined for power {}".format(power))

    return call(val)


def function_power2(val, power_func):
    return power_func(val)


print(function_power(5, 2))
print(function_power2(5, power2))
