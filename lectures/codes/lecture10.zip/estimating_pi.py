import math
import random

import matplotlib.pyplot as plt
from numpy import arange


def calculate_pi(in_circle, total):
    return 4 * (in_circle / float(total))


def is_in_circle(x, y):
    # get distance of [x, y] from [0, 0]
    distance = math.sqrt(x ** 2 + y ** 2)
    # if distance is <= 1, return True, else False
    return distance <= 1


def throw_darts(num_darts, show_plot):
    in_circle = 0
    estimates = list()

    for i in range(num_darts):
        # generate a random number in a square with side 1
        x = random.random()
        y = random.random()

        # update number of points in circle
        in_circle += is_in_circle(x, y)
        # if is_in_circle(x, y):
        #     in_circle += 1

        # estimate the value of pi from number of points
        if show_plot:
            estimate = calculate_pi(in_circle, i + 1)
            estimates.append(estimate)
        if (i + 1) % 10000 == 0:
            print("Estimate of pi after {} iterations is {}".format(
                i + 1, calculate_pi(in_circle, i + 1)))

    # print(estimates)
    if show_plot:
        plot_estimates(estimates)

    return estimates[-1]


def plot_estimates(estimates):
    X = arange(1, len(estimates) + 1)
    # plt.plot(X, estimates)
    plt.semilogx(X, estimates)
    plt.xlabel("Number of darts")
    plt.ylabel("Estimate of pi")
    plt.title("Final estimate of pi: {:.5f} (real value: {:.5f})".format(
        estimates[-1], math.pi))
    plt.axhline(3.14159, color='green')
    plt.show()


if __name__ == '__main__':
    darts = 1000000
    pi_guess = throw_darts(darts, True)
    print("Estimated value of pi with {} darts is {} (real value: {})".format(
        darts, pi_guess, math.pi))
