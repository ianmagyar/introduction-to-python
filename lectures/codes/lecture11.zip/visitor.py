class Item:
    def accept(self, visitor):
        pass

class Electronics(Item):
    def __init__(self, price):
        self.price = price

    def accept(self, visitor):
        visitor.visit_electronics(self)

class Clothing(Item):
    def __init__(self, price):
        self.price = price

    def accept(self, visitor):
        visitor.visit_clothing(self)

class TaxVisitor:
    def visit_electronics(self, electronics):
        pass

    def visit_clothing(self, clothing):
        pass

class USATaxVisitor(TaxVisitor):
    def visit_electronics(self, electronics):
        tax = electronics.price * 0.10
        print(f"USA Tax on Electronics: ${tax:.2f} for ${electronics.price}")

    def visit_clothing(self, clothing):
        tax = clothing.price * 0.05
        print(f"USA Tax on Clothing: ${tax:.2f} for ${clothing.price}")

class CanadaTaxVisitor(TaxVisitor):
    def visit_electronics(self, electronics):
        tax = electronics.price * 0.13
        print(f"Canada Tax on Electronics: ${tax:.2f} for ${electronics.price}")

    def visit_clothing(self, clothing):
        tax = clothing.price * 0.08
        print(f"Canada Tax on Clothing: ${tax:.2f} for ${clothing.price}")

if __name__ == "__main__":
    electronics = Electronics(1000)
    clothing = Clothing(50)

    usa_tax_visitor = USATaxVisitor()
    canada_tax_visitor = CanadaTaxVisitor()

    print("Calculating Taxes in the USA:")
    electronics.accept(usa_tax_visitor)
    clothing.accept(usa_tax_visitor)

    print("\nCalculating Taxes in Canada:")
    electronics.accept(canada_tax_visitor)
    clothing.accept(canada_tax_visitor)
