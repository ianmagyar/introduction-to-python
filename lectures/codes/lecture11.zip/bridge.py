class DrawingAPI1:
    def draw_circle(self, x, y, radius):
        print("API1 drawing circle at ({}, {}) with radius {}".format(x, y, radius))

class DrawingAPI2:
    def draw_circle(self, x, y, radius):
        print("API2 drawing circle at ({}, {}) with radius {}".format(x, y, radius))

class Shape:
    def __init__(self, drawing_api):
        self.drawing_api = drawing_api

    def draw(self):
        pass

    def resize_by_percentage(self, percent):
        pass

class CircleShape(Shape):
    def __init__(self, x, y, radius, drawing_api):
        super().__init__(drawing_api)
        self.x = x
        self.y = y
        self.radius = radius

    def draw(self):
        self.drawing_api.draw_circle(self.x, self.y, self.radius)

    def resize_by_percentage(self, percent):
        self.radius *= percent / 100.0
