def simple_example(param: int) -> str:
    return str(param)


result = simple_example('5')
print(result)

# print(simple_example.__annotations__)

# reveal_type(result)

# reveal_locals()


# def no_return_type(to_print: str) -> None:
#     print(to_print)


# check = no_return_type("bla")
# print(check)
