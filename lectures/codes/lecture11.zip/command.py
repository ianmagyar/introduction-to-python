class Action:
    def execute(self):
        pass

class LightOnCommand(Action):
    def __init__(self, light):
        self.light = light

    def execute(self):
        self.light.turn_on()

class LightOffCommand(Action):
    def __init__(self, light):
        self.light = light

    def execute(self):
        self.light.turn_off()

class MusicPlayCommand(Action):
    def __init__(self, music_player):
        self.music_player = music_player

    def execute(self):
        self.music_player.play()

class MusicStopCommand(Action):
    def __init__(self, music_player):
        self.music_player = music_player

    def execute(self):
        self.music_player.stop()

class Light:
    def turn_on(self):
        print("Light is ON")

    def turn_off(self):
        print("Light is OFF")

class MusicPlayer:
    def play(self):
        print("Music is playing")

    def stop(self):
        print("Music has stopped")

class RemoteControl:
    def __init__(self):
        self.command = None

    def set_command(self, command):
        self.command = command

    def press_button(self):
        self.command.execute()

def smart_house():
    light = Light()
    music_player = MusicPlayer()

    light_on = LightOnCommand(light)
    light_off = LightOffCommand(light)
    play_music = MusicPlayCommand(music_player)
    stop_music = MusicStopCommand(music_player)

    remote = RemoteControl()

    remote.set_command(light_on)
    remote.press_button()

    remote.set_command(play_music)
    remote.press_button()

    remote.set_command(stop_music)
    remote.press_button()

    remote.set_command(light_off)
    remote.press_button()
