from typing import List, Sequence, Any, TypeVar, Callable
import random


# works only for integers
# def choose_int(choose_from: List[int]) -> int:
#     return random.choice(choose_from)


# vals = [2, 3, 4]
# reveal_type(vals)
# chosen = choose_int(vals)
# reveal_type(chosen)


# works generally, no info on return type
# def choose_item(choose_from: List[Any]) -> Any:
#     return random.choice(choose_from)


# vals = ["one", "two", "three"]
# reveal_type(vals)
# chosen = choose_item(vals)
# reveal_type(chosen)


# now we get information on the return type as well
# Choosable = TypeVar("Choosable")


# def choose_item(choose_from: Sequence[Choosable]) -> Choosable:
#     return random.choice(choose_from)


# vals = [1, 2, 3]
# reveal_type(vals)
# chosen = choose_item(vals)
# reveal_type(chosen)
# reveal_type(choose_item(['one', 'two', 'three']))


# we want it to work for numbers only
# Choosable = TypeVar("Choosable", int, float)


# def choose_item(choose_from: Sequence[Choosable]) -> Choosable:
#     return random.choice(choose_from)


# vals = [1, 2, 3]
# reveal_type(vals)
# chosen = choose_item(vals)
# reveal_type(chosen)
# reveal_type(choose_item(['one', 'two', 'three']))


# functions as paremeters
def repeat_it(func: Callable[[str], None], argument: str, count: int) -> None:
    for _ in range(count):
        func(argument)


def simple_print(to_print: str) -> None:
    print(to_print)


repeat_it(simple_print, "Hello", 3)
