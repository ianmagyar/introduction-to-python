class CPU:
    def freeze(self):
        print("Freezing processor")

    def jump(self, position):
        print("Jumping to address", position)

    def execute(self):
        print("Executing instructions")

class Memory:
    def load(self, position, data):
        print("Loading data '{}' into address {}".format(data, position))

class HardDrive:
    def read(self, sector):
        print("Reading data from sector", sector)
        return "boot_data"

class Computer:
    def __init__(self):
        self.cpu = CPU()
        self.memory = Memory()
        self.hard_drive = HardDrive()

    def start(self):
        self.cpu.freeze()
        data = self.hard_drive.read("0x1FF")
        self.memory.load("0x00", data)
        self.cpu.jump("0x00")
        self.cpu.execute()

def startup():
    computer = Computer()
    computer.start()
