class Meal:
    def __init__(self):
        self.items = []

    def add_item(self, item):
        self.items.append(item)

    def show(self):
        for item in self.items:
            print("- " + item)

class MealBuilder:
    def __init__(self):
        self.meal = Meal()

    def add_main_item(self):
        pass

    def add_drink(self):
        pass

    def add_dessert(self):
        pass

    def get_meal(self):
        return self.meal

class VegMealBuilder(MealBuilder):
    def add_main_item(self):
        self.meal.add_item("Veggie Burger")

    def add_drink(self):
        self.meal.add_item("Orange Juice")

    def add_dessert(self):
        self.meal.add_item("Fruit Salad")

class NonVegMealBuilder(MealBuilder):
    def add_main_item(self):
        self.meal.add_item("Chicken Sandwich")

    def add_drink(self):
        self.meal.add_item("Cola")

    def add_dessert(self):
        self.meal.add_item("Ice Cream")

class MealDirector:
    def __init__(self, builder):
        self.builder = builder

    def construct_meal(self):
        self.builder.add_main_item()
        self.builder.add_drink()
        self.builder.add_dessert()
        return self.builder.get_meal()
