class Document:
    def display(self):
        pass

class ConfidentialReport(Document):
    def display(self):
        print("ConfidentialReport: Displaying sensitive content")

class ReportProxy(Document):
    def __init__(self, real_report):
        self.real_report = real_report
        self.access_granted = False

    def login(self, password):
        if password == "admin123":
            self.access_granted = True

    def display(self):
        if self.access_granted:
            print("ReportProxy: Access granted")
            self.real_report.display()
        else:
            print("ReportProxy: Access denied")

def login():
    report = ConfidentialReport()
    proxy = ReportProxy(report)

    print("Trying to view without login:")
    proxy.display()

    print("\nLogging in and trying again:")
    proxy.login("admin123")
    proxy.display()
