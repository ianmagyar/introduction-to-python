import urllib.request

from bs4 import BeautifulSoup


fp = urllib.request.urlopen('http://fei.tuke.sk/sk/studium/aktuality')
code = fp.read()
fp.close()

soup = BeautifulSoup(code, 'html.parser')

print(soup.title)
print(soup.body)

# list_of_news = soup.body.find('div', {'class': 'wg-top'})

# for elem in list_of_news.find_all('div', {'class': 'article default'}):
#     print(elem)
#     print('---')
