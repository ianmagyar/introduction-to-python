from selenium.webdriver import Firefox
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support.expected_conditions import presence_of_element_located, element_to_be_clickable

browser = Firefox()
wait = WebDriverWait(browser, 10)


# let me google that for you
browser.get('https://google.com')

# handles = browser.window_handles
# browser.switch_to.window(handles[-1])
# browser.close()
# browser.switch_to.window(handles[0])


element = browser.find_element(By.NAME, "q")
element.send_keys("never gonna give you up")

element.send_keys(Keys.RETURN)
wait.until(presence_of_element_located((By.CLASS_NAME, "yuRUbf")))

elements = browser.find_elements(By.CLASS_NAME, "yuRUbf")

first_result = elements[0]
link = first_result.find_element_by_tag_name('a')
browser.get(link.get_attribute('href'))

wait.until(element_to_be_clickable((By.CSS_SELECTOR, 'button.VfPpkd-LgbsSe-OWXEXe-dgl2Hf')))
agree_button = browser.find_element(By.CSS_SELECTOR, 'button.VfPpkd-LgbsSe-OWXEXe-dgl2Hf')
agree_button.click()

wait.until(element_to_be_clickable((By.CLASS_NAME, 'ytp-large-play-button')))
play_button = browser.find_element(By.CLASS_NAME, 'ytp-large-play-button')
play_button.click()

wait.until(element_to_be_clickable((By.CLASS_NAME, 'ytp-fullscreen-button')))
play_button = browser.find_element(By.CLASS_NAME, 'ytp-fullscreen-button')
play_button.click()
