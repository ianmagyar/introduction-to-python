from selenium.webdriver import Firefox
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support.expected_conditions import presence_of_element_located


browser = Firefox()
wait = WebDriverWait(browser, 10)

# we simply open a web site
browser.get('https://www.google.com')

# we interact with a web site
# browser.get('https://mail.tuke.sk/owa/auth/logon.aspx?replaceCurrent=1&url=https%3a%2f%2fmail.tuke.sk%2fowa%2f')

# # we enter login information
# element = browser.find_element_by_id('username')
# element.send_keys("ab123xy")

# element = browser.find_element_by_id('password')
# element.send_keys("heslo")

# # we press the ENTER button
# element.send_keys(Keys.RETURN)

# # we click on a button
# wait.until(presence_of_element_located((By.ID, 'O365_MainLink_NavMenu')))
# menu_button = browser.find_element_by_id('O365_MainLink_NavMenu')
# menu_button.click()
