class Mediator:
    def send(self, message, colleague):
        pass

class ChatRoom(Mediator):
    def __init__(self):
        self.colleagues = []

    def add_colleague(self, colleague):
        self.colleagues.append(colleague)

    def send(self, message, colleague):
        for c in self.colleagues:
            if c != colleague:
                c.receive(message)

class Colleague:
    def __init__(self, mediator, name):
        self.mediator = mediator
        self.name = name
        mediator.add_colleague(self)

    def send(self, message):
        print(f"{self.name} sends: {message}")
        self.mediator.send(message, self)

    def receive(self, message):
        print(f"{self.name} receives: {message}")

if __name__ == "__main__":
    chatroom = ChatRoom()

    john = Colleague(chatroom, "John")
    jane = Colleague(chatroom, "Jane")
    alice = Colleague(chatroom, "Alice")

    john.send("Hi everyone!")
    jane.send("Hello John!")
    alice.send("Hey John and Jane!")
