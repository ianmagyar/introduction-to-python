def make_power_of(n):
    def power_of(x):
        return x ** n

    return power_of


power2 = make_power_of(2)
power3 = make_power_of(3)

print(power2(2))
print(power3(2))

print(make_power_of(2)(3))

# del make_power_of

# print(power2(2))
# print(power3(2))
# print(make_power_of(2))
