class Observer:
    def update(self, temperature):
        pass

class WeatherStation:
    def __init__(self):
        self._observers = []
        self._temperature = None

    def add_observer(self, observer):
        self._observers.append(observer)

    def remove_observer(self, observer):
        self._observers.remove(observer)

    def set_temperature(self, temperature):
        self._temperature = temperature
        self._notify_observers()

    def _notify_observers(self):
        for observer in self._observers:
            observer.update(self._temperature)

class PhoneDisplay(Observer):
    def update(self, temperature):
        print(f"PhoneDisplay: The current temperature is {temperature}°C.")

class LaptopDisplay(Observer):
    def update(self, temperature):
        print(f"LaptopDisplay: The current temperature is {temperature}°C.")

class WindowDisplay(Observer):
    def update(self, temperature):
        print(f"WindowDisplay: The current temperature is {temperature}°C.")
