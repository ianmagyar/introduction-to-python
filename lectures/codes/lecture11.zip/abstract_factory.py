class WindowsButton:
    def click(self):
        return "Windows Button clicked"

class MacButton:
    def click(self):
        return "Mac Button clicked"

class WindowsCheckbox:
    def check(self):
        return "Windows Checkbox checked"

class MacCheckbox:
    def check(self):
        return "Mac Checkbox checked"

class WindowsFactory:
    def create_button(self):
        return WindowsButton()

    def create_checkbox(self):
        return WindowsCheckbox()

class MacFactory:
    def create_button(self):
        return MacButton()

    def create_checkbox(self):
        return MacCheckbox()

class Application:
    def __init__(self, factory):
        self.button = factory.create_button()
        self.checkbox = factory.create_checkbox()

    def render(self):
        print(self.button.click())
        print(self.checkbox.check())
