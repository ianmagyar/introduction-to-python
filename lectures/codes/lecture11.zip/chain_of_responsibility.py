class Support:
    def __init__(self):
        self.next_handler = None

    def set_next(self, handler):
        self.next_handler = handler
        return handler

    def handle_request(self, level, message):
        pass

class BasicSupport(Support):
    def handle_request(self, level, message):
        if level == "basic":
            print("BasicSupport: Handling -", message)
        elif self.next_handler:
            self.next_handler.handle_request(level, message)

class ManagerSupport(Support):
    def handle_request(self, level, message):
        if level == "intermediate":
            print("ManagerSupport: Handling -", message)
        elif self.next_handler:
            self.next_handler.handle_request(level, message)

class DirectorSupport(Support):
    def handle_request(self, level, message):
        if level == "advanced":
            print("DirectorSupport: Handling -", message)
        elif self.next_handler:
            self.next_handler.handle_request(level, message)

def app():
    basic = BasicSupport()
    manager = ManagerSupport()
    director = DirectorSupport()

    basic.set_next(manager).set_next(director)

    basic.handle_request("basic", "Reset password")
    basic.handle_request("intermediate", "Approve refund")
    basic.handle_request("advanced", "Negotiate contract")
    basic.handle_request("unknown", "Unknown issue")
