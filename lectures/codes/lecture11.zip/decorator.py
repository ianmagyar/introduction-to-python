class Text:
    def __init__(self, content):
        self._content = content

    def render(self):
        return self._content

class TextDecorator:
    def __init__(self, wrapped):
        self._wrapped = wrapped

    def render(self):
        return self._wrapped.render()

class BoldDecorator(TextDecorator):
    def render(self):
        return "<b>" + self._wrapped.render() + "</b>"

class ItalicDecorator(TextDecorator):
    def render(self):
        return "<i>" + self._wrapped.render() + "</i>"

class UnderlineDecorator(TextDecorator):
    def render(self):
        return "<u>" + self._wrapped.render() + "</u>"
