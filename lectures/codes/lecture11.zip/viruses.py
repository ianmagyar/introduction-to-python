import random
import matplotlib.pyplot as plt


class NoChildException(Exception):
    pass


class SimpleVirus(object):
    def __init__(self, maxBirthProb, clearProb):
        self.maxBirthProb = maxBirthProb
        self.clearProb = clearProb

    def doesClear(self):
        return random.random() < self.clearProb

    def reproduce(self, popDensity):
        reproducesProb = self.maxBirthProb * (1 - popDensity)
        if random.random() < reproducesProb:
            return SimpleVirus(self.maxBirthProb, self.clearProb)
        else:
            raise NoChildException("This virus particle does not reproduce")


class SimplePatient(object):
    def __init__(self, viruses, maxPop):
        self.viruses = viruses
        self.maxPop = maxPop

    def getTotalPop(self):
        return len(self.viruses)

    def update(self):
        virus_copy = self.viruses[:]
        for virus in virus_copy:
            if virus.doesClear():
                self.viruses.remove(virus)

        density = len(self.viruses) / self.maxPop
        virus_copy = self.viruses[:]
        for virus in virus_copy:
            try:
                child_virus = virus.reproduce(density)
                self.viruses.append(child_virus)
            except NoChildException:
                pass

        return len(self.viruses)


def simulation2():
    population_sizes = list()
    patient = SimplePatient([SimpleVirus(0.1, 0.05)] * 100, 1000)
    for step in range(300):
        population_sizes.append(patient.update())

    plt.plot(population_sizes)
    plt.xlabel("Time step")
    plt.ylabel("Population size")
    plt.title("Population size over time (SimplePatient & SimpleVirus)")
    plt.show()


# simulation2()


class ResistantVirus(SimpleVirus):
    def __init__(self, maxBirthProb, clearProb, resistances, mutProb):
        SimpleVirus.__init__(self, maxBirthProb, clearProb)
        self.resistances = resistances
        self.mutProb = mutProb

    def getResistance(self, drug):
        try:
            return self.resistances[drug]
        except KeyError:
            return False

    def reproduce(self, popDensity, activeDrugs):
        for drug in activeDrugs:
            if not self.resistances[drug]:
                raise NoChildException("This virus does not reproduce")

        reproducesProb = self.maxBirthProb * (1 - popDensity)
        if random.random() < reproducesProb:
            child_resistances = dict()
            for key in self.resistances:
                if random.random() < 1 - self.mutProb:
                    child_resistances[key] = self.resistances[key]
                else:
                    child_resistances[key] = not self.resistances[key]
            return ResistantVirus(
                self.maxBirthProb, self.clearProb,
                child_resistances, self.mutProb)
        else:
            raise NoChildException("This virus does not reproduce")


class Patient(SimplePatient):
    def __init__(self, viruses, maxPop):
        SimplePatient.__init__(self, viruses, maxPop)
        self.drugs_taken = list()

    def addPrescription(self, newDrug):
        if newDrug not in self.drugs_taken:
            self.drugs_taken.append(newDrug)

    def getPrescriptions(self):
        return self.drugs_taken

    def getResistPop(self, drugResist):
        resistant_virus_count = 0
        for virus in self.viruses:
            resistant = True
            for drug in drugResist:
                resistant = resistant and virus.getResistance(drug)
            if resistant:
                resistant_virus_count += 1
        return resistant_virus_count

    def update(self):
        virus_copy = self.viruses[:]
        for virus in virus_copy:
            if virus.doesClear():
                self.viruses.remove(virus)

        density = len(self.viruses) / self.maxPop
        virus_copy = self.viruses[:]
        for virus in virus_copy:
            try:
                child_virus = virus.reproduce(density, self.drugs_taken)
                self.viruses.append(child_virus)
            except NoChildException:
                pass

        return len(self.viruses)


def simulation4():
    population_sizes = list()
    guttagonol_resistant = list()
    patient = Patient([
        ResistantVirus(0.1, 0.05, {'guttagonol': False}, 0.005)] * 100, 1000)
    for step in range(150):
        population_sizes.append(patient.update())
        guttagonol_resistant.append(patient.getResistPop(['guttagonol']))

    patient.addPrescription('guttagonol')
    for step in range(150):
        population_sizes.append(patient.update())
        guttagonol_resistant.append(patient.getResistPop(['guttagonol']))

    plt.plot(population_sizes, color='green')
    plt.plot(guttagonol_resistant, color='red')
    plt.xlabel("Time step")
    plt.ylabel("Population size")
    plt.title("Population size over time (Patient & ResistantVirus)")
    plt.show()


# simulation4()


def simulation5():
    for waiting_time in [300, 150, 75, 0]:
        end_population = list()
        trials = 50
        for trials in range(trials):
            patient = Patient([
                ResistantVirus(0.1, 0.05, {'guttagonol': False}, 0.005)] * 100,
                1000)
            for step in range(waiting_time):
                patient.update()
            patient.addPrescription('guttagonol')
            for step in range(150):
                patient.update()

            end_population.append(patient.getTotalPop())

        plt.hist(end_population, bins=10)
        plt.xlabel("Population Size")
        plt.ylabel("Number of Patients")
        plt.title(
            "Number of cases after administering Guttagonol ({} steps)".format(
                waiting_time))
        plt.show()


# simulation5()


def simulation6():
    for waiting_time in [300, 150, 75, 0]:
        end_population = list()
        trials = 30
        for trials in range(trials):
            resistance = {'guttagonol': False, 'grimpex': False}
            patient = Patient([
                ResistantVirus(0.1, 0.05, resistance, 0.005)] * 100,
                1000)
            for step in range(150):
                patient.update()
            patient.addPrescription('guttagonol')
            for step in range(waiting_time):
                patient.update()
            patient.addPrescription('grimpex')
            for step in range(150):
                patient.update()

            end_population.append(patient.getTotalPop())

        plt.hist(end_population, bins=10)
        plt.xlabel("Population Size")
        plt.ylabel("Number of Patients")
        plt.title(
            "Number of cases by population (waited {} steps)".format(
                waiting_time))
        plt.show()


# simulation6()


def simulation7():
    for waiting_time in [300, 0]:
        total_population = list()
        guttagonol_resistant = list()
        grimpex_resistant = list()
        both_resistant = list()

        resistance = {'guttagonol': False, 'grimpex': False}
        patient = Patient([
            ResistantVirus(0.1, 0.05, resistance, 0.005)] * 100,
            1000)
        for step in range(150):
            patient.update()
            total_population.append(patient.getTotalPop())
            guttagonol_resistant.append(
                patient.getResistPop(['guttagonol']))
            grimpex_resistant.append(
                patient.getResistPop(['grimpex']))
            both_resistant.append(
                patient.getResistPop(['guttagonol', 'grimpex']))
        patient.addPrescription('guttagonol')
        for step in range(waiting_time):
            patient.update()
            total_population.append(patient.getTotalPop())
            guttagonol_resistant.append(
                patient.getResistPop(['guttagonol']))
            grimpex_resistant.append(
                patient.getResistPop(['grimpex']))
            both_resistant.append(
                patient.getResistPop(['guttagonol', 'grimpex']))
        patient.addPrescription('grimpex')
        for step in range(150):
            patient.update()
            total_population.append(patient.getTotalPop())
            guttagonol_resistant.append(
                patient.getResistPop(['guttagonol']))
            grimpex_resistant.append(
                patient.getResistPop(['grimpex']))
            both_resistant.append(
                patient.getResistPop(['guttagonol', 'grimpex']))

        plt.plot(
            total_population, label='total')
        plt.plot(
            guttagonol_resistant, color='red', label='guttagonol-resistant')
        plt.plot(
            grimpex_resistant, color='orange', label='grimpex-resistant')
        plt.plot(
            both_resistant, color='green', label='resistant to both')
        plt.legend()
        plt.xlabel("Time Step")
        plt.ylabel("Number of Virus Particles")
        plt.title(
            "Population after administering drugs (waited {} steps)".format(
                waiting_time))
        plt.show()


# simulation7()
