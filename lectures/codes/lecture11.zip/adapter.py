class OldPrinter:
    def old_print(self, text):
        print("Printing from OldPrinter:", text)

class Printable:
    def print_text(self, text):
        pass

class PrinterAdapter(Printable, OldPrinter):
    def print_text(self, text):
        self.old_print(text)

def app(printer):
    printer.print_text("Hello, Adapter Pattern!")
