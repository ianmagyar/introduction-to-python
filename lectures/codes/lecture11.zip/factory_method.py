class EmailNotification:
    def send(self, message):
        print("Sending Email: " + message)

class SMSNotification:
    def send(self, message):
        print("Sending SMS: " + message)

class NotificationCreator:
    def create_notification(self):
        pass

class EmailNotificationCreator(NotificationCreator):
    def create_notification(self):
        return EmailNotification()

class SMSNotificationCreator(NotificationCreator):
    def create_notification(self):
        return SMSNotification()

def app(creator, message):
    notification = creator.create_notification()
    notification.send(message)
