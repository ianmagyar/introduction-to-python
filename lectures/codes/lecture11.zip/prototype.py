import copy

class Shape:
    def __init__(self):
        self.color = "Black"

    def clone(self):
        return copy.deepcopy(self)

    def draw(self):
        pass

class Circle(Shape):
    def __init__(self):
        super().__init__()
        self.radius = 5

    def draw(self):
        print("Drawing Circle with radius", self.radius, "and color", self.color)

class Rectangle(Shape):
    def __init__(self):
        super().__init__()
        self.width = 10
        self.height = 5

    def draw(self):
        print("Drawing Rectangle with width", self.width, "height", self.height, "and color", self.color)

def app():
    original_circle = Circle()
    original_circle.color = "Red"

    cloned_circle = original_circle.clone()
    cloned_circle.radius = 10

    original_rectangle = Rectangle()
    original_rectangle.color = "Blue"

    cloned_rectangle = original_rectangle.clone()
    cloned_rectangle.width = 20

    print("Original Circle:")
    original_circle.draw()

    print("Cloned Circle:")
    cloned_circle.draw()

    print("\nOriginal Rectangle:")
    original_rectangle.draw()

    print("Cloned Rectangle:")
    cloned_rectangle.draw()
