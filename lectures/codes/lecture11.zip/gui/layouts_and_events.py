import sys

from PyQt5.QtWidgets import QApplication
from PyQt5.QtWidgets import QLabel, QPushButton
from PyQt5.QtWidgets import QVBoxLayout
from PyQt5.QtWidgets import QWidget


def show_message():
    if msg.text():
        msg.setText("")
        btn.setText("Show me!")
    else:
        msg.setText("This is a secret message")
        btn.setText("Hide me!")


app = QApplication(sys.argv)

window = QWidget()
window.setWindowTitle('simple button app')

main_layout = QVBoxLayout()

btn = QPushButton('Show me!')
btn.clicked.connect(show_message)
main_layout.addWidget(btn)

msg = QLabel('')
main_layout.addWidget(msg)

window.setLayout(main_layout)
window.show()
sys.exit(app.exec_())
