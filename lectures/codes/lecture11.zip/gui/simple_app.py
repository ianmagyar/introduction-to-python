import sys

from PyQt5.QtWidgets import QApplication
from PyQt5.QtWidgets import QLabel
from PyQt5.QtWidgets import QWidget


app = QApplication(sys.argv)

window = QWidget()
window.setWindowTitle('My first app')
window.setGeometry(10, 100, 200, 100)
# window.move(60, 15)

my_label = QLabel('Welcome!', parent=window)
# my_label = QLabel('<h1>Welcome!</h1>', parent=window)

window.show()
sys.exit(app.exec_())
