import operator
import sys

from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont
from PyQt5.QtWidgets import QApplication, QMainWindow, QWidget
from PyQt5.QtWidgets import QGridLayout, QVBoxLayout
from PyQt5.QtWidgets import QLineEdit, QPushButton


class SimpleCalculator(QMainWindow):
    def __init__(self):
        super().__init__()

        self.setWindowTitle('Calculator')
        self.setFixedSize(500, 500)

        self.custom_font = QFont('Arial', 32)

        self.main_layout = QVBoxLayout()
        self._centralWidget = QWidget(self)
        self._centralWidget.setLayout(self.main_layout)
        self.setCentralWidget(self._centralWidget)

        self._createDisplay()
        self._createButtons()

        self.answer = None
        self.second_argument = None
        self.last_operation = None

    def _createDisplay(self):
        self.display = QLineEdit()

        self.display.setFixedHeight(70)
        self.display.setAlignment(Qt.AlignRight)
        self.display.setFont(self.custom_font)
        self.display.setReadOnly(True)

        self.main_layout.addWidget(self.display)

    def _createButtons(self):
        self.buttons = {}

        buttonsLayout = QGridLayout()

        buttons = {
            '7': (0, 0),
            '8': (0, 1),
            '9': (0, 2),
            '/': (0, 3),
            '4': (1, 0),
            '5': (1, 1),
            '6': (1, 2),
            '*': (1, 3),
            '1': (2, 0),
            '2': (2, 1),
            '3': (2, 2),
            '-': (2, 3),
            'C': (3, 0),
            '0': (3, 1),
            '=': (3, 2),
            '+': (3, 3),
        }

        for btnText, pos in buttons.items():
            self.buttons[btnText] = QPushButton(btnText)
            self.buttons[btnText].setFixedSize(100, 100)
            if btnText not in ['=', 'C']:
                self.buttons[btnText].clicked.connect(self.process_push)
            self.buttons[btnText].setFont(self.custom_font)
            buttonsLayout.addWidget(self.buttons[btnText], pos[0], pos[1])

        self.buttons['='].clicked.connect(self.calculate_result)
        self.buttons['C'].clicked.connect(self.clear_memory)
        self.main_layout.addLayout(buttonsLayout)

    def setDisplayText(self, text):
        if type(text) == float and text % 1 == 0:
            text = int(text)
        self.display.setText("{}".format(text))
        self.display.setFocus()

    def clearDisplay(self):
        self.setDisplayText('')

    def displayText(self):
        return self.display.text()

    def update_expression(self, tba):
        if self.displayText() == 'ERROR':
            self.clearDisplay()

        expression = self.displayText() + tba
        if self.answer is None:
            self.answer = float(expression)
        else:
            self.second_argument = float(expression)

        self.setDisplayText(expression)

    def process_operation(self, op_text):
        if self.second_argument is not None:
            self.calculate_result()

        op_to_function = {
            '+': operator.add,
            '-': operator.sub,
            '*': operator.mul,
            '/': operator.truediv
        }
        self.last_operation = op_to_function[op_text]
        self.setDisplayText('')

    def process_push(self):
        sending_button = self.sender()
        btnText = sending_button.text()

        if btnText in ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']:
            self.update_expression(btnText)

        if btnText in ['+', '-', '*', '/']:
            self.process_operation(btnText)

    def calculate_result(self):
        if self.answer is None or self.second_argument is None or self.last_operation is None:
            result = 'ERROR'
        else:
            result = self.last_operation(self.answer, self.second_argument)
            self.answer = result
            self.second_argument = None
            self.last_operation = None

        # expression = self.displayText()
        # try:
        #     result = str(eval(expression, {}, {}))
        # except Exception:
        #     result = 'ERROR'

        self.setDisplayText(result)

    def clear_memory(self):
        self.answer = None
        self.second_argument = None
        self.last_operation = None
        self.clearDisplay()


def main():
    app = QApplication(sys.argv)

    calculator = SimpleCalculator()
    calculator.show()

    sys.exit(app.exec_())


if __name__ == '__main__':
    main()
