import math


# naive code
class cartesianPoint:
    pass


cp1 = cartesianPoint()
cp2 = cartesianPoint()
cp1.x = 1.0
cp1.y = 2.0
cp2.x = 1.0
cp2.y = 2.0


def samePoint(p1, p2):
    return (p1.x == p2.x) and (p1.y == p2.y)


# print(samePoint(cp1, cp2))


def printPoint(p):
    print("({}, {})".format(p.x, p.y))


# printPoint(cp1)
# printPoint(cp2)
# print("\n-----------\n")


class polarPoint:
    pass


pp1 = polarPoint()
pp2 = polarPoint()
pp1.radius = 1.0
pp1.angle = math.pi / 2
pp2.radius = 3.0
pp2.angle = 0

# samePoint(pp1, pp2)
# print("\n-----------\n")


class Point:
    def __str__(self):
        return "({}, {})".format(self.x, self.y)

    def cartesian(self):
        return (self.x, self.y)

    def polar(self):
        return (self.radius, self.angle)

    def __eq__(self, other):
        if not isinstance(other, Point):
            raise TypeError
        return self.x == other.x and self.y == other.y


# implementation using specific classes
class cPoint(Point):
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.radius = math.sqrt(self.x ** 2 + self.y ** 2)
        self.angle = math.atan2(self.y, self.x)

    def __add__(self, other):
        return cPoint(self.x + other.x, self.y + other.y)


p1 = cPoint(1.0, 2.0)
p2 = cPoint(3.0, 0.0)
p3 = cPoint(3.0, 0)

# print(p1)
# print(p1.cartesian())
# print(p1.polar())

# print("Comparing p1 and p2:")
# print(p1 == p2)
# print("Comparing p2 and p3:")
# print(p2 == p3)

# print("\n-----------\n")

print(p1 + p2)


class pPoint(Point):
    def __init__(self, r, a):
        self.radius = r
        self.angle = a
        self.x = self.radius * math.cos(self.angle)
        self.y = self.radius * math.sin(self.angle)

    # def cartesian(self):
    #     return (self.x, self.y)

    # def polar(self):
    #     return (self.radius, self.angle)

    # def __str__(self):
    #     return "({}, {})".format(self.x, self.y)

    # def __eq__(self, other):
    #     if not isinstance(other, Point):
    #         raise TypeError
    #     return self.x == other.x and self.y == other.y

    def set_radius(self, r):
        self.radius = r
        self.x = self.radius * math.cos(self.angle)
        self.y = self.radius * math.sin(self.angle)

    def set_angle(self, a):
        self.angle = a
        self.x = self.radius * math.cos(self.angle)
        self.y = self.radius * math.sin(self.angle)


# p4 = pPoint(3.0, 1.0)  # x=3, y = 0
# print(dir(p4))
# print("Comparing p2 and p4")
# print(p2 == p4)

# print("\n-----------\n")

# print("changing p4 position")
# p4.set_angle(0)
# print("P4 is now")
# print(p4.cartesian())
# print("Comparing p2 and p4")
# print(p4 == p2)

# print(dir(p4))
# print(dir(pPoint))
