import random


def simulate_one_game(switch):
    # set up the game, put the prize behind one door
    doors = [0, 0, 0]
    prize_behind = random.randint(0, 2)
    doors[prize_behind] = 1

    # initial guess - can be any
    available = [0, 1, 2]
    init_guess = random.choice(available)

    # open one door: it cannot be the player's guess
    # nor the door behind which lies the prize
    to_open = available.copy()
    try:
        to_open.remove(init_guess)
        to_open.remove(prize_behind)
    except ValueError:
        pass
    open_door = random.choice(to_open)
    available.remove(open_door)

    if switch:
        # the player changes his decision, takes the other available door
        final_guess = [x for x in available if x != init_guess][0]
    else:
        final_guess = init_guess

    # the player wins if his final guess is the same as the door
    # behind which lies the prize
    return final_guess == prize_behind


def check_behavior(switch, test_count):
    wins = 0

    for _ in range(test_count):
        wins += simulate_one_game(switch)

    return wins / test_count


def find_answer():
    test_count = 1000000
    print("Win percentage when switching: {:.2%}".format(
        check_behavior(True, test_count)))
    print("Win percentage when not switching: {:.2%}".format(
        check_behavior(False, test_count)))


if __name__ == '__main__':
    find_answer()
