class Musician:
    def __init__(self):
        self.sings = False
        self.writes = False


class Singer(Musician):
    def __init__(self):
        self.sings = True
        self.writes = False
        self.actor = False

    def foo(self):
        return "abc"


class SongWriter(Musician):
    def __init__(self):
        self.sings = False
        self.writes = True


class SingerSongWriter(SongWriter, Singer):
    def __init__(self):
        super().__init__()
        Singer.__init__(self)


test_singer = Singer()
test_songwriter = SongWriter()
test = SingerSongWriter()

# print(test_singer.sings, test_singer.writes)
# print(test_songwriter.sings, test_songwriter.writes)
# print(test.sings, test.writes, test.actor)
# print(test.foo())


class Person:
    pass


class Worker(Person):
    pass


class Boss(Person):
    pass


class Manager(Worker, Boss):
    pass


class Secretary(Worker):
    pass


class BoardMember(Boss):
    pass


class CEO(Manager, BoardMember):
    pass


print(CEO.__mro__)
print(CEO.mro())
