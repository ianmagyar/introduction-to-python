import random


EVERY_N_DAYS = 30


def simulate_new_lightning():
    days_passed = 1
    struck = False
    while not struck:
        if random.random() < (1 / EVERY_N_DAYS):
            return days_passed
        days_passed += 1


def simulate_n_lightnings(n):
    days_count = dict()

    for _ in range(n):
        lightning_on_day = simulate_new_lightning()
        try:
            days_count[lightning_on_day] += 1
        except KeyError:
            days_count[lightning_on_day] = 1

    return days_count


def find_answer(test_count):
    res = simulate_n_lightnings(test_count)

    most_often = [(key, value) for key, value in res.items()]
    # sort by count, descending
    most_often.sort(reverse=True, key=lambda x: x[1])
    most_often_day = most_often[0][0]

    return most_often_day, most_often


if __name__ == '__main__':
    test_count = 1000000
    ans, res = find_answer(test_count)
    print("Based on {} simulations, lightning strikes most often on day {}".format(
        test_count, ans))
    print(res)
