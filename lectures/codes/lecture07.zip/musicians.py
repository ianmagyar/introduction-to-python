class Musician:
    def __init__(self, first_name, family_name):
        self.first_name = first_name
        self.family_name = family_name

    def get_family_name(self):
        return self.family_name

    def get_first_name(self):
        return self.first_name

    def __str__(self):
        return "<Musician: {} {}>".format(self.first_name, self.family_name)

    def __eq__(self, other):
        return (self.family_name == other.get_family_name()
                and self.first_name == other.get_first_name())

    def play(self, song):
        return "{} {} plays {}".format(self.first_name, self.family_name, song)


# m1 = Musician("John", "Doe")
# m2 = Musician("John", "Doe")
# print(m1 == m2)


class Guitarist(Musician):
    nextId = 0

    def __init__(self, first_name, family_name):
        super().__init__(first_name, family_name)
        # Musician.__init__(self, first_name, family_name)
        self.id = Guitarist.nextId
        Guitarist.nextId += 1

    def get_id(self):
        return self.id

    def __str__(self):
        return "<Guitarist: {} {}>".format(self.first_name, self.family_name)

    def __eq__(self, other):
        return self.id == other.id


# m1 = Guitarist("Dave", "Murray")
# m2 = Guitarist("Adrian", "Smith")
# print(m1.get_id())
# print(m2.get_id())

# print(m1.play("2 Minutes To Midnight"))


class Bassist(Guitarist):
    def __init__(self, first_name, family_name):
        Guitarist.__init__(self, first_name, family_name)
        self.strings = 4

    def set_strings(self, strings):
        if strings > 6:
            raise ValueError("Calm down, that's just way too many strings...")
        self.strings = strings

    def get_strings(self):
        return self.strings

    def play(self, song):
        plus_string = " on " + str(self.strings) + " strings"
        return Guitarist.play(self, song) + plus_string
        # return Guitarist.play(
        #     self, song + " on " + str(self.strings) + " strings")


# m3 = Bassist("Steve", "Harris")
# print(m3.play("Hallowed Be Thy Name"))
# print(m3.get_id())


class Drummer(Musician):
    def __init__(self, first_name, family_name):
        Musician.__init__(self, first_name, family_name)
        self.songs = dict()

    def learn_song(self, bpm, title):
        try:
            self.songs[bpm].append(title)
        except KeyError:
            self.songs[bpm] = [title]

    def get_songs(self, bpm):
        try:
            return self.songs[bpm]
        except KeyError:
            return []

    def play(self, song):
        for bpm in self.songs:
            if song in self.songs[bpm]:
                return "{} {} smashes {}".format(
                    self.first_name, self.family_name, song)
        return "Huh? Was I supposed to learn that?"


# m4 = Drummer("Nicko", "McBrain")
# m4.learn_song(162, "The Trooper")
# m4.learn_song(134, "Aces High")
# m4.learn_song(109, "Fear of the Dark")
# m4.learn_song(173, "Run to the Hills")

# print(m4.get_songs(134))
# print(m4.play("Aces High"))
# print(m4.play("Hallowed Be Thy Name"))


class Band:
    def __init__(self):
        self.members = []
        self.IDs = []

    def get_members(self):
        return self.members

    def add(self, who):
        if not isinstance(who, Musician):
            raise TypeError("Band can only consist of musicians")

        if isinstance(who, Guitarist):
            if who.get_id() in self.IDs:
                raise ValueError("Duplicate band guitarists")

        self.members.append(who)
        if isinstance(who, Guitarist):
            self.IDs.append(who.get_id())

    def __iter__(self):
        self.place = 0
        return self

    def __next__(self):
        if self.place >= len(self.members):
            raise StopIteration
        self.place += 1
        return self.members[self.place - 1]


m1 = Guitarist("Dave", "Murray")
m2 = Guitarist("Adrian", "Smith")
m3 = Bassist("Steve", "Harris")
m4 = Drummer("Nicko", "McBrain")
m4.learn_song(162, "The Trooper")

iron_maiden = Band()
iron_maiden.add(m1)
iron_maiden.add(m2)
iron_maiden.add(m3)
iron_maiden.add(m4)

# print(m1.play("The Trooper"))
# print(m2.play("The Trooper"))
# print(m3.play("The Trooper"))
# print(m4.play("The Trooper"))

# for member in iron_maiden.get_members():
for member in iron_maiden:
    print(member.play("The Trooper"))
