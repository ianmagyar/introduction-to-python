class HashTable:
    def __init__(self):
        self.table = dict()

    def hash_function(self, number):
        # number is an integer or float
        # calculates and returns hash value for number
        if type(number) not in [int, float]:
            raise TypeError("You can only add numbers to this hash table")
        return round(number % 5)

    def insert(self, number):
        # number is an integer or float
        # adds number into the hash table under its hash value
        key = self.hash_function(number)

        try:
            self.table[key].append(number)
        except KeyError:
            self.table[key] = [number]

    def has(self, number):
        # number is an integer or float
        # returns True if number is in hash table, False otherwise
        key = self.hash_function(number)

        if key in self.table:
            return number in self.table[key]

        return False

    def get(self, number):
        # number is an integer or float
        # returns number if number is in hash table, None otherwise
        if self.has(self.table, number):
            return number

        return None

    def delete(self, number):
        # number is an integer or float
        # deletes number from table
        # returns True if number was deleted, False if number was not in table
        key = self.hash_function(number)

        try:
            self.table[key].remove(number)
            return True
        except (KeyError, ValueError):
            return False

    def get_table(self):
        return self.table
