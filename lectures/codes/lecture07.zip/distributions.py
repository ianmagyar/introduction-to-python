import random
import numpy as np
import matplotlib.pyplot as plt


fair_die = [1, 2, 3, 4, 5, 6]


def throwDie(vals):
    return random.choice(vals)


def uniformDistribution(numThrows, vals):
    throws = []
    for i in range(numThrows):
        d = throwDie(vals)
        throws.append(d)

    labels, counts = np.unique(throws, return_counts=True)
    plt.bar(labels, counts, align='center')
    plt.gca().set_xticks(labels)
    plt.show()


# uniformDistribution(100000, fair_die)


def throwTwoDice(vals1, vals2):
    return random.choice(vals1), random.choice(vals2)


def normalDistribution(numThrows, vals1, vals2):
    throws = []
    for i in range(numThrows):
        d1, d2 = throwTwoDice(vals1, vals2)
        throws.append(d1 + d2)

    labels, counts = np.unique(throws, return_counts=True)
    plt.bar(labels, counts, align='center')
    plt.gca().set_xticks(labels)
    plt.show()


# normalDistribution(100000, fair_die, fair_die)


def throwThreeDice(vals1, vals2, vals3):
    return random.choice(vals1), random.choice(vals2), random.choice(vals3)


def normalDistribution3(numThrows, vals1, vals2, vals3):
    throws = []
    for i in range(numThrows):
        d1, d2, d3 = throwThreeDice(vals1, vals2, vals3)
        throws.append(d1 + d2 + d3)

    labels, counts = np.unique(throws, return_counts=True)
    plt.bar(labels, counts, align='center')
    plt.gca().set_xticks(labels)
    plt.show()


normalDistribution3(100000, fair_die, fair_die, fair_die)
