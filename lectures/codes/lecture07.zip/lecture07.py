class Product:
    counter = 0

    def __init__(self, price, name):
        self.__price = price
        self.name = name
        Product.counter += 1

    def get_price(self):
        return self.__price

    def set_price(self, new_price):
        self.__price = new_price

    def get_counter(self):
        return Product.counter


# test1 = Product(500, "abc")
# test1.set_price(1000)
# # test1.__price = 2000
# print(test1.get_price())

# test2 = Product(750, "def")
# print(test2.get_price())
# print(test2.get_counter())

# print(test1.get_price())
# print(test1.get_counter())


class Person:
    def __init__(self, name):
        print('setting name in person')
        self.name = name

    def calculate(self):
        return 6


class Student(Person):
    def __init__(self, name, year):
        # print('setting name in student')
        # self.name = name
        super().__init__(name)
        self.year = year

    def calculate(self):
        return super().calculate() * 2


student = Student("Janko Hrasko", 1)
print(type(student))
print(student.name)
print(student.year)
print(student.calculate())

person = Person("Janko Hrasko")
print(type(person))
print(person.name)
# print(person.year)  # AttributeError
print(person.calculate())
