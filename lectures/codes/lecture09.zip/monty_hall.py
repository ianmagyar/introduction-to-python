import random


def simulate_one_game(switch):
    doors = [0, 0, 0]
    prize_behind = random.randint(0, 2)
    doors[prize_behind] = 1

    available = [0, 1, 2]
    init_guess = random.choice(available)

    to_open = available.copy()
    try:
        to_open.remove(init_guess)
        to_open.remove(prize_behind)
    except ValueError:
        pass
    open_door = random.choice(to_open)
    available.remove(open_door)

    if switch:
        final_guess = [x for x in available if x != init_guess][0]
    else:
        final_guess = init_guess

    return final_guess == prize_behind


def check_behavior(count, switch):
    wins = 0

    for _ in range(count):
        wins += simulate_one_game(switch)

    return wins / count


if __name__ == '__main__':
    print(check_behavior(1000000, False))
