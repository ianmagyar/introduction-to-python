import random


def generate_birthdays(n):
    birthdays = list()
    for _ in range(n):
        birthdays.append(random.randint(1, 365))

    return birthdays


def has_match(birthdays):
    unique = set(birthdays)
    # if all are unique, the lengths are the same
    return len(birthdays) != len(unique)


def test_prob(n, test_count):
    sharing_bday = 0

    for _ in range(test_count):
        birthdays = generate_birthdays(n)
        sharing_bday += has_match(birthdays)

    return sharing_bday / test_count


if __name__ == '__main__':
    n = 23
    test_count = 100000
    print("Probability of shared birthday with {} people: {:.2%}".format(
        n, test_prob(n, test_count)))
