import random


def generate_birthdays(n):
    birthdays = list()
    for _ in range(n):
        birthdays.append(random.randint(1, 365))

    return birthdays


def has_match(birthdays):
    unique = set(birthdays)
    return len(birthdays) != len(unique)


def test_chance_on_n(n, count):
    with_match = 0

    for _ in range(count):
        birthdays = generate_birthdays(n)
        with_match += has_match(birthdays)

    return with_match / count


if __name__ == '__main__':
    print(test_chance_on_n(70, 100000))
