from math import sqrt
import random
import matplotlib.pyplot as plt


class Location:
    def __init__(self, x, y):
        self.x = float(x)
        self.y = float(y)

    def move(self, dx, dy):
        return Location(self.x + float(dx), self.y + float(dy))

    def getCoords(self):
        return self.x, self.y

    def getDistance(self, other):
        o_x, o_y = other.getCoords()
        x_dist = self.x - o_x
        y_dist = self.y - o_y
        return sqrt(x_dist ** 2 + y_dist ** 2)


class Direction:
    possibles = ['N', 'E', 'S', 'W']

    def __init__(self, direction):
        if direction in self.possibles:
            self.direction = direction
        else:
            raise ValueError(
                "Unknown direction {} in Direction.__init__".format(direction))

    def move(self, dist):
        if self.direction == 'N':
            return (0, dist)
        elif self.direction == 'E':
            return (dist, 0)
        elif self.direction == 'S':
            return (0, -dist)
        elif self.direction == 'W':
            return (-dist, 0)
        else:
            raise ValueError("Unexpected direction in Direction.move")


class Field:
    def __init__(self, drunk, loc):
        self.drunk = drunk
        self.loc = loc

    def move(self, direction, dist):
        oldLoc = self.loc
        dx, dy = direction.move(dist)
        self.loc = oldLoc.move(dx, dy)

    def getLoc(self):
        return self.loc

    def getDrunk(self):
        return self.drunk


class Drunk:
    def __init__(self, name):
        self.name = name

    def move(self, field, steps=1):
        if field.getDrunk() != self:
            raise ValueError(
                "Drunk.move called when drunk was not added to a field")
        for i in range(steps):
            direction = Direction(random.choice(Direction.possibles))
            field.move(direction, 1)


def performTrial(steps, field):
    start = field.getLoc()
    distances = [0.0]
    for t in range(1, steps + 1):
        field.getDrunk().move(field)
        newLoc = field.getLoc()
        distance = newLoc.getDistance(start)
        distances.append(distance)
    return distances, newLoc.getCoords()


# drunk = Drunk("Not Me")
# for i in range(3):
#     field = Field(drunk, Location(0, 0))
#     distances, end_point = performTrial(500, field)
#     plt.plot(distances)
# plt.title("Drunk's Random Walk")
# plt.xlabel("Time")
# plt.ylabel("Distance from Origin")
# plt.show()


def performSim(steps, numTrials):
    distLists = []
    endPoints = []
    for trial in range(numTrials):
        d = Drunk("Drunk" + str(trial))
        f = Field(d, Location(0, 0))
        distances, endPoint = performTrial(steps, f)
        distLists.append(distances)
        endPoints.append(endPoint)
    return distLists, endPoints


def ansQuest(steps, numTrials):
    means = []
    distLists, endPoints = performSim(steps, numTrials)
    for t in range(steps + 1):
        total = 0.0
        for distL in distLists:
            total += distL[t]
        means.append(total / len(distLists))
    plt.figure()
    plt.plot(means)
    plt.ylabel('distance')
    plt.xlabel('time')
    plt.title('Average distance vs. Time ({} trials)'.format(numTrials))

    X = [p[0] for p in endPoints]
    Y = [p[1] for p in endPoints]
    plt.figure()
    plt.scatter(X, Y)
    plt.xlabel('x distance')
    plt.ylabel('y distance')
    plt.title('End points')


ansQuest(steps=500, numTrials=300)
plt.show()
