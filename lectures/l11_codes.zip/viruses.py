import random
import matplotlib.pyplot as plt


class NoChildException(Exception):
    """
    NoChildException is raised by the reproduce() method in the SimpleVirus
    and ResistantVirus classes to indicate that a virus particle does not
    reproduce. You can use NoChildException as is, you do not need to
    modify/add any code.
    """


class SimpleVirus(object):
    """
    Representation of a simple virus (does not model drug effects/resistance).
    """

    def __init__(self, maxBirthProb, clearProb):
        """
        Initialize a SimpleVirus instance, saves all parameters as attributes
        of the instance.

        maxBirthProb: Maximum reproduction probability (a float between 0-1)

        clearProb: Maximum clearance probability (a float between 0-1).
        """
        self.maxBirthProb = maxBirthProb
        self.clearProb = clearProb

    def doesClear(self):
        """
        Stochastically determines whether this virus is cleared from the
        patient's body at a time step.

        returns: Using a random number generator (random.random()), this method
        returns True with probability self.clearProb and otherwise returns
        False.
        """
        return random.random() < self.clearProb

    def reproduce(self, popDensity):
        """
        Stochastically determines whether this virus particle reproduces at a
        time step. Called by the update() method in the SimplePatient and
        Patient classes. The virus particle reproduces with probability
        self.maxBirthProb * (1 - popDensity).

        If this virus particle reproduces, then reproduce() creates and returns
        the instance of the offspring SimpleVirus (which has the same
        maxBirthProb and clearProb values as its parent).

        popDensity: the population density (a float), defined as the current
        virus population divided by the maximum population.

        returns: a new instance of the SimpleVirus class representing the
        offspring of this virus particle. The child should have the same
        maxBirthProb and clearProb values as this virus. Raises a
        NoChildException if this virus particle does not reproduce.
        """
        reproducesProb = self.maxBirthProb * (1 - popDensity)
        if random.random() < reproducesProb:
            return SimpleVirus(self.maxBirthProb, self.clearProb)
        else:
            raise NoChildException("This virus particle does not reproduce")


class SimplePatient(object):
    """
    Representation of a simplified patient. The patient does not take any drugs
    and his/her virus populations have no drug resistance.
    """

    def __init__(self, viruses, maxPop):
        """
        Initialization function, saves the viruses and maxPop parameters as
        attributes.

        viruses: the list representing the virus population (a list of
        SimpleVirus instances)

        maxPop: the  maximum virus population for this patient (an integer)
        """
        self.viruses = viruses
        self.maxPop = maxPop

    def getTotalPop(self):
        """
        Gets the current total virus population.

        returns: The total virus population (an integer)
        """
        return len(self.viruses)

    def update(self):
        """
        Update the state of the virus population in this patient for a single
        time step. update() should execute the following steps in this order:

        - Determine whether each virus particle survives and updates the list
          of virus particles accordingly.

        - The current population density is calculated. This population density
          value is used until the next call to update()

        - Determine whether each virus particle should reproduce and add
          offspring virus particles to the list of viruses in this patient.

        returns: the total virus population at the end of the update (an
        integer)
        """
        virus_copy = self.viruses[:]
        for virus in virus_copy:
            if virus.doesClear():
                self.viruses.remove(virus)

        density = len(self.viruses) / self.maxPop
        virus_copy = self.viruses[:]
        for virus in virus_copy:
            try:
                child_virus = virus.reproduce(density)
                self.viruses.append(child_virus)
            except NoChildException:
                pass

        return len(self.viruses)


def problem2():
    """
    Run the simulation and plot the graph for problem 2 (no drugs are used,
    viruses do not have any drug resistance).

    Instantiates a patient, runs a simulation for 300 timesteps, and plots the
    total virus population as a function of time.
    """
    population_sizes = list()
    patient = SimplePatient([SimpleVirus(0.1, 0.05)] * 100, 1000)
    for step in range(300):
        population_sizes.append(patient.update())

    plt.plot(population_sizes)
    plt.xlabel("Time step")
    plt.ylabel("Population size")
    plt.title("Population size over time (SimplePatient & SimpleVirus)")
    plt.show()


problem2()


class ResistantVirus(SimpleVirus):
    """
    Representation of a virus which can have drug resistance.
    """

    def __init__(self, maxBirthProb, clearProb, resistances, mutProb):
        """
        Initialize a ResistantVirus instance, saves all parameters as attributes
        of the instance.

        maxBirthProb: Maximum reproduction probability (a float between 0-1)

        clearProb: Maximum clearance probability (a float between 0-1).

        resistances: A dictionary of drug names (strings) mapping to the state
        of this virus particle's resistance (either True or False) to each drug.
        e.g. {'guttagonol':False, 'grimpex',False}, means that this virus
        particle is resistant to neither guttagonol nor grimpex.

        mutProb: Mutation probability for this virus particle (a float). This is
        the probability of the offspring acquiring or losing resistance to a drug.
        """
        SimpleVirus.__init__(self, maxBirthProb, clearProb)
        self.resistances = resistances
        self.mutProb = mutProb

    def getResistance(self, drug):
        """
        Get the state of this virus particle's resistance to a drug. This method
        is called by getResistPop() in Patient to determine how many virus
        particles have resistance to a drug.

        drug: the drug (a string).

        returns: True if this virus instance is resistant to the drug, False
        otherwise.
        """
        try:
            return self.resistances[drug]
        except KeyError:
            return False

    def reproduce(self, popDensity, activeDrugs):
        """
        Stochastically determines whether this virus particle reproduces at a
        time step. Called by the update() method in the Patient class.

        If the virus particle is not resistant to any drug in activeDrugs,
        then it does not reproduce. Otherwise, the virus particle reproduces
        with probability:

        self.maxBirthProb * (1 - popDensity).

        If this virus particle reproduces, then reproduce() creates and returns
        the instance of the offspring ResistantVirus (which has the same
        maxBirthProb and clearProb values as its parent).

        For each drug resistance trait of the virus (i.e. each key of
        self.resistances), the offspring has probability 1-mutProb of
        inheriting that resistance trait from the parent, and probability
        mutProb of switching that resistance trait in the offspring.

        For example, if a virus particle is resistant to guttagonol but not
        grimpex, and `self.mutProb` is 0.1, then there is a 10% chance that
        that the offspring will lose resistance to guttagonol and a 90%
        chance that the offspring will be resistant to guttagonol.
        There is also a 10% chance that the offspring will gain resistance to
        grimpex and a 90% chance that the offspring will not be resistant to
        grimpex.

        popDensity: the population density (a float), defined as the current
        virus population divided by the maximum population

        activeDrugs: a list of the drug names acting on this virus particle
        (a list of strings).

        returns: a new instance of the ResistantVirus class representing the
        offspring of this virus particle. The child should have the same
        maxBirthProb and clearProb values as this virus. Raises a
        NoChildException if this virus particle does not reproduce.
        """
        for drug in activeDrugs:
            if not self.resistances[drug]:
                raise NoChildException("This virus does not reproduce")

        reproducesProb = self.maxBirthProb * (1 - popDensity)
        if random.random() < reproducesProb:
            child_resistances = dict()
            for key in self.resistances:
                if random.random() < 1 - self.mutProb:
                    child_resistances[key] = self.resistances[key]
                else:
                    child_resistances[key] = not self.resistances[key]
            return ResistantVirus(
                self.maxBirthProb, self.clearProb,
                child_resistances, self.mutProb)
        else:
            raise NoChildException("This virus does not reproduce")


class Patient(SimplePatient):
    """
    Representation of a patient. The patient is able to take drugs and his/her
    virus population can acquire resistance to the drugs he/she takes.
    """

    def __init__(self, viruses, maxPop):
        """
        Initialization function, saves the viruses and maxPop parameters as
        attributes. Also initializes the list of drugs being administered
        (which should initially include no drugs).

        viruses: the list representing the virus population (a list of
        SimpleVirus instances)

        maxPop: the  maximum virus population for this patient (an integer)
        """
        SimplePatient.__init__(self, viruses, maxPop)
        self.drugs_taken = list()

    def addPrescription(self, newDrug):
        """
        Administer a drug to this patient. After a prescription is added, the
        drug acts on the virus population for all subsequent time steps. If the
        newDrug is already prescribed to this patient, the method has no effect.

        newDrug: The name of the drug to administer to the patient (a string).

        postcondition: list of drugs being administered to a patient is updated
        """
        if newDrug not in self.drugs_taken:
            self.drugs_taken.append(newDrug)

    def getPrescriptions(self):
        """
        Returns the drugs that are being administered to this patient.

        returns: The list of drug names (strings) being administered to this
        patient.
        """
        return self.drugs_taken

    def getResistPop(self, drugResist):
        """
        Get the population of virus particles resistant to the drugs listed in
        drugResist.

        drugResist: Which drug resistances to include in the population (a list
        of strings - e.g. ['guttagonol'] or ['guttagonol', 'grimpex'])

        returns: the population of viruses (an integer) with resistances to all
        drugs in the drugResist list.
        """
        resistant_virus_count = 0
        for virus in self.viruses:
            resistant_to_all = True
            for drug in drugResist:
                resistant_to_all = resistant_to_all and virus.getResistance(drug)
            if resistant_to_all:
                resistant_virus_count += 1
        return resistant_virus_count

    def update(self):
        """
        Update the state of the virus population in this patient for a single
        time step. update() should execute these actions in order:

        - Determine whether each virus particle survives and update the list of
          virus particles accordingly

        - The current population density is calculated. This population density
          value is used until the next call to update().

        - Determine whether each virus particle should reproduce and add
          offspring virus particles to the list of viruses in this patient.
          The listof drugs being administered should be accounted for in the
          determination of whether each virus particle reproduces.

        returns: the total virus population at the end of the update (an
        integer)
        """
        virus_copy = self.viruses[:]
        for virus in virus_copy:
            if virus.doesClear():
                self.viruses.remove(virus)

        density = len(self.viruses) / self.maxPop
        virus_copy = self.viruses[:]
        for virus in virus_copy:
            try:
                child_virus = virus.reproduce(density, self.drugs_taken)
                self.viruses.append(child_virus)
            except NoChildException:
                pass

        return len(self.viruses)


def problem4():
    """
    Runs simulations and plots graphs for problem 4.

    Instantiates a patient, runs a simulation for 150 timesteps, adds
    guttagonol, and runs the simulation for an additional 150 timesteps.

    total virus population vs. time  and guttagonol-resistant virus population
    vs. time are plotted
    """
    population_sizes = list()
    guttagonol_resistant_size = list()
    patient = Patient([
        ResistantVirus(0.1, 0.05, {'guttagonol': False}, 0.005)] * 100, 1000)
    for step in range(150):
        population_sizes.append(patient.update())
        guttagonol_resistant_size.append(patient.getResistPop(['guttagonol']))

    patient.addPrescription('guttagonol')
    for step in range(150):
        population_sizes.append(patient.update())
        guttagonol_resistant_size.append(patient.getResistPop(['guttagonol']))

    plt.plot(population_sizes)
    plt.plot(guttagonol_resistant_size)
    plt.xlabel("Time step")
    plt.ylabel("Population size")
    plt.title("Population size over time (Patient & ResistantVirus)")
    plt.show()


problem4()


def problem5():
    """
    Runs simulations and make histograms for problem 5.

    Runs multiple simulations to show the relationship between delayed treatment
    and patient outcome.

    Histograms of final total virus populations are displayed for delays of 300,
    150, 75, 0 timesteps (followed by an additional 150 timesteps of
    simulation).
    """
    for waiting_time in [300, 150, 75, 0]:
        end_population = list()
        trials = 50
        for trials in range(trials):
            patient = Patient([
                ResistantVirus(0.1, 0.05, {'guttagonol': False}, 0.005)] * 100,
                1000)
            for step in range(waiting_time):
                patient.update()
            patient.addPrescription('guttagonol')
            for step in range(150):
                patient.update()

            end_population.append(patient.getTotalPop())

        plt.hist(end_population, bins=10)
        plt.xlabel("Population Size")
        plt.ylabel("Number of Patients")
        plt.title("Number of cases after administering Guttagonol ({} steps)".format(waiting_time))
        plt.show()


problem5()


def problem6():
    """
    Runs simulations and make histograms for problem 6.

    Runs multiple simulations to show the relationship between administration
    of multiple drugs and patient outcome.

    Histograms of final total virus populations are displayed for lag times of
    150, 75, 0 timesteps between adding drugs (followed by an additional 150
    timesteps of simulation).
    """
    for waiting_time in [300, 150, 75, 0]:
        end_population = list()
        trials = 30
        for trials in range(trials):
            patient = Patient([
                ResistantVirus(0.1, 0.05, {'guttagonol': False, 'grimpex': False}, 0.005)] * 100,
                1000)
            for step in range(150):
                patient.update()
            patient.addPrescription('guttagonol')
            for step in range(waiting_time):
                patient.update()
            patient.addPrescription('grimpex')
            for step in range(150):
                patient.update()

            end_population.append(patient.getTotalPop())

        plt.hist(end_population, bins=10)
        plt.xlabel("Population Size")
        plt.ylabel("Number of Patients")
        plt.title("Number of cases by population (waited {} steps)".format(waiting_time))
        plt.show()


problem6()


def problem7():
    """
    Run simulations and plot graphs examining the relationship between
    administration of multiple drugs and patient outcome.

    Plots of total and drug-resistant viruses vs. time are made for a
    simulation with a 300 time step delay between administering the 2 drugs and
    a simulations for which drugs are administered simultaneously.
    """
    for waiting_time in [300, 0]:
        total_population = list()
        guttagonol_resistant_size = list()
        grimpex_resistant_size = list()
        both_resistant_size = list()

        patient = Patient([
            ResistantVirus(0.1, 0.05, {'guttagonol': False, 'grimpex': False}, 0.005)] * 100,
            1000)
        for step in range(150):
            patient.update()
            total_population.append(patient.getTotalPop())
            guttagonol_resistant_size.append(patient.getResistPop(['guttagonol']))
            grimpex_resistant_size.append(patient.getResistPop(['grimpex']))
            both_resistant_size.append(patient.getResistPop(['guttagonol', 'grimpex']))
        patient.addPrescription('guttagonol')
        for step in range(waiting_time):
            patient.update()
            total_population.append(patient.getTotalPop())
            guttagonol_resistant_size.append(patient.getResistPop(['guttagonol']))
            grimpex_resistant_size.append(patient.getResistPop(['grimpex']))
            both_resistant_size.append(patient.getResistPop(['guttagonol', 'grimpex']))
        patient.addPrescription('grimpex')
        for step in range(150):
            patient.update()
            total_population.append(patient.getTotalPop())
            guttagonol_resistant_size.append(patient.getResistPop(['guttagonol']))
            grimpex_resistant_size.append(patient.getResistPop(['grimpex']))
            both_resistant_size.append(patient.getResistPop(['guttagonol', 'grimpex']))

        plt.plot(total_population, label='total')
        plt.plot(guttagonol_resistant_size, color='red', label='guttagonol-resistant')
        plt.plot(grimpex_resistant_size, color='orange', label='grimpex-resistant')
        plt.plot(both_resistant_size, color='green', label='resistant to both')
        plt.legend()
        plt.xlabel("Time Step")
        plt.ylabel("Number of Virus Particles")
        plt.title("Population size after administering drugs (waited {} steps)".format(waiting_time))
        plt.show()


problem7()
