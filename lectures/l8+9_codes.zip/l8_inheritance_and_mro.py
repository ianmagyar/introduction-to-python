# class Product:
#     def __init__(self):
#         self.price = 1000

#     def set_price(self, new):
#         self.price = new

#     def sell(self):
#         print("Was sold for {}".format(self.price))

#     def print_price(self):
#         print(self.price)


# t = Product()
# t.set_price(500)
# t.print_price()


class Person:
    pass
class Worker(Person):
    pass
class Boss(Person):
    pass


class Manager(Worker, Boss):
    pass
class Secretary(Worker):
    pass
class BoardMember(Boss):
    pass


class CEO(Manager, BoardMember):
    pass


print(CEO.mro())
