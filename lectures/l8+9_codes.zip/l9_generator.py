def reverse(data):
    for i in range(len(data) - 1, -1, -1):
        yield data[i]


my_list = [1, 2, 3, 4, 5]
for elem in reverse(my_list):
    print(elem)
