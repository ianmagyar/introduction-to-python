import matplotlib.pyplot as plt
import numpy as np
import math
import random


def flipTrial(numFlips):
    heads, tails = 0, 0
    for i in range(numFlips):
        coin = random.randint(0, 1)
        if coin:
            heads += 1
        else:
            tails += 1
    return heads, tails


def simFlips(numFlips, numTrials):
    diffs = list()
    for i in range(numTrials):
        heads, tails = flipTrial(numFlips)
        diffs.append(abs(heads - tails))
    diffs = np.array(diffs)
    diffMean = sum(diffs) / len(diffs)
    diffPercentual = (diffs / numFlips) * 100
    percentMean = sum(diffPercentual) / len(diffPercentual)

    plt.hist(diffs)
    plt.axvline(diffMean, color='r', label='Mean')
    plt.legend()
    plt.title("{} flips, {} trials".format(numFlips, numTrials))
    plt.xlabel("Difference between heads and tails")
    plt.ylabel("Number of trials")
    plt.figure()

    plt.plot(diffPercentual)
    plt.axhline(percentMean, color='r', label='Mean')
    plt.legend()
    plt.title("{} flips, {} trials".format(numFlips, numTrials))
    plt.xlabel("Trial number")
    plt.ylabel("Percentual difference between heads and tails")


if __name__ == '__main__':
    simFlips(1000, 500)
    plt.show()
