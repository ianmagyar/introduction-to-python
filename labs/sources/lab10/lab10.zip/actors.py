from location import Location


class Actor:
    def __init__(self, name, speed, x, y):
        self.name = name
        self.speed = speed
        self.loc = Location(x, y)

        self.field = None

    def set_field(self, field):
        self.field = field

    def move(self):
        pass

    def get_coords(self):
        return self.loc.get_coords()

    def get_location(self):
        return self.loc


class Human(Actor):
    def __init__(self, name, speed, x, y):
        super().__init__(name, speed, x, y)

    def move(self):
        # TODO: take a step in a random direction
        pass


class Mosquito(Actor):
    def __init__(self, name, speed, x, y):
        super().__init__(name, speed, x, y)
        self.found_prey = False
        self.last_distance = 0
        self.last_direction = None
        self.changes = list()

    def move(self):
        # TODO: implement mosquito's movement:
        # while distance > 90 - move in a random direction
        # if distance < 90, the mosquito has found the human scent trace
        # fly in random direction, if scent gets stronger, continue
        # if scent gets weaker, turn around
        # if scent is lost, fly in a random direction
        pass
