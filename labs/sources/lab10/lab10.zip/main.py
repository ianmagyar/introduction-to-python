import random
from time import sleep

import matplotlib.pyplot as plt

from actors import Human, Mosquito
from field import Field


def visualize():
    human_x = random.randint(-50, 50)
    human_y = random.randint(-50, 50)
    human = Human("Janko Hrasko", 1, human_x, human_y)
    mosquito = Mosquito("Mosquito", 1, 10, 10)

    field = Field(human, mosquito)

    plt.ion()
    fig = plt.figure()
    ax = fig.add_subplot(111)
    ax.set_xlim([-100, 100])
    ax.set_ylim([-100, 100])

    human_pos = field.get_human_coordinates()
    mosquito_pos = field.get_mosquito_coordinates()

    human_plot_point, = ax.plot(human_pos, 'bo')
    mosquito_plot_point, = ax.plot(mosquito_pos, 'rx')
    fig.canvas.draw()
    fig.canvas.flush_events()

    while not field.found():
        human_pos = field.get_human_coordinates()
        mosquito_pos = field.get_mosquito_coordinates()

        human_plot_point.set_xdata(human_pos[0])
        human_plot_point.set_ydata(human_pos[1])
        mosquito_plot_point.set_xdata(mosquito_pos[0])
        mosquito_plot_point.set_ydata(mosquito_pos[1])

        fig.canvas.draw()
        fig.canvas.flush_events()

        field.move_mosquito()
        sleep(0.1)


def get_flight_length(init_dist):
    # TODO: implement simulation and answer the question
    # how many steps it takes for the mosquito to reach its prey
    # on average given an initial distance init_dist
    pass


if __name__ == '__main__':
    visualize()
