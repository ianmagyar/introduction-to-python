import random
import sys
import time

import pygame
from pygame.locals import *


pygame.init()

FPS = 60
FramePerSec = pygame.time.Clock()

RED = (255, 0, 0)
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)

SCREEN_WIDTH = 400
SCREEN_HEIGHT = 600
SPEED = 5
SCORE = 0

font = pygame.font.SysFont("Verdana", 60)
game_over = font.render("Game Over", True, BLACK)

font_small = pygame.font.SysFont("Verdana", 20)

background = pygame.image.load("resources/AnimatedStreet.png")

DISPLAYSURF = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
DISPLAYSURF.fill(WHITE)
pygame.display.set_caption("Game")


class Enemy(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()

    def move(self):
        pass


class Player(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()

    def move(self):
        pass


P1 = Player()
E1 = Enemy()


while True:
    for event in pygame.event.get():
        if event.type == QUIT:
            pygame.quit()
            sys.exit()
    P1.move()
    E1.move()

    DISPLAYSURF.fill(WHITE)
    # DISPLAYSURF.blit(P1.image, P1.rect)

    pygame.display.update()
    FramePerSec.tick(FPS)
