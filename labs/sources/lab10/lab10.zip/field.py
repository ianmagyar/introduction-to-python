class Field:
    def __init__(self, human, mosquito):
        self.human = human
        self.mosquito = mosquito

        self.human.set_field(self)
        self.mosquito.set_field(self)

    def move_human(self):
        self.human.move()

    def move_mosquito(self):
        self.mosquito.move()

    def get_human_coordinates(self):
        return self.human.get_coords()

    def get_mosquito_coordinates(self):
        return self.mosquito.get_coords()

    def get_human(self):
        return self.human

    def get_mosquito(self):
        return self.mosquito

    def get_actor_distance(self):
        # TODO: return distance between human and mosquito
        return 0

    def found(self):
        # TODO: return if mosquito has found human (distance between them < 2)
        return False
