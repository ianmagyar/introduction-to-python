from math import sqrt


class Location:
    def __init__(self, x, y):
        self.x = float(x)
        self.y = float(y)

    def move(self, dx, dy):
        return Location(self.x + float(dx), self.y + float(dy))

    def get_coords(self):
        return self.x, self.y

    def get_distance(self, other):
        o_x, o_y = other.get_coords()
        x_dist = self.x - o_x
        y_dist = self.y - o_y
        return sqrt(x_dist ** 2 + y_dist ** 2)
