import math


class Direction:
    def __init__(self, angle):
        # angle is given in radians
        # TODO: set angle, and normalize it for range <0, 2pi>
        self.angle = angle
        while self.angle < 0:
            self.angle += math.tau
        if self.angle > math.tau:
            self.angle = self.angle % math.tau

    def move(self, dist):
        dx = dist * math.cos(self.angle)
        dy = dist * math.sin(self.angle)
        return (dx, dy)

    def get_angle(self):
        return self.angle
