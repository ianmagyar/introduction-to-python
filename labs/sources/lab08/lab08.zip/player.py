from hand import Hand


class Player:
    def __init__(self):
        self.hand = list()

    def __str__(self):
        str_repr = ""
        for card in self.hand:
            str_repr += "{} ".format(str(card))
        return str_repr

    def deal_hand(self, hand):
        self.hand = hand

    def get_all_combinations(self, flop, turn, river):
        # returns a list of all combinations of the given cards
        # each element in the list is of type Hand
        return

    def get_best_hand(self, flop, turn, river):
        # returns the strongest hand from the available cards
        # the return type is Hand
        return
