class Plane:
    def __init__(self, length):
        self.length = length
        self.seats = [[[] for i in range(self.length + 2)] for j in range(7)]

    def print_plane(self):
        for x in range(len(self.seats)):
            if x != 3:
                self.print_seats(x)
            else:
                self.print_corridor()

    def print_seats(self, seat_idx):
        row_str = "  | "
        for seat in self.seats[seat_idx][1:-1]:
            if len(seat) == 0:
                row_str += " O"
            else:
                row_str += " {}".format(len(seat))
        row_str += " |"
        print(row_str)

    def print_corridor(self):
        corridor_str = ""
        for position in self.seats[3]:
            if len(position) == 0:
                corridor_str += "  "
            else:
                corridor_str += " {}".format(len(position))
        print(corridor_str)

    def add_passengers(self, psg_list):
        for passenger in psg_list:
            passenger.add_to_plane(self)
            self.seats[3][0].append(passenger)

    def is_empty(self, row, seat):
        try:
            return not len(self.seats[seat][row])
        except IndexError:
            return True

    def move_row(self, row, seat_letter):
        if seat_letter in ["A", "B", "C"]:
            seat_list = [
                self.seats[4][row],
                self.seats[5][row],
                self.seats[6][row]
            ]
        else:
            seat_list = [
                self.seats[0][row],
                self.seats[1][row],
                self.seats[2][row]
            ]

        if self.is_empty(row + 1, 3):
            for psg_seat in seat_list:
                try:
                    psg = psg_seat[0]
                    psg_seat.remove(psg)
                    self.seats[3][row + 1].append(psg)
                    psg.forced_to_move(3, row + 1)
                except IndexError:
                    pass

    def return_row(self, row):
        cpy = self.seats[3][row + 1].copy()
        if not self.is_empty(row + 1, 3):
            for psg in cpy:
                y, x = psg.get_seat()
                p_y, p_x = psg.get_position()
                if x == row:
                    self.seats[3][row + 1].remove(psg)
                    self.seats[y][x].append(psg)
                    psg.forced_to_move(x, y)

    def move_passengers(self):
        for idx in range(len(self.seats[3]) - 1, -1, -1):
            for psg in self.seats[3][idx]:
                old_s, old_r = psg.get_position()
                new_r, new_s = psg.move()
                if old_s != new_s or old_r != new_r:
                    save_psg = psg
                    self.seats[3][idx].remove(psg)
                    self.seats[new_s][new_r].append(save_psg)
                else:
                    pass

    def boarding_finished(self):
        for pos in self.seats[3]:
            if len(pos) != 0:
                return False

        for row in self.seats[:3] + self.seats[4:]:
            for seat in row[1:-1]:
                if len(seat) != 1:
                    return False

        return True
