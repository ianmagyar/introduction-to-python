import random

from person import Person


class Population:
    def __init__(self, size, meets_per_day, uses_quarantine):
        self.size = size
        self.meets_per_day = meets_per_day
        self.persons = list()
        for _ in range(self.size):
            self.persons.append(Person())

        self.quarantine = uses_quarantine

    def set_quarantine(self, quarantine):
        self.quarantine = quarantine

    def introduce_virus(self, day, virus, patient_count):
        # TODO: introduces a new virus to the population
        # infect a random sample of the population with the virus
        # sample size is given by patient_count
        pass

    def get_moving_people(self, mobility):
        # TODO: generates a random sample of people moving (meeting others)
        # only people not in quarantine can move
        # mobility is a number between 0 and 1
        # representing the percentage of people moving within the population
        return []

    def get_people_met(self, person):
        # TODO: generate a list of people a person meets
        # person can only meet people not in quarantine
        # returns the list of people
        return []

    def simulate_interaction(self, person1, person2, day):
        # person 1 can infect person 2
        if random.random() < person1.get_infectiousness(day):
            person2.infect(day, self.virus, self.quarantine)

        # person 2 can infect person 1
        if random.random() < person2.get_infectiousness(day):
            person1.infect(day, self.virus, self.quarantine)

    def run_day(self, day, mobility):
        # TODO: simulates a day
        # 1. update people's state
        # 2. simulate people moving
        #   2.1. get list of people moving
        #   2.2. simulate all interactions
        pass

    def get_number_of_infected(self):
        # TODO: return the number of infected people within the population
        return 0
