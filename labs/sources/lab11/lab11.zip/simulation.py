import matplotlib.pyplot as plt

from virus import Virus
from person import Person
from population import Population


def run_simulation(virus, initial_patient_count,
                   population, mobility,
                   length):
    # TODO: runs a simulation based on the parameters
    # 1. introduce virus to the population
    # 2. for the duration of the simulation:
    #   2.1. simulate day's events
    #   2.2. get number of infected and append it to counts
    #   2.3. introduce dynamic quarantine:
    #          - use quarantine if more than 400 people are infected
    #          - stop using quarantine if less than 200 people are infected
    counts = list()

    return counts


if __name__ == '__main__':
    covid = Virus(incubation=5, illness_length=14, max_transmission_rate=0.8, immunity=90)
    population = Population(size=10000, meets_per_day=6, uses_quarantine=False)

    points = run_simulation(covid, 6, population, 0.1, 500)

    plt.plot(points)
    plt.show()
