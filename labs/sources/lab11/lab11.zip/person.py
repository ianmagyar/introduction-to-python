class Person:
    def __init__(self):
        self.infected = False
        self.got_infected = None
        self.has_virus = None
        self.got_cured = None
        self.quarantined = False

    def is_in_quarantine(self):
        return self.quarantined

    def is_infected(self):
        return self.infected

    def infect(self, day, virus, quarantine):
        # TODO: simulates a person getting infected
        # - if person already infected, do nothing
        # - if person immune after previous infection, do nothing
        # - otherwise infect person, set all relevant object attributes
        pass

    def update(self, day):
        # TODO: updates the person's state, potentially gets cured
        # - if person not infected, do nothing
        # - if person has been sick longer than the virus's illness duration,
        #   the person gets cured: set all relevant object attributes
        pass

    def get_infectiousness(self, day):
        # TODO: returns the probability of a person infecting someone else
        # - if the person is not infected, return 0.0
        # - otherwise return probability based on sickness duration
        return 0.0
