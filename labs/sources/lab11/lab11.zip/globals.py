SEAT_TO_IDX = {
    "A": 6,
    "B": 5,
    "C": 4,
    "D": 2,
    "E": 1,
    "F": 0
}

IDX_TO_SEAT = {
    0: "F",
    1: "E",
    2: "D",
    4: "C",
    5: "B",
    6: "A"
}
