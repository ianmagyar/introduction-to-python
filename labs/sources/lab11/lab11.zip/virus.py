import math


class Virus:
    def __init__(self, incubation, illness_length, max_transmission_rate, immunity):
        self.incubation = incubation
        self.illness_length = illness_length
        self.max_transmission_rate = max_transmission_rate
        self.immunity = immunity

    def get_immunity(self):
        return self.immunity

    def get_illness_length(self):
        return self.illness_length

    def get_incubation(self):
        return self.incubation

    def get_max_transmission_rate(self):
        return self.max_transmission_rate

    def get_gaussian_value(self, time_passed):
        smallest = self.incubation
        largest = self.illness_length - self.incubation
        std = (largest - smallest) / 4

        value = ((1 / (std * math.sqrt(math.tau))) * math.e ** (-0.5 * ((time_passed - self.illness_length // 2) / std) ** 2))

        return value

    def get_transmission(self, days_since_infected):
        if days_since_infected < self.incubation:
            return 0.0

        if days_since_infected > self.illness_length - self.incubation:
            return 0.0

        val = self.get_gaussian_value(days_since_infected)
        max_val = self.get_gaussian_value(self.illness_length // 2)
        norm_constant = self.max_transmission_rate / max_val

        return val * norm_constant


if __name__ == '__main__':
    import matplotlib.pyplot as plt

    virus = Virus(5, 14, 0.9, 90)
    X = [i for i in range(1, 15)]
    y = [virus.get_transmission(x) for x in X]

    plt.plot(X, y)
    plt.xlabel("days since infected")
    plt.ylabel("probability of infecting")
    plt.title("Change of transmission rate wrt days since infected")
    plt.show()
