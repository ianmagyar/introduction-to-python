from globals import SEAT_TO_IDX


class Passenger:
    def __init__(self, row, seat, no_of_bags):
        if seat not in ['A', 'B', 'C', 'D', 'E', 'F']:
            raise ValueError("Seat must be a letter from A to F")

        self.row = row
        self.seat = seat
        self.bags = no_of_bags * 4

        self.plane = None
        self.current_position = [None, None]

    def __str__(self):
        return "<Passenger in seat: {}{}>".format(self.row, self.seat)

    def get_position(self):
        if self.plane is not None:
            return self.current_position[-1], self.current_position[0]
        else:
            return None

    def get_seat(self):
        x = SEAT_TO_IDX[self.seat]
        y = self.row
        return x, y

    def add_to_plane(self, plane):
        self.plane = plane
        self.current_position = [0, 3]

    def can_sit(self):
        if self.plane is None:
            return False

        if self.current_position[1] != 3:
            return False

        r = self.current_position[0]
        s_idx = SEAT_TO_IDX[self.seat]
        if self.seat in ['A', 'B', 'C']:
            for s in range(4, s_idx):
                if not self.plane.is_empty(r, s):
                    return False
        else:
            for s in range(s_idx + 1, 3):
                if not self.plane.is_empty(r, s):
                    return False

        return True

    def forced_to_move(self, x, y):
        self.current_position = [y, x]

    def move(self):
        if self.plane is None:
            raise TypeError("This passenger was not added to a plane yet")

        r, s = self.current_position
        if r < self.row and self.plane.is_empty(r + 1, s):
            self.current_position = [r + 1, s]
            return r + 1, s

        if r == self.row:
            if self.bags > 0:
                self.bags -= 1
                return r, s
            else:
                if self.can_sit():
                    self.current_position = [self.row, SEAT_TO_IDX[self.seat]]
                    self.plane.return_row(self.row)
                    return self.row, SEAT_TO_IDX[self.seat]
                else:
                    self.plane.move_row(self.row, self.seat)
                    return r, s

        return r, s
