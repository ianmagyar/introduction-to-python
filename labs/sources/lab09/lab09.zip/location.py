class Location:
    def __init__(self, x, y):
        pass

    def move(self, dx, dy):
        return

    def get_coords(self):
        return

    def get_distance(self, other):
        return
