class Actor:
    def __init__(self, name, speed, x, y):
        pass

    def set_field(self, field):
        pass

    def move(self):
        pass

    def get_coords(self):
        return

    def get_location(self):
        return
