class Direction:
    def __init__(self, angle):
        # angle is given in radians
        # TODO: set angle, and normalize it for range <0, 2pi>
        self.angle = angle

    def move(self, dist):
        # TODO: return difference in x and y values based on angle
        return (-1, -1)

    def get_angle(self):
        return self.angle
