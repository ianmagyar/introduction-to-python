import random
from time import sleep

import matplotlib.pyplot as plt

from actor import Actor


def visualize():
    human_x = random.randint(-50, 50)
    human_y = random.randint(-50, 50)
    actor = Actor("Janko Hrasko", 1, human_x, human_y)

    plt.ion()
    fig = plt.figure()
    ax = fig.add_subplot(111)
    ax.set_xlim([-100, 100])
    ax.set_ylim([-100, 100])

    actor_pos = actor.get_coords()

    actor_plot_point, = ax.plot(actor_pos, 'bo')
    fig.canvas.draw()
    fig.canvas.flush_events()

    for _ in range(1000):
        actor_pos = actor.get_coords()

        actor_plot_point.set_xdata(actor_pos[0])
        actor_plot_point.set_ydata(actor_pos[1])

        fig.canvas.draw()
        fig.canvas.flush_events()

        sleep(0.1)


if __name__ == '__main__':
    visualize()
